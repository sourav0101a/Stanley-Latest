import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import LB2BQty from '@salesforce/label/c.LB2BQty';
import LB2BUnitPrice from '@salesforce/label/c.LB2BUnitPrice';
import LB2BTotalPrice from '@salesforce/label/c.LB2BTotalPrice';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BEstimatedShip from '@salesforce/label/c.LB2BEstimatedShip';
import LB2BEstimatedDelivery from '@salesforce/label/c.LB2BEstimatedDelivery';
import LB2BQtyMissMatchError from '@salesforce/label/c.LB2BQtyMissMatchError';
import LB2BTo from '@salesforce/label/c.LB2BTo';
import LB2BPendingInventory from '@salesforce/label/c.LB2BPendingInventory';
import LB2BFree from '@salesforce/label/c.LB2BFree';
import LB2BSubstituteProductsMsg from '@salesforce/label/c.LB2BSubstituteProductsMsg';
import LOCALE from '@salesforce/i18n/locale';
//  for check inventory availability
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';

const QUANTITY_CHANGED_EVT = 'quantitychanged';
const SINGLE_CART_ITEM_DELETE = 'singlecartitemdelete';

/**
 * A non-exposed component to display cart items.
 *
 * @fires Items#quantitychanged
 * @fires Items#singlecartitemdelete
 */
export default class Lb2bCheckoutFinalCartItemV2 extends NavigationMixin(LightningElement) {
    label = {
        LB2BQty,
        LB2BUnitPrice,
        LB2BSku,
        LB2BEstimatedShip,
        LB2BEstimatedDelivery,
        LB2BPendingInventory,
        LB2BQtyMissMatchError,
        LB2BTo,
        LB2BFree,
        LB2BSubstituteProductsMsg,
        LB2BTotalPrice
    };

    /**
     * An event fired when the quantity of an item has been changed.
     *
     * Properties:
     *   - Bubbles: true
     *   - Cancelable: false
     *   - Composed: true
     *
     * @event Items#quantitychanged
     * @type {CustomEvent}
     *
     * @property {string} detail.itemId
     *   The unique identifier of an item.
     *
     * @property {number} detail.quantity
     *   The new quantity of the item.
     *
     * @export
     */

    /**
     * An event fired when the user triggers the removal of an item from the cart.
     *
     * Properties:
     *   - Bubbles: true
     *   - Cancelable: false
     *   - Composed: true
     *
     * @event Items#singlecartitemdelete
     * @type {CustomEvent}
     *
     * @property {string} detail.cartItemId
     *   The unique identifier of the item to remove from the cart.
     *
     * @export
     */

    /**
     * A cart line item.
     *
     * @typedef {Object} CartItem
     *
     * @property {ProductDetails} productDetails
     *   Representation of the product details.
     *
     * @property {string} originalPrice
     *   The original price of a cart item.
     *
     * @property {number} quantity
     *   The quantity of the cart item.
     *
     *  @property {number} quantityOrder
     *   The quantity of the cart item.
     *
     * @property {string} totalPrice
     *   The total sales price of a cart item.
     *
     * @property {string} totalListPrice
     *   The total original (list) price of a cart item.
     *
     * @property {string} unitAdjustedPrice
     *   The cart item price per unit based on tiered adjustments.
     *
     * @property {Object} estimatedDates
     *
     */

    /**
     * Details for a product containing product information
     *
     * @typedef {Object} ProductDetails
     *
     * @property {string} productId
     *   The unique identifier of the item.
     *
     * @property {string} sku
     *  Product SKU number.
     *
     * @property {string} name
     *   The name of the item.
     *
     * @property {ThumbnailImage} thumbnailImage
     *   The image of the cart line item
     *
     */

    /**
     * Image information for a product.
     *
     * @typedef {Object} ThumbnailImage
     *
     * @property {string} alternateText
     *  Alternate text for an image.
     *
     * @property {string} title
     *   The title of the image.
     *
     * @property {string} url
     *   The url of the image.
     */

    @wire(CurrentPageReference)
    pageRef;
    /**
     * The ISO 4217 currency code for the cart page
     *
     * @type {string}
     */
    @api
    currencyCode;
    @api sapJsonData;
    @api recordId;
    _isCheckout;
    _isCheckoutvalue;
    dataa = [];
    newarray;

    @api
    effectiveAccountId;
    visibleAccounts;

    /**
     * Whether or not the cart is in a locked state
     *
     * @type {Boolean}
     */

    /**
     * A list of CartItems
     *
     * @type {CartItem[]}
     */

    @api
    get cartItems() {
        return this._providedItems;
    }

    set cartItems(items) {
        console.log('new data', JSON.stringify(items));
        this._providedItems = items;
        const generatedUrls = [];
        this.displayItems = (items || []).map((item) => {
            // Create a copy of the item that we can safely mutate.
            const newItem = { ...item };

            // Get URL for the product, which is asynchronous and can only happen after the component is connected to the DOM (NavigationMixin dependency).
            const urlGenerated = this._canResolveUrls
                .then(() =>
                    this[NavigationMixin.GenerateUrl]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: newItem.product2Id,
                            objectApiName: 'Product2',
                            actionName: 'view'
                        }
                    })
                )
                .then((url) => {
                    newItem.productUrl = url;
                });
            generatedUrls.push(urlGenerated);
            return newItem;
        });
        // When we've generated all our navigation item URLs, update the list once more.
        Promise.all(generatedUrls).then(() => {
            //  this._items = Array.from(this._items);
            this.displayItems = Array.from(this.displayItems);
        });
        this.dataa = this.displayItems;
    }

    @api
    get isBrowserPrint() {
        return this.isPrint;
    }

    set isBrowserPrint(value) {
        this.isPrint = value;
        if (value) {
            this.recordSize = 130;
            this.displayItems = this._providedItems;
            this.dataa = [];
        }
    }

    updateCartItems(event) {
        if (!this.isPrint) {
            this.displayItems = [...event.detail.records];
        }
    }

    get arrayLength() {
        return this.dataa.length === 0 || this.isPrint;
    }

    /**
     * A normalized collection of items suitable for display.
     *
     * @private
     */

    displayItems = [];
    /**
     * A list of provided cart items
     *
     * @private
     */
    _providedItems;
    isPrint;
    @track recordSize = 100;

    /**
     * A Promise-resolver to invoke when the component is a part of the DOM.
     *
     * @type {Function}
     * @private
     */
    _connectedResolver;
    pcrCodes;

    /**
     * A Promise that is resolved when the component is connected to the DOM.
     *
     * @type {Promise}
     * @private
     */
    _canResolveUrls = new Promise((resolved) => {
        this._connectedResolver = resolved;
    });

    /**
     * This lifecycle hook fires when this component is inserted into the DOM.
     */
    connectedCallback() {
        this.pcrCodes = localStorage.getItem('PcrCodes');
        console.log('Pcr Codes ', this.pcrCodes);
        this._isCheckout = window.location.origin + window.location.pathname;
        this._isCheckoutvalue = this._isCheckout.includes('order-review');
        this.MoveToDataLayer();
        this._connectedResolver();
    }

    get isCheckout() {
        this._isCheckout = window.location.origin + window.location.pathname;
        return this._isCheckout.includes('order-review');
    }

    /**
     * This lifecycle hook fires when this component is removed from the DOM.
     */
    disconnectedCallback() {
        // We've beeen disconnected, so reset our Promise that reflects this state.
        this._canResolveUrls = new Promise((resolved) => {
            this._connectedResolver = resolved;
        });
    }

    /**
     * Gets the sequence of cart items for display.
     * This getter allows us to incorporate properties that are dependent upon
     * other component properties, like price displays.
     *
     * @private
     */

    navigateBackToCartPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    /**
     * Gets the available labels.
     *
     * @type {Object}
     *
     * @readonly
     * @private
     */
    get labels() {
        return {
            quantity: 'Qty',
            originalPriceCrossedOut: 'Original price (crossed out):'
        };
    }

    /**
     * Handler for the 'click' event fired from 'contents'
     *
     * @param {Object} evt the event object
     */
    handleProductDetailNavigation(evt) {
        evt.preventDefault();
        const productId = evt.target.dataset.productid;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: productId,
                actionName: 'view'
            }
        });
    }

    /**
     * Fires an event to delete a single cart item
     * @private
     * @param {ClickEvent} clickEvt A click event.
     * @fires Items#singlecartitemdelete
     */
    handleDeleteCartItem(clickEvt) {
        const cartItemId = clickEvt.target.dataset.cartitemid;
        this.dispatchEvent(
            new CustomEvent(SINGLE_CART_ITEM_DELETE, {
                bubbles: true,
                composed: true,
                cancelable: false,
                detail: {
                    cartItemId
                }
            })
        );
    }

    /**
     * Fires an event to update the cart item quantity
     * @private
     * @param {FocusEvent} blurEvent A blur event.
     * @fires Items#quantitychanged
     */
    handleQuantitySelectorBlur(blurEvent) {
        //Stop the original event since we're replacing it.
        blurEvent.stopPropagation();

        // Get the item ID off this item so that we can add it to a new event.
        const cartItemId = blurEvent.target.dataset.itemId;
        // Get the quantity off the control, which exposes it.
        const quantity = blurEvent.target.value;

        // Fire a new event with extra data.
        this.dispatchEvent(
            new CustomEvent(QUANTITY_CHANGED_EVT, {
                bubbles: true,
                composed: true,
                cancelable: false,
                detail: {
                    cartItemId,
                    quantity
                }
            })
        );
    }

    /**
     * Handles a click event on the input element.
     *
     * @param {ClickEvent} clickEvent
     *  A click event.
     */
    handleQuantitySelectorClick(clickEvent) {
        /*
       Firefox is an oddity in that if the user clicks the "spin" dial on the number
       control, the input control does not gain focus. This means that users clicking the
       up or down arrows won't trigger our events.
  
       To keep the user interactions smooth and prevent a notification on every up / down arrow click
       we simply pull the focus explicitly to the input control so that our normal event handling takes care of things properly.
     */
        clickEvent.target.focus();
    }

    @track mapData = [];
    mapDataFinal = [];
    eventValue;
    totalFinalValue = 0;
    MoveToDataLayer() {
        let productCurrency = LOCALE === 'en-US' ? 'USD' : LOCALE === 'es-MX' ? 'MXN' : 'CAD';
        console.log('currency ', this._isCheckoutvalue);
        for (var i = 0; i < this.displayItems.length; i++) {
            this.mapData.push({
                item_name: this.displayItems[i].productName,
                item_brand: this.displayItems[i].brandName,
                item_id: this.displayItems[i].productSku,
                item_variant: null,
                price: this.displayItems[i].unitPrice,
                discount: null,
                quantity: this.displayItems[i].quantity,
                index: i + 1
            });
            this.totalFinalValue = this.totalFinalValue + this.displayItems[i].extendedPrice;
        }
        this.mapDataFinal = this.mapData;
        this.eventValue = this._isCheckoutvalue === true ? 'view_order_review' : 'view_checkout';
        console.log('Final Array ', JSON.parse(JSON.stringify(this.mapDataFinal)));
        dispatchUpdateDataLayerEvent({
            event: this.eventValue,
            ecommerce: {
                currency: productCurrency,
                value: this.totalFinalValue.toFixed(2),
                coupon: this.pcrCodes === undefined || null ? null : this.pcrCodes,
                items: JSON.parse(JSON.stringify(this.mapDataFinal))
            }
        });
    }

    get isInternalSalessRep() {
        return hasPermission;
    }
}

export function dispatchUpdateDataLayerEvent(detail) {
    document.dispatchEvent(
        new CustomEvent('updatedatalayer', {
            detail
        })
    );
}