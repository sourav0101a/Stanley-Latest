import { LightningElement,track, api } from 'lwc';
import getPlantNames from '@salesforce/apex/LB2BCheckAvailabilityController.getPlantNames';
import getLocationInfo from '@salesforce/apex/LB2BCheckAvailabilityController.getLocationInfo';
import getInventory from '@salesforce/apex/LB2BCheckAvailabilityController.getInventory';
import LB2BCheckAvailability from '@salesforce/label/c.LB2BCheckAvailability';
import LB2BSelectPlant from '@salesforce/label/c.LB2BSelectPlant';
import LB2BDefaultPlantNote from '@salesforce/label/c.LB2BDefaultPlantNote';
import LB2BAvailableInventory from '@salesforce/label/c.LB2BAvailableInventory';
import LB2BNoPlantMessage from '@salesforce/label/c.LB2BNoPlantMessage';
import SalesRepMX from '@salesforce/customPermission/Sales_Rep_MX';
import SalesRepUS from '@salesforce/customPermission/Sales_Rep_US';
import SalesRepCA from '@salesforce/customPermission/Sales_Rep_CA';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import LocaleSidKey from '@salesforce/i18n/locale';
import { loadStyle} from 'lightning/platformResourceLoader';



export default class Lb2bCheckAvailability extends LightningElement {
    isModalOpen = false;
    plantNames;
    @track plantNameOptions = [];
    @api productSku;
    value;
    isLoading =  false;
    isNoLocationData = false;
    inventory;

    label = {
        LB2BCheckAvailability,
        LB2BSelectPlant,
        LB2BDefaultPlantNote,
        LB2BAvailableInventory,
        LB2BNoPlantMessage
    }

    connectedCallback(){
        console.log('productSku------>  ', this.productSku);
        loadStyle(this, GlobalCSS);
    }

    handleCheckAvailability () {
        this.plantNameOptions = [];
        this.callGetPlantNames();
    }

    callGetPlantNames(){
        console.log('locale >>>',LocaleSidKey);
        this.isLoading = true;
        getPlantNames({
            locale : LocaleSidKey
        }).then((result) => {
        //    this.plantNameOptions = [];
            console.log('Plant names result >>> ',result);
            for(let i = 0; i < result.length; i++){
                this.plantNameOptions.push({ label: result[i].Plant_Name__c, value:  result[i].Label });
            }

            if (this.plantNameOptions) {
                this.isLoading = false;
                this.isModalOpen = true;
               // this.value = this.plantNameOptions.find(opt => opt.value === '155').label;
                console.log('plantNameOptions value >>> ',this.value)
                if(SalesRepUS){
                    this.value = this.plantNameOptions.find(opt => opt.value === '0020-155-00').value;
                    console.log('SalesRepUS value >>> ',this.value); 
                } else if(SalesRepMX){
                    this.value = this.plantNameOptions.find(opt => opt.value === '3001-217-00').value; 
                    console.log('SalesRepMX value >>> ',this.value);
                } else if(SalesRepCA){
                    this.value = this.plantNameOptions.find(opt => opt.value === '0010-150-00').value; 
                    console.log('SalesRepCA value >>> ',this.value);
                }
                this.callGetLocationInfo(this.value);
            }

            console.log('by default value:   ', this.plantNameOptions.find(opt => opt.value === '155').value)
            
            
        })        
        .catch((error) => {
            console.log('error for plant names result: ', error);
        });
    }
    

    handlePlantNameChange(event){
        let plantName = event.target.options.find(opt => opt.value === event.detail.value).label;
        let plantLabel = event.detail.value;
        console.log('onchange >>> ', plantName, ' >> ', plantLabel )
        this.callGetLocationInfo(plantLabel);
    }

    //get locations 
    callGetLocationInfo(plant_label) {
        getLocationInfo({
            plantNumber: plant_label
        })
        .then((result) => {
            console.log('Plant location result >>> ', result);
            this.isNoLocationData = false;
            if (result.ExternalReference) {
                this.callGetInventory(result.ExternalReference);
            }
        })
        .catch((error) => {
            this.isNoLocationData = true;
            console.log('error for location result: ', error.body.message);
        });
    }
    
    //get inventory 
    callGetInventory(location_Identifier){
        let listOfSkus= [this.productSku];
        let listOflocation_Identifier= [location_Identifier];

        getInventory({
            sku: listOfSkus,
            locationIdentifier: listOflocation_Identifier
        })
        .then((result) => {
            this.isNoLocationData = false;
            console.log('result for getInventory: ', result);
            inventory = result.locations.inventoryrecords.availableToOrder;
        })
        .catch((error) => {
            this.isNoLocationData = true;
            console.log('error for getInventory: ', error);
        })
    }

    handleToggleOpenClick (event) {
        this.isModalOpen = false;
    }
}