import { LightningElement, api, track, wire } from 'lwc';
import LB2BShowing from '@salesforce/label/c.LB2BShowing';
import LB2BOf from '@salesforce/label/c.LB2BOf';
import LB2BTo from '@salesforce/label/c.LB2BTo';
import LB2BEntries from '@salesforce/label/c.LB2BEntries';
import LB2BPages from '@salesforce/label/c.LB2BPages';
import LB2BPrevious from '@salesforce/label/c.LB2B_Previous_Button';
import LB2BNext from '@salesforce/label/c.LB2B_Next_Button';
import { fireEvent } from 'c/lb2bPubSub';
import { CurrentPageReference } from 'lightning/navigation';
import { registerListener } from 'c/lb2bPubSub';

export default class Lb2bCartItemPagination extends LightningElement {
    label = {
        LB2BShowing,
        LB2BOf,
        LB2BTo,
        LB2BEntries,
        LB2BPages,
        LB2BPrevious,
        LB2BNext
    };
    @api totalEntries;
    currentPage = 1;
    totalRecords;
    @api _recordSize;
    @api cartTotalCount;
    totalPage = 0;
    nextToken;
    previousToken;
    lastItemDeleted = false;

    @wire(CurrentPageReference) pageRef;

    get records() {
        return this.visibleRecords;
    }
    @api
    set records(data) {
        if (data) {
            this.totalRecords = data;
            // this.totalPage = Math.ceil(data.length/this._recordSize);
            this.totalPage = Math.ceil(this.cartTotalCount / this._recordSize);
            // this.updateRecords();
            // this.totalEntries = this._recordSize*this.totalPage;
        }
    }

    get productCount() {
        return this.cartTotalCount;
    }
    @api
    set productCount(data) {
        this.cartTotalCount = data;
        // this._recordSize = Number(data.recordsize);
    }

    get recordSize() {
        return this._recordSize;
    }
    @api
    set recordSize(data) {
        this._recordSize = Number(data);
    }

    get disablePrevious() {
        return this.previousToken == null || this.currentPage <= 1;
    }
    get disableNext() {
        return this.nextToken == null || this.currentPage >= this.totalPage;
    }
    previousHandler() {
        fireEvent(this.pageRef, 'paginationPreviousPage', this.previousToken);
        if (this.currentPage > 1) {
            this.currentPage--;
            // this.updateRecords()
        }
    }
    nextHandler() {
        fireEvent(this.pageRef, 'paginationNextPage', this.nextToken);
        this.currentPage++;
        // if(this.currentPage < this.totalPage){
        //     this.currentPage = this.currentPage+1
        //     // this.updateRecords();
        // }
    }

    updateRecords() {
        const start = (this.currentPage - 1) * this._recordSize;
        const end = this._recordSize * this.currentPage;
        this.visibleRecords = this.totalRecords.slice(start, end);

        if (this.visibleRecords.length == 0) {
            this.currentPage = 1;
        }

        // this.dispatchEvent(new CustomEvent('update',{
        //     detail:{
        //         records:this.visibleRecords
        //     }
        // }))
    }

    get next() {
        return this.nextToken;
    }
    @api
    set next(data) {
        this.nextToken = data;
    }

    get previous() {
        return this.previousToken;
    }

    @api
    set previous(data) {
        this.previousToken = data;
    }

    // get isDeleted(){
    //     return this.lastItemDeleted;
    // }
    // @api
    // set isDeleted(data){
    //     this.lastItemDeleted = data;
    //     this.previousHandler();
    // }
    isDeleted(val) {
        this.lastItemDeleted = val;
        if (this.currentPage > 1) {
            this.currentPage--;
        }
        this.previousHandler();
    }

    connectedCallback() {
        registerListener('itemDeleted', this.isDeleted, this);
    }
}