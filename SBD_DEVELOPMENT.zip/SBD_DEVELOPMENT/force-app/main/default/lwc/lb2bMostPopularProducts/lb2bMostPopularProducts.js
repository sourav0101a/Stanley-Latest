import { LightningElement, track, api, wire } from 'lwc';
import getAggregateResults from '@salesforce/apex/LB2BMostPopularController.getAggregateResults';
import communityId from '@salesforce/community/Id';
import { NavigationMixin } from 'lightning/navigation';
import Id from '@salesforce/user/Id';
import LOCALE from '@salesforce/i18n/locale';
import userAccountId from '@salesforce/schema/User.AccountId';
import { getRecord } from 'lightning/uiRecordApi';

import LB2BMostPopular from '@salesforce/label/c.LB2BMostPopular';
import LB2BSku from '@salesforce/label/c.LB2BSku';

export default class Lb2bMostPopularProducts extends NavigationMixin(LightningElement) {

    @track currentSlideIndex = 0;
    @track productsPerPage = 4;
    @track productList;

    @api effectiveAccountId;
    @api product;

    accountId;
    color;
    isCanadaUser = false;
    isMxUser = false;
    isUsUser = false;
    isLoading;

    labels = {
        LB2BMostPopular,
        LB2BSku
    }

    connectedCallback(){
   if (LOCALE === 'en-US') {
        this.isUsUser = true;
    } else if (LOCALE === 'fr-CA') {
        this.isCanadaUser = true;
    } else {
        this.isMxUser = true;
    }
}

    @wire(getRecord, { recordId: Id, fields: [userAccountId] })
    userDetails({ error, data }) {
        if (data) {
            this.isLoading = true;
            this.accountId = data.fields.AccountId.value;
            setTimeout(() => {
                this.getPopularProducts();
            }, 5000);
            
        }
    }

    getPopularProducts() {
        getAggregateResults({ communityId: communityId, effectiveAccountId: this.accountId })
            .then((results) => {
                console.log('Successfully retrieved products', results);
                let res = JSON.parse(JSON.stringify(results));

                // Remove duplicates based on productId               
                 this.productList = res.filter((item, index) => res.findIndex((i) =>
                    i.fields.Name === item.fields.Name) === index);

                // Change Product Availability Status Color
                this.productList.forEach(element => {
                    let value = this.isUsUser ? element.fields.LB2BProductAvailabilityStatusUs__c :
                                this.isCanadaUser ? element.fields.LB2BProductAvailabilityStatusCa__c :
                                element.fields.LB2BProductAvailabilityStatusMx__c
                    element.stockAvailabilityColor = value === 'In Stock' ? 'InStock' :
                                    value === 'Out of Stock' ? 'OutofStock' :
                                    value === 'Low Stock' ? 'LowStock' : '';
                });
                this.isLoading = false;
            })
            
            .catch((error) => {
                console.log('Error:', error);
            });
    }

    get hasProducts() {
        return this.productList != undefined && this.productList.length > 0;
    }

    get currentGroup() {
        const start = this.currentSlideIndex * this.productsPerPage;
        const end = start + this.productsPerPage;
        return this.productList ? this.productList.slice(start, end) : [];
    }

    get showLeftArrow() {
        return this.currentSlideIndex > 0;
    }

    get showRightArrow() {
        return this.currentSlideIndex < 3 && (this.productList != undefined && this.productList.length > 4);
    }

    handlePrevArrowClick() {
        if (this.currentSlideIndex > 0) {
            this.currentSlideIndex--;
        }
    }

    handleNextArrowClick() {
        const totalSlides = Math.ceil(this.productList.length / this.productsPerPage);
        if (this.currentSlideIndex < totalSlides - 1) {
            this.currentSlideIndex++;
        }
    }

    handleCarouselClick(event) {
        const productId = event.currentTarget.dataset.productId;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: productId,
                objectApiName: 'Product2',
                actionName: 'view'
            }
        });
    }
}