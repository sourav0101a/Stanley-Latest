import { api, LightningElement, track, wire } from 'lwc';
// import getOrderStatus from "@salesforce/apex/LB2BCallEnosix.getOrderStatus";
import { NavigationMixin } from 'lightning/navigation';
import getOrderNo from '@salesforce/apex/LB2BCallEnosix.getOrderNo';
import getOrderDetail from '@salesforce/apex/LB2BCallEnosix.getOrderDetail';
import communityId from '@salesforce/community/Id';
import getWishlistSummaries from '@salesforce/apex/LB2BCartController.getWishlistSummaries';
import addItemsToWishlist from '@salesforce/apex/LB2BCartController.addItemsToWishlist';
import createWishlist from '@salesforce/apex/LB2BCartController.createWishlist';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import { CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import addToCart from '@salesforce/apex/LB2BCSVUploaderController.addToCart';
import addQuoteNumber from '@salesforce/apex/LB2BCSVUploaderController.addQuoteNumber';
import LB2BSapOrder from '@salesforce/label/c.LB2BSapOrder';
import LB2BCreateAList from '@salesforce/label/c.LB2BCreateAList';
import LB2BExportToExcel from '@salesforce/label/c.LB2BExportToExcel';
import LB2BReorder from '@salesforce/label/c.LB2BReorder';
import LB2BOrderQty from '@salesforce/label/c.LB2BOrderQty';
import LB2BShipQty from '@salesforce/label/c.LB2BShipQty';
import LB2BEstShip from '@salesforce/label/c.LB2BEstShip';
import LB2BEstimatedDelivery from '@salesforce/label/c.LB2BEstimatedDelivery';
import LB2BTracking from '@salesforce/label/c.LB2BTracking';
import LB2BProductName from '@salesforce/label/c.LB2BProductName';
import LB2BExtPrice from '@salesforce/label/c.LB2BExtPrice';
import LB2BCarrier from '@salesforce/label/c.LB2BCarrier';
import LB2BShipDate from '@salesforce/label/c.LB2BShipDate';
import LB2BRejectedQty from '@salesforce/label/c.LB2BRejectedQty';
import LB2BRejectReason from '@salesforce/label/c.LB2BRejectReason';
import LB2BReorderInProgress from '@salesforce/label/c.LB2BReorderInProgress';
import LB2BAddingItemsToCart from '@salesforce/label/c.LB2BAddingItemsToCart';
import LB2BViewCart from '@salesforce/label/c.LB2BViewCart';
import LB2BContinueShopping from '@salesforce/label/c.LB2BContinueShopping';
import LB2BStatus from '@salesforce/label/c.LB2BStatus';
import LB2BAdd_All_List from '@salesforce/label/c.LB2BAdd_All_List';
import LB2BClose from '@salesforce/label/c.LB2BClose';
import LB2BCreateList from '@salesforce/label/c.LB2BCreateList';
import LB2BAddtoexistingList from '@salesforce/label/c.LB2BAddtoexistingList';
import LB2BCancel from '@salesforce/label/c.LB2BCancel';
import LB2BAdd from '@salesforce/label/c.LB2BAdd';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BUnitPrice from '@salesforce/label/c.LB2BUnitPrice';
import LB2BShowModal from '@salesforce/label/c.LB2BShowModal';
import LB2BOrderDetailError from '@salesforce/label/c.LB2BOrderDetailError';
import LB2BReorderAllSkuNotexist from '@salesforce/label/c.LB2BReorderAllSkuNotexist';
import LB2BTrackingNumber from '@salesforce/label/c.LB2BTrackingNumber';
import LB2BError from '@salesforce/label/c.LB2BError';
import LB2BSuccess from '@salesforce/label/c.LB2BSuccess';
import LB2BListName from '@salesforce/label/c.LB2BListName';
import LB2BMyLists from '@salesforce/label/c.LB2BMyLists';
import LB2BButtonCancel from '@salesforce/label/c.LB2BButtonCancel';
import LB2BViewAll from '@salesforce/label/c.LB2BViewAll';
import LB2BNotAccess from '@salesforce/label/c.LB2BNotAccess';
import LB2BSoldToLabel from '@salesforce/label/c.LB2BSoldToLabel';
import LB2BShipToLabel from '@salesforce/label/c.LB2BShipToLabel';
import LB2BSales_Order_Number from '@salesforce/label/c.LB2BSales_Order_Number';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BOrderDetails from '@salesforce/label/c.LB2BOrderDetails';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BOrderDate from '@salesforce/label/c.LB2BOrderDate';
import LB2BSapAccount from '@salesforce/label/c.LB2BSapAccount';
import LB2BFreight from '@salesforce/label/c.LB2BFreight';
import LB2BNetTotal from '@salesforce/label/c.LB2BNetTotal';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BNetAmount from '@salesforce/label/c.LB2BNetAmount';
import LB2BOrderSumm from '@salesforce/label/c.LB2BOrderSumm';
import LB2BSubtotal from '@salesforce/label/c.LB2BSubtotal';
import LB2BTotal from '@salesforce/label/c.LB2BTotal';
import LB2BLiftFee from '@salesforce/label/c.LB2BLiftFee';
import LB2BResidentialFee from '@salesforce/label/c.LB2BResidentialFee';
import LB2BOk from '@salesforce/label/c.LB2BOk';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';
import { toastUtil } from 'c/lb2bUtil';
import { registerListener } from 'c/lb2bPubSub';
import LOCALE from '@salesforce/i18n/locale';
import LB2BDeliveryNumber from '@salesforce/label/c.LB2BDeliveryNumber';
import { OrderTracking } from 'c/lb2bDataLayer';
import LB2BShipProNumber from '@salesforce/label/c.LB2BShipProNumber';
import LB2BCarrierName from '@salesforce/label/c.LB2BCarrierName';
import LB2BLargeOrderTimeoutError from '@salesforce/label/c.LB2BLargeOrderTimeoutError';
import LB2BAssignedbyTradingContract from '@salesforce/label/c.LB2BAssignedbyTradingContract';
import LB2BDeliveryTooLate from '@salesforce/label/c.LB2BDeliveryTooLate';
import LB2BShiporCancelRequest from '@salesforce/label/c.LB2BShiporCancelRequest';
import LB2BCustomerRequest from '@salesforce/label/c.LB2BCustomerRequest';
import LB2BPastCancelDate from '@salesforce/label/c.LB2BPastCancelDate';
import LB2BDiscontinuedNoLongerAvailable from '@salesforce/label/c.LB2BDiscontinuedNoLongerAvailable';
import LB2BDiscontinuedwithReplacement from '@salesforce/label/c.LB2BDiscontinuedwithReplacement';
import LB2BCustomerServiceAdjustment from '@salesforce/label/c.LB2BCustomerServiceAdjustment';
import LB2BRefusedreturnsentbacktocustomer from '@salesforce/label/c.LB2BRefusedreturnsentbacktocustomer';
import LB2BProductnotreceivedinreturnshipment from '@salesforce/label/c.LB2BProductnotreceivedinreturnshipment';
import LB2BInvalidClaim from '@salesforce/label/c.LB2BInvalidClaim';
import LB2BItemnotreturned from '@salesforce/label/c.LB2BItemnotreturned';
import LB2BDiscorderthroughproductservice from '@salesforce/label/c.LB2BDiscorderthroughproductservice';
import LB2BCancelledpersalesrep from '@salesforce/label/c.LB2BCancelledpersalesrep';
import LB2BMovedtoproductservicesystem from '@salesforce/label/c.LB2BMovedtoproductservicesystem';
import LB2BDiscontinuedNoSubstitutionAllowed from '@salesforce/label/c.LB2BDiscontinuedNoSubstitutionAllowed';
import LB2BShiporCancelInventoryIssue from '@salesforce/label/c.LB2BShiporCancelInventoryIssue';
import LB2BDeletedandMovedtoNewOrder from '@salesforce/label/c.LB2BDeletedandMovedtoNewOrder';
import LB2BSuspendedNoInventoryAvailable from '@salesforce/label/c.LB2BSuspendedNoInventoryAvailable';
import LB2BCancelledPricingissueunresolved from '@salesforce/label/c.LB2BCancelledPricingissueunresolved';
import LB2BCancelledReconcancelpolicy from '@salesforce/label/c.LB2BCancelledReconcancelpolicy';
import LB2BRBOMIncorrectQty from '@salesforce/label/c.LB2BRBOMIncorrectQty';
import LB2BCustomerError from '@salesforce/label/c.LB2BCustomerError';
import LB2BProductNotAvailable from '@salesforce/label/c.LB2BProductNotAvailable';
import LB2BInventorynotavailableWalmartDSDC from '@salesforce/label/c.LB2BInventorynotavailableWalmartDSDC';
import LB2BCustomeragreedtocxnoinvy from '@salesforce/label/c.LB2BCustomeragreedtocxnoinvy';
import LB2BCoilDifferentialAllowance from '@salesforce/label/c.LB2BCoilDifferentialAllowance';
import LB2BAutoRejectedOldLine from '@salesforce/label/c.LB2BAutoRejectedOldLine';
import LB2BAutoRejectPricing from '@salesforce/label/c.LB2BAutoRejectPricing';
import LB2BOutofPolicyDateCode from '@salesforce/label/c.LB2BOutofPolicyDateCode';
import LB2BMissingTool from '@salesforce/label/c.LB2BMissingTool';
import LB2BMissingBattery from '@salesforce/label/c.LB2BMissingBattery';
import LB2BMissingCharger from '@salesforce/label/c.LB2BMissingCharger';
import LB2BMissingParts from '@salesforce/label/c.LB2BMissingParts';
import LB2BSwappedparts from '@salesforce/label/c.lb2bSwappedparts';
import LB2BAbuse from '@salesforce/label/c.LB2BAbuse';
import LB2BCancelledAddNewLineforSub from '@salesforce/label/c.LB2BCancelledAddNewLineforSub';
import LB2BCanceledforsystemconversion from '@salesforce/label/c.LB2BCanceledforsystemconversion';
import LB2BCancelledduetosingledelivery from '@salesforce/label/c.LB2BCancelledduetosingledelivery';
import LB2BCancelledduetosingleinvoicing from '@salesforce/label/c.LB2BCancelledduetosingleinvoicing';
import LB2BCreditReasons from '@salesforce/label/c.LB2BCreditReasons';
import LB2BCreditMemoCleanup from '@salesforce/label/c.LB2BCreditMemoCleanup';
import LB2BDeallocateStock from '@salesforce/label/c.LB2BDeallocateStock';
import LB2BShouldhavebeenanEstimate from '@salesforce/label/c.LB2BShouldhavebeenanEstimate';
import LB2BReturnedNotRepaired from '@salesforce/label/c.LB2BReturnedNotRepaired';
import LB2BSRDPlndOrd from '@salesforce/label/c.LB2BSRDPlndOrd';
import LB2BExceedsTLConstraintsCustSvcAdj from '@salesforce/label/c.LB2BExceedsTLConstraintsCustSvcAdj';
import LB2BStatisticalUseUltimusApproval from '@salesforce/label/c.LB2BStatisticalUseUltimusApproval';
import LB2BCoilDifferentialAllowanc from '@salesforce/label/c.LB2BCoilDifferentialAllowance';
import LB2BCancelledDuetoUnshippedin7days from '@salesforce/label/c.LB2BCancelledDuetoUnshippedin7days';
import agoraDetail from '@salesforce/apex/LB2BAgora_OrderDetail.execute';

export default class Lb2bOrderDetail extends NavigationMixin(LightningElement) {
    // @api recordId;
    @api cartIdFromLocalStorage;
    @api status;

    @api cartIdNew;

    label = {
        LB2BSapOrder,
        LB2BCreateAList,
        LB2BOrderSumm,
        LB2BExportToExcel,
        LB2BReorder,
        LB2BOrderQty,
        LB2BShipQty,
        LB2BEstShip,
        LB2BEstimatedDelivery,
        LB2BTracking,
        LB2BProductName,
        LB2BExtPrice,
        LB2BCarrier,
        LB2BShipDate,
        LB2BOrderDetails,
        LB2BOrderDate,
        LB2BSapAccount,
        LB2BLiftFee,
        LB2BTotal,
        LB2BResidentialFee,
        LB2BSubtotal,
        LB2BRejectedQty,
        LB2BRejectReason,
        LB2BReorderInProgress,
        LB2BAddingItemsToCart,
        LB2BViewCart,
        LB2BContinueShopping,
        LB2BStatus,
        LB2BAdd_All_List,
        LB2BClose,
        LB2BCreateList,
        LB2BAddtoexistingList,
        LB2BCancel,
        LB2BAdd,
        LB2BSku,
        LB2BUnitPrice,
        LB2BOrderDetailError,
        LB2BShowModal,
        LB2BTrackingNumber,
        LB2BError,
        LB2BSuccess,
        LB2BListName,
        LB2BMyLists,
        LB2BButtonCancel,
        LB2BViewAll,
        LB2BDeliveryNumber,
        LB2BNotAccess,
        LB2BOk,
        LB2BSoldToLabel,
        LB2BShipToLabel,
        LB2BSales_Order_Number,
        LB2BPONumber,
        LB2BNetAmount,
        LB2BFreight,
        LB2BNetTotal,
        LB2BShip_To,
        LB2BSold_To,
        LB2BShipProNumber,
        LB2BCarrierName,
        LB2BLargeOrderTimeoutError,
        LB2BAssignedbyTradingContract,
        LB2BDeliveryTooLate,
        LB2BCustomerRequest,
        LB2BShiporCancelRequest,
        LB2BPastCancelDate,
        LB2BDiscontinuedNoLongerAvailable,
        LB2BDiscontinuedwithReplacement,
        LB2BCustomerServiceAdjustment,
        LB2BRefusedreturnsentbacktocustomer
    };

    columnHeader = [
        this.label.LB2BSku,
        this.label.LB2BOrderQty,
        this.label.LB2BShipQty,
        this.label.LB2BEstShip,
        this.label.LB2BProductName,
        this.label.LB2BUnitPrice,
        this.label.LB2BExtPrice,
        this.label.LB2BShipDate,
        this.label.LB2BRejectedQty,
        this.label.LB2BRejectReason,
        this.label.LB2BDeliveryNumber,
        this.label.LB2BTrackingNumber,
        this.label.LB2BShipProNumber,
        this.label.LB2BCarrierName
    ];
    /**
     * The effectiveAccountId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    effectiveAccountId;

    /**
     * A wishlist summary.
     * @type {wishlist[]}
     */
    wishlist;

    /**
     * Name of the new wishlist
     * @type {String}
     */
    listname;

    /**
     * A NewWishlist Id
     * @type {String}
     */
    newWishlistId;

    /**
     * An Existing Wishlist Id
     * @type {String}
     */
    wishlistId;

    /**
     * An existing Wishlist Name
     * @type {String}
     */
    existingListName;

    // @track disabled= false;

    @track existingLists = [];
    @track openModal = false;

    data;
    uploadInfo = [];
    inputData = [];
    tableData = [];

    @track
    showTable = false;
    @track isUSA = false;
    @api soldToAccount;
    localebaseDate;
    localebaseDate1;
    @track customFormModal = false;

    /**
      * Representation of a  option.
      *
      * @typedef {Object} option
      *  *
      * @property {string} label
      * The label for the  option.
      *
      * @property {string} value
      * The value for the  option.

      */

    /**
     * A list of options useful for displaying options
     *
     * @type {option[]}
     */

    /**
     * Length of Wishlist Summaries
     * @type {Number}
     */
    currentPageReference = null;
    @api sapOrderNumber;
    existingListsLength;
    currCountry;
    isShowTrakingLink = true;

    orderDetailData;

    connectedCallback() {
        // registerListener('usa',this.countryCheck,this);
        this.isLoader = true;
        this.cartIdFromLocalStorage = localStorage.getItem('cartId');
        console.log('record id ', this.cartIdFromLocalStorage);
        console.log('Effective Account Id:', this.effectiveAccountId);
        //this.getStatus();
        this.getLists();
        this.getAgoraOrderDetail();
        if (LOCALE === 'es-MX') {
            this.isShowTrakingLink = false;
        }
    }
    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            console.log('bbbb', currentPageReference.state.orderNumber);
            this.sapOrderNumber = currentPageReference.state.orderNumber;
            this.orderType = currentPageReference.state.type;
        }
    }

    showAllSuccessMessage = true;
    @api orderStatus;
    @api _result;
    @api sapTotal = 0;
    @api sapFrieght;
    @track mapObj = [];
    @track item;
    @track listOfSKU = [];
    @track isLoader = false;
    allOrderItems;
    errorMsg;
    orderDate;
    sapSoldToAccountName;
    sapSoldStreet;
    sapSoldCity;
    sapSoldState;
    sapSoldCode;
    sapSoldCountry;
    _poNumber;
    sapShipToAccountName;
    shipStr;
    shipcity;
    shipstate;
    shipCode;
    shipcon;
    sapAccountNumber;
    subTotal = 0;
    frieghtCharge = 0;
    totalPrice = 0;
    rejectedDiscriptions;
    estShipDate;
    estShipDatee;

    // TODO Hari
    getAgoraOrderDetail() {
        agoraDetail({ orderNumber: this.sapOrderNumber })
            .then((result) => {
                console.log('result :', JSON.stringify(result));
                if (!result.isSuccess) {
                    // Do something here
                    this.isLoader = false;
                    this.customFormModal = true;
                    this.errorMsg = this.label.LB2BNotAccess;
                    console.log('Error in getOrderDetail:', result.message);
                } else {
                    this.isLoader = false;
                    this.orderDetailData = result.message;
                    console.log('agoraDetail()', this.orderDetailData);
                    const message = JSON.parse(result.message);
                    const orderHeaders = message.ORDERHEADERS;
                    let response = result.isSuccess;
                    console.log('agoraDetail response ', response);
                    const soldToInfo = message.SoldTo;
                    const shipToInfo = message.ShipTo;
                    this.allOrderItems = message.OrderItems;
                    const returnOrder = message.Return;

                    if (orderHeaders && orderHeaders.length > 0) {
                        this.orderDate = orderHeaders[0].OrderDate;
                        this._poNumber = orderHeaders[0].PONumber;
                    }

                    if (soldToInfo && soldToInfo.length > 0) {
                        this.sapSoldToAccountName = soldToInfo[0].CustName;
                        this.sapSoldStreet = soldToInfo[0].StreetAddr;
                        this.sapSoldCity = soldToInfo[0].City;
                        this.sapSoldState = soldToInfo[0].State;
                        this.sapSoldCode = soldToInfo[0].Postal;
                        this.sapSoldCountry = soldToInfo[0].Country;
                    }
                    if (this.orderDate != null && this.orderDate != undefined) {
                        let EstYear =
                            this.orderDate == undefined || null ? '' : this.orderDate.substring(0, 4);
                        let EstMonth = this.orderDate.substring(4, 6);
                        let EstDate = this.orderDate.substring(6, 8);
                        let EstimatedDateFinal = new Date(Date.UTC(EstYear, EstMonth - 1, EstDate));
                        this.localebaseDate =
                            this.sapSoldCountry === 'UNITED STATES'
                                ? new Intl.DateTimeFormat('en-US').format(EstimatedDateFinal)
                                : this.sapSoldCountry === 'MEXICO'
                                    ? new Intl.DateTimeFormat('es-MX').format(EstimatedDateFinal)
                                    : new Intl.DateTimeFormat('fr-CA').format(EstimatedDateFinal);
                    }
                    // Assinging updated Value
                    this.orderDate = this.localebaseDate;

                    if (shipToInfo && shipToInfo.length > 0) {
                        this.sapShipToAccountName = shipToInfo[0].CustName;
                        this.shipStr = shipToInfo[0].StreetAddr;
                        this.shipcity = shipToInfo[0].City;
                        this.shipstate = shipToInfo[0].State;
                        this.shipCode = shipToInfo[0].Postal;
                        this.shipcon = shipToInfo[0].Country;
                    }

                    if (this.allOrderItems && this.allOrderItems.length > 0) {
                        this.sapAccountNumber = this.allOrderItems[0].SAPAccount;
                        for (let i = 0; i < this.allOrderItems.length; i++) {
                            this.subTotal += parseFloat(this.allOrderItems[i].Subtotal);
                            this.frieghtCharge += parseFloat(this.allOrderItems[i].Freight);
                            this.totalPrice += parseFloat(this.allOrderItems[i].Total);
                            let EstimatedShipDate = this.allOrderItems[i].EstShip;
                            if (EstimatedShipDate != null && EstimatedShipDate != undefined) {
                                let EstYear =
                                EstimatedShipDate == undefined || null ? '' : EstimatedShipDate.substring(0, 4);
                                let EstMonth = EstimatedShipDate.substring(4, 6);
                                let EstDate = EstimatedShipDate.substring(6, 8);
                                let EstimatedDateFinal = new Date(Date.UTC(EstYear, EstMonth - 1, EstDate));
                                this.estShipDate =
                                this.sapSoldCountry === 'UNITED STATES'
                                        ? new Intl.DateTimeFormat('en-US').format(EstimatedDateFinal)
                                        : this.sapSoldCountry === 'MEXICO'
                                            ? new Intl.DateTimeFormat('es-MX').format(EstimatedDateFinal)
                                            : new Intl.DateTimeFormat('fr-CA').format(EstimatedDateFinal);
                            this.allOrderItems[i].EstShip = this.estShipDate;
                            }
                            let shipDate = this.allOrderItems[i].ShipDate;
                            if(shipDate == '00000000'){
                                this.allOrderItems[i].ShipDate = '';
                            }
                            else if (shipDate != null && shipDate != undefined) {
                                let EstYearr =
                                shipDate == undefined || null ? '' : shipDate.substring(0, 4);
                                let EstMonthh = shipDate.substring(4, 6);
                                let EstDatee = shipDate.substring(6, 8);
                                let EstimatedDateFinall = new Date(Date.UTC(EstYearr, EstMonthh - 1, EstDatee));
                                this.estShipDatee =
                                this.sapSoldCountry === 'UNITED STATES'
                                        ? new Intl.DateTimeFormat('en-US').format(EstimatedDateFinall)
                                        : this.sapSoldCountry === 'MEXICO'
                                            ? new Intl.DateTimeFormat('es-MX').format(EstimatedDateFinall)
                                            : new Intl.DateTimeFormat('fr-CA').format(EstimatedDateFinall);
                             this.allOrderItems[i].ShipDate = this.estShipDatee;
                            }

                            let rejectedQuantity = this.allOrderItems[i].RejectedQty;
                            console.log('Rejected quantity is : ',rejectedQuantity);
                            if( rejectedQuantity == 0)
                            {
                                this.allOrderItems[i].showField = true;
                                this.hideRejectedReason = true;
                            }

                            let rejectionCode = this.allOrderItems[i].ReasonRejected;
                            console.log('rejection code:', rejectionCode);
                            if (rejectionCode != null || undefined) {
                                switch (rejectionCode) {
                                    case '':
                                        this.rejectedDiscriptions = '';
                                        break;
                                    case '00':
                                        this.rejectedDiscriptions = LB2BAssignedbyTradingContract;
                                        break;
                                    case '01':
                                        this.rejectedDiscriptions = LB2BDeliveryTooLate;
                                        break;
                                    case '02':
                                        this.rejectedDiscriptions = LB2BCustomerRequest;
                                        break;
                                    case '03':
                                        this.rejectedDiscriptions = LB2BShiporCancelRequest;
                                        break;
                                    case '04':
                                        this.rejectedDiscriptions = LB2BPastCancelDate;
                                        break;
                                    case '05':
                                        this.rejectedDiscriptions = LB2BDiscontinuedNoLongerAvailable;
                                        break;
                                    case '06':
                                        this.rejectedDiscriptions = LB2BDiscontinuedwithReplacement;
                                        break;
                                    case '07':
                                        this.rejectedDiscriptions = LB2BCustomerServiceAdjustment;
                                        break;
                                    case '08':
                                        this.rejectedDiscriptions = LB2BRefusedreturnsentbacktocustomer;
                                        break;
                                    case '09':
                                        this.rejectedDiscriptions = LB2BProductnotreceivedinreturnshipment;
                                        break;
                                    case '10':
                                        this.rejectedDiscriptions = LB2BInvalidClaim;
                                        break;
                                    case '11':
                                        this.rejectedDiscriptions = LB2BItemnotreturned;
                                        break;
                                    case '12':
                                        this.rejectedDiscriptions = LB2BDiscorderthroughproductservice;
                                        break;
                                    case '13':
                                        this.rejectedDiscriptions = LB2BCancelledpersalesrep;
                                        break;
                                    case '14':
                                        this.rejectedDiscriptions = LB2BMovedtoproductservicesystem;
                                        break;
                                    case '15':
                                        this.rejectedDiscriptions = LB2BDiscontinuedNoSubstitutionAllowed;
                                        break;
                                    case '16':
                                        this.rejectedDiscriptions = LB2BShiporCancelInventoryIssue;
                                        break;
                                    case '17':
                                        this.rejectedDiscriptions = LB2BDeletedandMovedtoNewOrder;
                                        break;
                                    case '18':
                                        this.rejectedDiscriptions = LB2BSuspendedNoInventoryAvailable;
                                        break;
                                    case '19':
                                        this.rejectedDiscriptions = LB2BCancelledPricingissueunresolved;
                                        break;
                                    case '20':
                                        this.rejectedDiscriptions = LB2BCancelledReconcancelpolicy;
                                        break;
                                    case '21':
                                        this.rejectedDiscriptions = LB2BRBOMIncorrectQty;
                                        break;
                                    case '22':
                                        this.rejectedDiscriptions = LB2BCustomerError;
                                        break;
                                    case '23':
                                        this.rejectedDiscriptions = LB2BProductNotAvailable;
                                        break;
                                    case '24':
                                        this.rejectedDiscriptions = LB2BInventorynotavailableWalmartDSDC;
                                        break;
                                    case '25':
                                        this.rejectedDiscriptions = LB2BCustomeragreedtocxnoinvy;
                                        break;
                                    case '26':
                                        this.rejectedDiscriptions = LB2BCoilDifferentialAllowance;
                                        break;
                                    case '27':
                                        this.rejectedDiscriptions = LB2BAutoRejectedOldLine;
                                        break;
                                    case '28':
                                        this.rejectedDiscriptions = LB2BAutoRejectPricing;
                                        break;
                                    case '41':
                                        this.rejectedDiscriptions = LB2BOutofPolicyDateCode;
                                        break;
                                    case '42':
                                        this.rejectedDiscriptions = LB2BMissingTool;
                                        break;
                                    case '43':
                                        this.rejectedDiscriptions = LB2BMissingBattery;
                                        break;
                                    case '44':
                                        this.rejectedDiscriptions = LB2BMissingCharger;
                                        break;
                                    case '45':
                                        this.rejectedDiscriptions = LB2BMissingParts;
                                        break;
                                    case '46':
                                        this.rejectedDiscriptions = LB2BSwappedparts;
                                        break;
                                    case '47':
                                        this.rejectedDiscriptions = LB2BAbuse;
                                        break;
                                    case 'CA':
                                        this.rejectedDiscriptions = LB2BCancelledAddNewLineforSub;
                                        break;
                                    case 'CC':
                                        this.rejectedDiscriptions = LB2BCanceledforsystemconversion;
                                        break;
                                    case 'CD':
                                        this.rejectedDiscriptions = LB2BCancelledduetosingledelivery;
                                        break;
                                    case 'CI':
                                        this.rejectedDiscriptions = LB2BCancelledduetosingleinvoicing;
                                        break;
                                    case 'CR':
                                        this.rejectedDiscriptions = LB2BCreditReasons;
                                        break;
                                    case 'CU':
                                        this.rejectedDiscriptions = LB2BCreditMemoCleanup;
                                        break;
                                    case 'DS':
                                        this.rejectedDiscriptions = LB2BDeallocateStock;
                                        break;
                                    case 'ES':
                                        this.rejectedDiscriptions = LB2BShouldhavebeenanEstimate;
                                        break;
                                    case 'RR':
                                        this.rejectedDiscriptions = LB2BReturnedNotRepaired;
                                        break;
                                    case 'SR':
                                        this.rejectedDiscriptions = LB2BSRDPlndOrd;
                                        break;
                                    case 'TL':
                                        this.rejectedDiscriptions = LB2BExceedsTLConstraintsCustSvcAdj;
                                        break;
                                    case 'UA':
                                        this.rejectedDiscriptions = LB2BStatisticalUseUltimusApproval;
                                        break;
                                    case 'Z1':
                                        this.rejectedDiscriptions = LB2BCoilDifferentialAllowance;
                                        break;
                                    case 'Z2':
                                        this.rejectedDiscriptions = LB2BCancelledDuetoUnshippedin7days;
                                        break;
                                    default:
                                        this.rejectedDiscriptions = 'others';
                                        break;
                                }
                            }
                            console.log('rejection reason:', this.rejectedDiscriptions); 
                           this.allOrderItems[i].ReasonRejected = this.rejectedDiscriptions != undefined ? this.rejectedDiscriptions : '';
                         //  this.allOrderItems[i].ReasonRejected = this.rejectedDiscriptions;

                            this.uploadInfo.push({
                                sku:  this.allOrderItems[i].SKU,
                                quantity:  this.allOrderItems[i].OrderQTY
                            });
                        }
                        this.frieghtCharge = parseFloat(this.frieghtCharge).toFixed(2);
                        this.subTotal = parseFloat(this.subTotal).toFixed(2);
                        this.totalPrice = parseFloat(this.totalPrice).toFixed(2);
                        
                    }

                    if (returnOrder && returnOrder.length > 0) {
                        this.customFormModal = true;
                        this.errorMsg = this.label.LB2BNotAccess;
                        console.log('Error in getOrderDetail:', this.errorMsg);
                    }


                }
            })
            .catch((error) => {
                console.error('agoraDetail()', error);
            });
    }

    trackTrackingInfo(event) {
        let trackingNumber = event.currentTarget.dataset.value;
        let trackingUrl = event.target.href;
        OrderTracking('order_tracking', trackingNumber, trackingUrl);
    }

    customDelete(event) {
        this.customFormModal = false;
        window.history.back();
    }

    exportToExcel() {
        console.log('inside method: ', this.allOrderItems);

        for (let i = 0; i < this.allOrderItems.length; i++) {
            this.sapTotal += this.allOrderItems[i].Total;
            this.sapFrieght += this.allOrderItems[i].Freight;
        }
        this.sapTotal = parseFloat(this.sapTotal).toFixed(2);
        this.sapFrieght = parseFloat(this.sapFrieght).toFixed(2);

        // Prepare a html table

        let doc = '';
        doc += '<table>';
        doc += '<style>';
        doc += 'table, td {';
        doc += 'text-align : left;';
        doc += '}';
        doc += '</style>';
        doc += '<tr>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BSold_To + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this.sapSoldToAccountName + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BShip_To + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this.sapShipToAccountName + '<br>';
        doc += '</td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this.sapSoldCity + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this.shipcity + '<br>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this.sapSoldCode + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this.shipCode + '<br>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this.sapSoldCountry + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += this.shipcon + '<br>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BSales_Order_Number + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this.sapOrderNumber + '<br>';
        doc += '<td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BPONumber + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this._poNumber + '<br>';
        doc += '</td>';
        doc += '<td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BNetTotal + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += this.sapTotal + '<br>';
        doc += '</td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>';
        doc += '';
        doc += '</td>';
        doc += '<td>' + '<b>';
        doc += this.label.LB2BFreight + ':';
        doc += '</b>' + '</td>';
        doc += '<td>';
        doc += '&nbsp;' + this.sapFrieght + '</br>';
        doc += '</td>';
        doc += '</tr>';
        doc += '<tr>';
        doc += '';
        doc += '</tr>';
        doc += '</table>';
        doc += '<table>';
        // Add styles for the table
        doc += '<style>';
        doc += 'table, th, td {';
        doc += '    border: 1px solid black;';
        doc += '    border-collapse: collapse;';
        doc += '    text-align: center;';
        doc += '}';
        doc += '</style>';
        // Add all the Table Headers
        doc += '<tr>';
        this.columnHeader.forEach((element) => {
            doc += '<th>' + element + '</th>';
        });
        doc += '</tr>';
        // Add the data rows
        this.allOrderItems.forEach((record) => {
            if (record) {
                doc += '<tr>';
                doc += '<th>' + record.SKU + '</th>';
                doc += '<th>' + record.OrderQTY + '</th>';
                doc += '<th>' + record.ShipQTY + '</th>';
                doc += '<th>' + record.EstShip + '</th>';
                doc += '<th>' + record.ProductName + '</th>';
                doc += '<th>' + record.UnitPrice + '</th>';
                doc += '<th>' + record.ExtPrice + '</th>';
                doc += '<th>' + record.ShipDate + '</th>';
                if (record.RejectedQty !== null) {
                    doc += '<th>' + record.RejectedQty + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                if (record.ReasonRejected) {
                    doc += '<th>' + record.ReasonRejected + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                if (record.Tracking) {
                    doc += '<th>' + record.Tracking + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                if (record.Deliverynumber) {
                    doc += '<th>' + record.Deliverynumber + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                if (record.ShipPro !== null) {
                    doc += '<th>' + record.ShipPro + '</th>';
                } else {
                    doc += '<th>' + '</th>';
                }
                doc += '<th>' + record.CarrierName + '</th>';

                doc += '</tr>';
            } else {
                doc += '<th>' + '</th>';
            }
        });
        doc += '</table>';
        var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
        let downloadElement = document.createElement('a');
        downloadElement.href = element;
        downloadElement.target = '_self';
        // use .csv as extension on below line if you want to export data as csv
        downloadElement.download = 'Order Detail List.xls';
        document.body.appendChild(downloadElement);
        downloadElement.click();
    }

    handleAccrdionTable(event) {
        let accordionBtns = this.template.querySelectorAll('.accordion');
        accordionBtns.forEach((item) => {
            item.addEventListener('click', () => {
                item.parentElement.parentElement.classList.contains('is-open')
                    ? item.parentElement.parentElement.classList.remove('is-open')
                    : item.parentElement.parentElement.classList.add('is-open');
            });
        });
    }

    handleViewAll(e) {
        let viewAllStatus = e.target.checked;
        let viewAllTable = this.template.querySelector('.order-table-container');
        viewAllStatus
            ? viewAllTable.classList.add('show-all-table')
            : viewAllTable.classList.remove('show-all-table');
    }

    renderedCallback() {
        this.handleAccrdionTable();
        loadStyle(this, GlobalCSS);
    }

    //Boolean tracked variable to indicate if modal is open or not default value is false as modal is closed when page is loaded
    @track isModalOpen = false;
    openModalForList() {
        // to open modal set isModalOpen track value as true
        this.isModalOpen = true;
    }
    closeModalForList() {
        // to close modal set isModalOpen track value as false
        this.isModalOpen = false;
    }

    /*Handle Radio button Change */
    @track createListValue = true;
    @track addToListValue = false;

    handleRadioChange(event) {
        let selectedOption = event.target.value;
        if (selectedOption == 'createList') {
            this.createListValue = true;
        } else {
            this.createListValue = false;
        }
        if (selectedOption == 'addToList') {
            this.addToListValue = true;
        } else {
            this.addToListValue = false;
        }
    }

    //Gets all the wishlist summaries if any
    @track showExistingLists = false;
    getLists() {
        getWishlistSummaries({
            communityId,
            effectiveAccountId: this.effectiveAccountId
        }).then((result) => {
            this.data = JSON.parse(JSON.stringify(result));

            let listOption = [];

            this.existingListsLength = result.summaries.length;

            for (let i = 0; i < this.existingListsLength; i++) {
                this.existingListName = result.summaries[i].name;

                listOption.push({
                    label: this.existingListName
                        .replace('&amp;', '&')
                        .replace('&lt;/p&gt;', '')
                        .replace('&amp;amp;', '&')
                        .replace('&amp;#39;', "'"),
                    value: this.existingListName
                });
            }
            this.existingLists = listOption;
            //console.log("ExlistOptions:" ,JSON.parse(JSON.stringify(this.existingLists)));

            if (this.existingLists != 0) {
                this.showExistingLists = true;
            }
        });
    }

    /*Handle Existing Lists Dropdown*/
    handleExistingLists(event) {
        this.value = event.detail.value;
    }

    get options() {
        return this.existingLists;
    }

    handleCreateList() {
        this.isModalOpen = false;

        if (this.createListValue == true) {
            this.listname = this.template.querySelector(`[data-id = "newlist"]`).value;

            createWishlist({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                listname: this.listname
            })
                .then((result) => {
                    this.wishlist = result.summary;
                    this.newWishlistId = result.summary.id;

                    addItemsToWishlist({
                        communityId,
                        effectiveAccountId: this.effectiveAccountId,
                        wishlistId: this.newWishlistId,
                        skuList: JSON.stringify(this.listOfSKU)
                    })
                        .then((result) => {
                            console.log('Add Items To List:', result);
                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: this.label.LB2BSuccess,
                                    message: 'Products Added to Wishlist',
                                    variant: 'success',
                                    mode: 'dismissable'
                                })
                            );
                        })
                        .catch((error) => {
                            let message = this.label.LB2BOrderDetailError;
                            console.log('Error Msg:', message);

                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: 'Error',
                                    message: message,
                                    variant: 'error',
                                    mode: 'dismissable'
                                })
                            );
                        });
                })
                .catch((error) => {
                    let message = error.body.message;
                    console.log('Error Msg:', message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }

        if (this.addToListValue == true) {
            let lName = this.template.querySelector(`[data-id = "existinglist"]`).value;

            let id;
            for (let i = 0; i < this.existingListsLength; i++) {
                if (this.data.summaries[i].name == lName) {
                    id = this.data.summaries[i].id;
                }
            }
            this.wishlistId = id;
            console.log('WishlistId: ', this.wishlistId);

            addItemsToWishlist({
                communityId,
                effectiveAccountId: this.effectiveAccountId,
                wishlistId: this.wishlistId,
                skuList: JSON.stringify(this.listOfSKU)
            })
                .then((result) => {
                    console.log('Add Items To List:', result);
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Products Added to Wishlist',
                            variant: 'success',
                            mode: 'dismissable'
                        })
                    );
                })
                .catch((error) => {
                    let message = this.label.LB2BOrderDetailError;
                    console.log('Error Msg:', message);

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }
    }

    addItemsToCart() {
        var dataSet = JSON.stringify(this.uploadInfo);
        this.isLoader = true;

        if (this.uploadInfo.length != 0) {
            addToCart({
                data: dataSet,
                communityId: communityId,
                effectiveAccountId: this.effectiveAccountId,
                isChecked: false
            })
                .then((result) => {
                    this.isLoader = false;
                    this.showAllSuccessMessage = true;
                    if (result.isSuccess) {
                        console.log('resultcart:', result.data);
                        if (this.showAllSuccessMessage) {
                            if (
                                result.data.every((element) => {
                                    return element.isSuccess === false;
                                })
                            ) {
                                this.showAllSuccessMessage = false;
                                const event = new ShowToastEvent({
                                    title: this.label.LB2BError,
                                    message: LB2BReorderAllSkuNotexist,
                                    variant: 'error',
                                    mode: 'dismissable'
                                });
                                this.dispatchEvent(event);
                                return;
                            } else {
                                result.data.forEach((element) => {
                                    if (!element.isSuccess) {
                                        this.showAllSuccessMessage = false;
                                        const event = new ShowToastEvent({
                                            title: this.label.LB2BError,
                                            message: LB2BOrderDetailError,
                                            variant: 'error',
                                            mode: 'dismissable'
                                        });
                                        this.dispatchEvent(event);
                                        return;
                                    }
                                });
                            }
                        }
                        result.data.forEach((element) => {
                            let item = {};
                            item.sku = element.sku;
                            item.qty = element.quantity;
                            item.notes = element.message;
                            item.notesColor = element.isSuccess ? '' : 'slds-text-color_error';
                            this.inputData.push(item);
                            this.cartIdNew = element.cartId != undefined ? element.cartId : '';
                        });
                        if (this.showAllSuccessMessage) {
                            this.openModal = true;
                        }

                        this.tableData = this.inputData;
                        if (this.tableData.length > 0) {
                            this.showTable = true;
                        }

                        this.dispatchEvent(
                            new CustomEvent('cartchanged', {
                                bubbles: true,
                                composed: true
                            })
                        );
                    } else {
                        toastUtil.toastError(this, { message: result.message });
                        this.dispatchEvent(
                            new ShowToastEvent({
                                title: this.label.LB2BError,
                                message: result.message,
                                variant: 'error',
                                mode: 'dismissable'
                            })
                        );
                    }

                    if (this.orderType === 'QUOTE') {
                        addQuoteNumber({
                            cartId: result.data[0].cartId,
                            quoteNumber: this.sapOrderNumber
                        });
                    }
                })
                .catch((error) => {
                    this.isLoader = false;
                    let message = error && error.body && error.body.message;
                    toastUtil.toastError(this, { message: message });
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.label.LB2BError,
                            message: message,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                });
        }
    }

    closeModal() {
        this.openModal = false;
    }

    backToCartPage() {
        var pathname = new URL(window.location.href).pathname.split('?orderNumber');
        this.navigateToWebPage(pathname[0]);
        //toastUtil.toastSuccess(this, { message: LB2BReorderSuccessMsg });
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url.replace('/sap-order-detail', '/cart/' + this.cartIdNew)
            }
        });
    }
}