import LB2BOrderSummary from '@salesforce/label/c.LB2BOrderSummary';
import LB2BAccount from '@salesforce/label/c.LB2BAccount';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BBrand from '@salesforce/label/c.LB2BBrand';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BMultipleLocation from '@salesforce/label/c.LB2BMultipleLocation';
import LB2BSubtotal from '@salesforce/label/c.LB2BSubtotal';
import LB2BFreight from '@salesforce/label/c.LB2BFreight';
import LB2BResidentialFee from '@salesforce/label/c.LB2BResidentialFee';
import LB2BLiftFee from '@salesforce/label/c.LB2BLiftFee';
import LB2BTotal from '@salesforce/label/c.LB2BTotal';
import LB2BSavings from '@salesforce/label/c.LB2BSavings';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BQty from '@salesforce/label/c.LB2BQty';
import LB2BUnitPrice from '@salesforce/label/c.LB2BUnitPrice';
import LB2BTotalPrice from '@salesforce/label/c.LB2BTotalPrice';
import LB2BQuote from '@salesforce/label/c.LB2BQuote';
import LB2BQuoteDate from '@salesforce/label/c.LB2BQuoteDate';
import LB2BItems from '@salesforce/label/c.LB2BItems';
import LB2BEstimatedShip from '@salesforce/label/c.LB2BEstimatedShip';
import LB2BQtyMissMatchError from '@salesforce/label/c.LB2BQtyMissMatchError';
import LB2BTo from '@salesforce/label/c.LB2BTo';
import LB2BPendingInventory from '@salesforce/label/c.LB2BPendingInventory';
import LB2BFree from '@salesforce/label/c.LB2BFree';
import LB2BSubstituteProductsMsg from '@salesforce/label/c.LB2BSubstituteProductsMsg';
import LB2BFooter_Line from '@salesforce/label/c.LB2BFooter_Line';
import LB2BFooter_Line_enUS from '@salesforce/label/c.LB2BFooter_Line_enUS';
import LB2BFooter_Line_frCA from '@salesforce/label/c.LB2BFooter_Line_frCA';
import LB2BFooter_Line_esMX from '@salesforce/label/c.LB2BFooter_Line_esMX';
import LB2BPer from '@salesforce/label/c.LB2BPer';

export function getQuotePdf(cartItems, base64Data, date, summary, brand, sbdLogo, locale, isOrderHistory) {
 console.log('base64Data', base64Data);
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({});

    let currency;
    let numberFormat;
    if (locale == 'es_MX') {
        //TODO:For MX User
        currency = 'USD';
        numberFormat = 'en-US';
    } else if (locale == 'fr' || locale == 'fr_CA') {
        currency = 'CAD';
        numberFormat = 'fr-CA';
    } else {
        currency = 'USD';
        numberFormat = 'en-US';
    }

    const numberFormatter = new Intl.NumberFormat(numberFormat, {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2
    });
    let plantName;

    doc.addImage(sbdLogo, 'png', 8, 6, 22, 8);
    doc.setLineWidth(0.001);
    doc.setDrawColor(169, 169, 169);
    doc.line(8, 16, 202, 16);

    let height = 50;

    doc.setFontSize(30);
    doc.setFont('Montserrat', 'bold');
    doc.text(LB2BQuote, 8, 28);

    doc.setFontSize(18);
    doc.setFont('Montserrat', 'bold');
    doc.text(LB2BQuoteDate + ' : ' + date, 8, 38);

    doc.setFontSize(18);
    doc.setFont('Montserrat', 'bold');
    doc.text(LB2BItems, 8, 50);

    height += 5;
    doc.setLineWidth(0.001);
    doc.setDrawColor(169, 169, 169);
    doc.line(8, 51, 150, 51);

    //Order Summary Box
    doc.rect(152, 30, 50, 130);
    doc.setFontSize(12);
    doc.setFont('Montserrat', 'bold');
    const orderSummary = doc.splitTextToSize(LB2BOrderSummary, 48);
    doc.text(orderSummary, 154, 37);
    doc.line(152, 45, 202, 45);

    doc.setFontSize(10);
    doc.setFont('Montserrat', 'bold');
    doc.text(LB2BAccount, 154, 50);

    let lineHeight = 50;
    doc.setFontSize(10);
    doc.setFont("Montserrat", "normal");
    let splitText;
    isOrderHistory === false ? splitText = doc.splitTextToSize(summary.Sold_To_SAP_Account__r.Name, 50) : splitText = doc.splitTextToSize(summary.Sold_To_SAP_Account__r.PartnerName, 50);
    doc.text(splitText, 154, lineHeight + 5);
    for (let i = 0; i < splitText.length; i++) {
        lineHeight += 5;
    }
   // doc.text(summary.Sold_To_SAP_Account__r.Name, 154, 54);
    isOrderHistory === false ? doc.text(LB2BSold_To + ' #: ' + summary.ensxb2b__sap_BillTo_PartnerNumber__c, 154, lineHeight+4) :  doc.text(LB2BSold_To + ' #: ' + summary.Sold_To_SAP_Account__r.PartnerNumber, 154, lineHeight+4);
    doc.text(LB2BBrand + ' : ' + (brand!=undefined ? brand :''), 154, lineHeight+8);

    doc.setFontSize(10);
    doc.setFont('Montserrat', 'bold');
    doc.text(LB2BShip_To + ':', 154, lineHeight + 16);
     
    if (summary.Ship_To_SAP_Account__r !== undefined) {      
        let splitText;
        isOrderHistory === false ? splitText =doc.splitTextToSize(summary.Ship_To_SAP_Account__r.Name, 50) : splitText = doc.splitTextToSize(summary.Ship_To_SAP_Account__r.PartnerName, 50);
        doc.setFontSize(10);
        doc.setFont('Montserrat', 'normal');
        doc.text(splitText, 154, lineHeight + 21);
        for (let i = 0; i < splitText.length; i++) {
            lineHeight = lineHeight + 5;
        }
        
       // doc.text(summary.Ship_To_SAP_Account__r.Name, 154, 82);
       //const splitStreet = doc.splitTextToSize(summary.Ship_To_SAP_Account__r.Street__c, 50);
        let splitStreet;
        isOrderHistory === false ? splitStreet = doc.splitTextToSize(summary.Ship_To_SAP_Account__r.Street__c, 50) : splitStreet = doc.splitTextToSize(summary.Ship_To_SAP_Account__r.Street, 50);
        doc.text(splitStreet, 154, lineHeight+20);
        for(let i=0; i<splitStreet.length; i++){     
            lineHeight = lineHeight + 5;
        }
        if(isOrderHistory){ 
            doc.text(summary.Ship_To_SAP_Account__r.City, 154, lineHeight+20);
            doc.text(summary.Ship_To_SAP_Account__r.PostalCode, 154, lineHeight+29);
            doc.text(summary.Ship_To_SAP_Account__r.Country, 154, lineHeight+33);
        } else { 
            doc.text(summary.Ship_To_SAP_Account__r.City__c, 154, lineHeight+20);
            doc.text(summary.Ship_To_SAP_Account__r.State__c, 154, lineHeight+25);
            doc.text(summary.Ship_To_SAP_Account__r.Postal_Code__c, 154, lineHeight+29);
            doc.text(summary.Ship_To_SAP_Account__r.Country__c, 154, lineHeight+33);
        }
    } else {
        doc.setFontSize(10);
        doc.setFont('Montserrat', 'normal');
        doc.text(LB2BMultipleLocation, 154, lineHeight + 21);
    }

    doc.line(154, lineHeight + 38, 200, lineHeight + 38);
    doc.text(LB2BSubtotal, 154, 125);
    doc.text(LB2BFreight, 154, 132);

    doc.setFontSize(10);
    doc.setFont('Montserrat', 'bold');
    doc.text(LB2BTotal, 154, 139);
    isOrderHistory == false ? doc.text(numberFormatter.format(summary.LB2B_Total__c.toFixed(2)).toString(), 200, 139, "right") : doc.text(numberFormatter.format(summary.LB2B_Total__c.toFixed(2)).toString(), 200, 139, "right");
    
    doc.setFont("Montserrat", "normal");
    isOrderHistory == false ? doc.text(numberFormatter.format(summary.LB2B_SubTotal__c.toFixed(2)).toString(), 200, 125, "right"): doc.text(numberFormatter.format(summary.SubTotal__c.toFixed(2)).toString(), 200, 125, "right");
    isOrderHistory == false ? doc.text(numberFormatter.format(summary.Freight__c.toFixed(2)).toString(), 200, 132, "right") : doc.text(numberFormatter.format(summary.Freight__c), 200, 132, "right");

    // cart items
    for (let i = 0; i < cartItems.length; i++) {
        var pageHeight = doc.internal.pageSize.getHeight();
        height += 5;
        doc.setFontSize(8);
        doc.setFont('Montserrat', 'normal');
        doc.setTextColor(0, 0, 0);
        if (cartItems[i].brandName !== undefined) {
            doc.text(cartItems[i].brandName, 30, height);
        }

        doc.addImage(base64Data[i], 'png', 8, height, 22, 8);  //Product image
        doc.setFont('Montserrat', 'normal');
        doc.text(LB2BUnitPrice + ':', 85, height);

        doc.setFont('Montserrat', 'bold');
        doc.text(LB2BQty + ' : ', 110, height);

        doc.setFont('Montserrat', 'normal');
        doc.text(LB2BTotalPrice + ' :', 130, height);

        if (height > 285) {
            doc.addPage();
            height = 10;
        }

        height += 5;
        isOrderHistory === false ? doc.text(numberFormatter.format(cartItems[i].unitPrice.toFixed(2)).toString() + 
            (cartItems[i].unitOfMeasure ? ' ' + LB2BPer + ' ' + cartItems[i].conditionPrcingUnit: ''), 85, height) :
            doc.text(numberFormatter.format(cartItems[i].NetItemPrice)+
            (cartItems[i].unitOfMeasure ? ' ' + LB2BPer + ' ' + cartItems[i].conditionPrcingUnit: ''), 85, height);

        if (cartItems[i].hasRoundedQuantity == false) {
            // Qty
            doc.text(cartItems[i].oldQuantity.toString(), 110, height);
        } else {
            isOrderHistory === false ? doc.text(cartItems[i].oldQuantity.toString(), 110, height) : doc.text(cartItems[i].OrderQuantity.toString(), 110, height); //strikeThrough qty
            let _data;
            isOrderHistory === false ? _data = cartItems[i].oldQuantity.toString() : _data =cartItems[i].OrderQuantity.toString();
            doc.setTextColor(0);
            // doc.line(120, height - 6, 130 + (_data.length), height - 6);
            doc.setLineWidth(0.001);
            doc.setDrawColor(169, 169, 169);
            doc.line(110, height - 1, 114 + _data.length, height - 1);

            doc.setTextColor(179, 0, 0);
            isOrderHistory === false ? doc.text(cartItems[i].quantity.toString(), 110, height + 5) : doc.text(cartItems[i].OrderQuantity.toString(), 110, height + 5); // qty in red color
            if (height > 285) {
                doc.addPage();
                height = 10;
            }
        }

        cartItems[i].hasRoundedQuantity ? doc.setTextColor(179, 0, 0) : doc.setTextColor(0, 0, 0);
        isOrderHistory === false ? doc.text(numberFormatter.format(cartItems[i].extendedPrice.toFixed(2)).toString(), 130, height) : doc.text(numberFormatter.format(cartItems[i].NetValueInDocumentCurrency), 130, height);

        doc.setTextColor(0, 0, 0);
        doc.setFontSize(10);
        doc.setFont("Montserrat", "bold");
        let splitText;
        if(!isOrderHistory){
             splitText = doc.splitTextToSize((cartItems[i].oldProductName).replace('ˮ','"'), 50);
        } else {
             splitText = doc.splitTextToSize((cartItems[i].ItemDescription).replace('ˮ','"'), 50);
        }
        doc.text(splitText, 30, height);
        if (height > 285) {
            doc.addPage();
            height = 10;
        }

        splitText.forEach(() => {
            height += 4;
        });
        doc.setFontSize(8);
        doc.setFont("Montserrat", "normal");
        isOrderHistory === false ? doc.text(LB2BSku + ' # ' + cartItems[i].oldProductSku, 30, height) : doc.text(LB2BSku + ' # ' + cartItems[i].MaterialEntered, 30, height);
        if (height > 285) {
            doc.addPage();
            height = 10;
        }

        // Rounded Quantity
        if (cartItems[i].hasRoundedQuantity) {
            height += 5;
            doc.setTextColor(179, 0, 0);
            doc.text(
                LB2BQtyMissMatchError +
                    ' ' +
                    cartItems[i].oldQuantity.toString() +
                    ' ' +
                    LB2BTo +
                    ' ' +
                    cartItems[i].quantity.toString(),
                30,
                height
            );
            if (height > 285) {
                doc.addPage();
                height = 10;
            }
        }

        if(!isOrderHistory){
        //Shipment List or Multiple shipment
            if ((cartItems[i].shipmentList).length >= 1) {
                for (let j = 0; j < cartItems[i].shipmentList.length; j++) {
                    height += 2;
                    plantName = cartItems[i].shipmentList[j].plantName;
                    if (cartItems[i].shipmentList[j].isPendingAvailability == false) {
                        height += 2;
                        // const splitDate = doc.splitTextToSize(LB2BQty +' : ' + (cartItems[i].shipmentList[j].shipQuantity).toString() +' - '+ LB2BEstimatedShip+' : ' + cartItems[i].shipmentList[j].estimatedShipDate,35);
                        doc.setTextColor(0, 0, 0)
                        doc.text(LB2BQty + ' : ' + (cartItems[i].shipmentList[j].shipQuantity).toString() + ' - ' + LB2BEstimatedShip + ' : ' + cartItems[i].shipmentList[j].estimatedShipDate +' - ', 30, height);

                        doc.setTextColor(74,127,175);
                    
                        doc.text( cartItems[i].shipmentList[j].plantName,30,height+4);
                        if (height > 285) {
                            doc.addPage();
                            height = 10;
                        }
                    } else {
                        height += 2;
                        doc.setTextColor(0, 0, 0)
                        doc.text(LB2BQty + ' : ' + (cartItems[i].shipmentList[j].shipQuantity).toString() + ' - ' + LB2BPendingInventory, 30, height);
                    }
                    if (height > 285) {
                        doc.addPage();
                        height = 10;
                    }
                }
            }

            //SublineList
            if ((cartItems[i].shipmentList).length >= 1) {
                for (let k = 0; k < cartItems[i].sublineList.length; k++) {
                    for (let l = 0; l < cartItems[i].sublineList[k].shipmentList.length; l++) {
                        height += 5;
                        doc.line(8, height, 80, height);
                        if (height > 285) {
                            doc.addPage();
                            height = 10;
                        }
                        height += 4;
                        doc.setTextColor(0,0,0);
                        doc.text(LB2BSku + '#: ' + cartItems[i].sublineList[k].productSku, 8, height);
                        if (height > 285) {
                            doc.addPage();
                            height = 10;
                        }
                        if (cartItems[i].sublineList[k].shipmentList[l].isPendingAvailability == false) {
                            height += 4;
                            doc.text(LB2BQty + ': ' + cartItems[i].sublineList[k].shipmentList[l].shipQuantity + ' - ' + LB2BEstimatedShip + ':' + cartItems[i].sublineList[k].shipmentList[l].estimatedShipDate, 30, height);
                            // if (height > 285) {
                            //     alert('page add')
                            //     doc.addPage();
                            //     height = 10;
                            // }
                        } else {
                            height += 4;
                            doc.text(LB2BQty + ': ' + cartItems[i].sublineList[k].shipmentList[l].shipQuantity + ' - ' + LB2BPendingInventory, 30, height);
                        }
                        console.log('height of page11 : ', height)
                        if (height > 285) {
                            doc.addPage();
                            height = 10;
                        }
                        // if (height-10 > pageHeight) {
                        //     height=10;
                        //     doc.addPage();
                        // }
                    }
                }
            }
        }

        //FreeGoods Message
        if (cartItems[i].hasFreeGoods) {
            height += 5;
            doc.text(LB2BFree, 30, height);
            if (height > 285) {
                doc.addPage();
                height = 10;
            }
        }

        //hasSubstitute Product
        if (cartItems[i].hasSubstituteProducts) {
            height += 5;
            doc.text(
                cartItems[i].oldProductSku +
                    ' ' +
                    LB2BSubstituteProductsMsg +
                    ' ' +
                    cartItems[i].productSku,
                30,
                height
            );
            if (height > 285) {
                doc.addPage();
                height = 10;
            }
        }

        height += plantName != undefined ? 9 : 5;
        doc.line(8, height + 1, 150, height + 1);
        if (height > 285) {
            doc.addPage();
            height = 10;
        }

        height += 5;

        console.log('height of page 22 : ', pageHeight);
        console.log('height last   : ', height);
        // if (height > pageHeight - 12) {
        //     height=10;
        //     doc.addPage();
        // }
        if (height > 285) {
            doc.addPage();
            height = 10;
        }
    }

    doc.setTextColor(0, 0, 0);

    let footerText = '';
    if (locale === 'es-MX') {
        footerText = LB2BFooter_Line_esMX;
    }
    else if (locale === 'fr-CA') {
        footerText = LB2BFooter_Line_frCA;
    }
    else if (locale === 'en-US') {
        footerText = LB2BFooter_Line_enUS;
    }
    else {
        footerText = LB2BFooter_Line;
    }
    doc.text(footerText, 8, height);
    if (height > 285) {
        doc.addPage();
        height = 10;
    }
    console.log('doc save', doc);
    doc.save('quote.pdf');
}