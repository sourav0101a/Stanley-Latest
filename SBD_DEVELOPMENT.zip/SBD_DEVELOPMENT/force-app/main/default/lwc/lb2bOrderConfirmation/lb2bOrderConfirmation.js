/**
 * This component display the Account details, shipping addrss, total number of cart items
 * and total amount of product
 */

 import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
 import getSapTotal from '@salesforce/apex/LB2BCartController.getSapTotal';
 import LB2BContactName from '@salesforce/label/c.LB2BContactName';
 import LB2BDropShipAddress from '@salesforce/label/c.LB2BDropShipAddress';
 import LB2BEstimatedShipDate from '@salesforce/label/c.LB2BEstimatedShipDate';
 import LB2BFreight from '@salesforce/label/c.LB2BFreight';
 import LB2BLiftFee from '@salesforce/label/c.LB2BLiftFee';
 import LB2BOrderDate from '@salesforce/label/c.LB2BOrderDate';
 import LB2BOrderDetails from '@salesforce/label/c.LB2BOrderDetails';
 import LB2BOrderSumm from '@salesforce/label/c.LB2BOrderSumm';
 import LB2BPackingDeliveryInstructions from '@salesforce/label/c.LB2BPackingDeliveryInstructions';
 import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
 import LB2BReference from '@salesforce/label/c.LB2BReference';
 import LB2BResidentialFee from '@salesforce/label/c.LB2BResidentialFee';
 import LB2BSapAccount from '@salesforce/label/c.LB2BSapAccount';
 import LB2BSavings from '@salesforce/label/c.LB2BSavings';
 import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
 import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
 import LB2BSubtotal from '@salesforce/label/c.LB2BSubtotal';
 import LB2BTotal from '@salesforce/label/c.LB2BTotal';
 import ACCOUNT_NAME from '@salesforce/schema/User.Account.Name';
 import SAP_Customer_Number from '@salesforce/schema/User.Account.SAP_Customer_Number_Read_Only__c';
 import ShippingCity from '@salesforce/schema/User.Account.ShippingCity';
 import ShippingCountry from '@salesforce/schema/User.Account.ShippingCountry';
 import ShippingPostalCode from '@salesforce/schema/User.Account.ShippingPostalCode';
 import ShippingState from '@salesforce/schema/User.Account.ShippingState';
 import ShippingStreet from '@salesforce/schema/User.Account.ShippingStreet';
 import ContactName from '@salesforce/schema/User.Contact.Name';
 import ID from '@salesforce/schema/WebCart.Id';
 import CITY from '@salesforce/schema/WebCart.SAP_ShipTo_Override_City__c';
 import COUNTRY from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Country__c';
 import POSTALCODE from '@salesforce/schema/WebCart.SAP_ShipTo_Override_PostalCode__c';
 import STATE from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Region__c';
 import ADDRESS2 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Street2__c';
 import ADDRESS1 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Street__c';
 import LB2BSelectedCarrier from '@salesforce/label/c.LB2BSelectedCarrier';
 import USER_ID from '@salesforce/user/Id';
 import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';
 import { getFieldValue, getRecord } from 'lightning/uiRecordApi';
 import { api, LightningElement, track, wire } from 'lwc';
 import LB2BMultipleLocation from '@salesforce/label/c.LB2BMultipleLocation';
 //import { getQuotePdf } from 'c/lb2bGetQuote';
 // Custom Permissions import
import hasPermission from '@salesforce/customPermission/Internal_Sales_Rep';
import SalesRepCA from '@salesforce/customPermission/Sales_Rep_CA';
import SalesRepMX from '@salesforce/customPermission/Sales_Rep_MX';
import SalesRepUS from '@salesforce/customPermission/Sales_Rep_US';
import SalesRepCAMarketing from '@salesforce/customPermission/Sales_Rep_CA_Marketing';
import SalesRepCASales from '@salesforce/customPermission/Sales_Rep_CA_Sales';
import SalesRepCASalesMarketing from '@salesforce/customPermission/Sales_Rep_CA_Sales_Marketing';
import hasExportAffiliateUser from '@salesforce/customPermission/Export_Affiliate_User';
import hasDomesticAffiliate from '@salesforce/customPermission/Domestic_Affiliate_User';
 
 // Event name constants
 const CART_CHANGED_EVT = 'cartchanged';
 
 export default class lb2bOrderConfirmation extends NavigationMixin(LightningElement) {
     @track isOrderDetail = true;
     @track total = [];
     @track error;
     @api testvar;
     @api recordId;
     @api effectiveAccountId;
     pageParam = null;
     sortParam = 'CreatedDateDesc';
     cartItems;
     @api displayTotal;
     @api _poNumber;
     @api cartIdFromLocalStorage;
     orderDetails;
     @api orderDate;
     @api orderNumber;
 
     @api sapOrderDate;
     @api sapShipStreet;
     @api sapShipCity;
     @api sapShipState;
     @api sapShipCode;
     @api sapShipCountry;
     @api pathName;
     @api sapSoldToAccountName;
     @api sapShipToAccountName;
     @api sapAccNum;
     @api sapFrieght;
     @api sapResFrieght;
     @api sapLiftGateFee;
     @api sapTotal = 0;
     @api sapSubTotal;
     @api sapEstShipDate;
     @api SoldtoAccountname;
     @api ShiptoAccountname;
     @api ShippingStreet;
     @api ShippingCity;
     @api ShippingState;
     @api ShippingCountry;
     @api ShippingPostalCode;
     @api showDropShip = false;
     @api dropShipAddress1;
     dropshipName;
     dropshipName2;
     @api dropShipAddress2;
     @api dropShipCity;
     @api dropShipState;
     @api dropShipZip;
     @api dropShipCountry;
     @api showPackingInstructions;
     @api packingInstructions;
     @api layoutSize = '4';
     @track showAddress2;
     showName2 = false;
     _providedItems;
     currentPageReference = null;
     @track checkShowDropShip;
     checkCountry;
     cartItems;
     doShowFreightFields;
     pcrCodes;
     pcrcodescheck;
     frightcharges;
     displayTotal2;
     @track isMultipleLocation = false;
     @track soldToStreet;
     @track soldToCity;
     @track soldToState;
     @track soldToCountry;
     @track soldToPostalCode;
     shippingCarrier;
     shippingCarrierAccNum;
     userType;
 
     @wire(CurrentPageReference)
     pageRef;
 
     @wire(CurrentPageReference)
     getStateParameters(currentPageReference) {
         if (currentPageReference) {
             console.log('bbbb', currentPageReference.state.orderNumber);
             this.orderNumber = currentPageReference.state.orderNumber;
         }
     }
 
    // @api getSapData;
      @api
     get getSapData() {
        return this._providedItems;
     }
 
     set getSapData(data) {
         if (data != undefined) {
             // this.sapOrderDate = data.orderDate.CreateDate;
             this.sapShipStreet = data.orderShipTo.Street;
             this.sapShipCity = data.orderShipTo.City;
             this.sapShipState = data.orderShipTo.Region;
             this.sapShipCode = data.orderShipTo.PostalCode;
             this.sapShipCountry = data.orderShipTo.Country;
             this._poNumber = data.orderPONum.CustomerPurchaseOrderNumber;
             this.sapSoldToAccountName = data.orderSoldTo.PartnerName;
             this.sapShipToAccountName = data.orderShipTo.PartnerName;
             this.sapAccNum = data.orderSoldTo.PartnerNumber;
             //this.sapEstShipDate = data.orderItemsSchedule[0].ScheduleLineDate;
             this.sapSoldStreet = data.orderSoldTo.Street;
             this.sapSoldCity = data.orderSoldTo.City;
             this.sapSoldState = data.orderSoldTo.Region;
             this.sapSoldCode = data.orderSoldTo.PostalCode;
             this.sapSoldCountry = data.orderSoldTo.Country;
             let EstYear = data.orderDate.CreateDate.substring(0, 4);
             let EstMonth = data.orderDate.CreateDate.substring(5, 7);
             let EstDate = data.orderDate.CreateDate.substring(8, 10);
             let OrderDateFinal = new Date(Date.UTC(EstYear, EstMonth - 1, EstDate));
             this.sapOrderDate =
                 this.sapSoldCountry == 'US'
                     ? new Intl.DateTimeFormat('en-US').format(OrderDateFinal)
                     : this.sapSoldCountry == 'MX'
                     ? new Intl.DateTimeFormat('es-MX').format(OrderDateFinal)
                     : new Intl.DateTimeFormat('fr-CA').format(OrderDateFinal);
 
             for (let i = 0; i < data.orderItems.length; i++) {
                 this.sapTotal += data.orderItems[i].NetValueInDocumentCurrency;
             }
             this.sapTotal = parseFloat(this.sapTotal).toFixed(2);
 
             if (data.orderFrieght.length == 0) {
                 this.sapFrieght = parseFloat(0).toFixed(2);
             } else {
                 this.sapFrieght = parseFloat(data.orderFrieght[0].Rate).toFixed(2);
             }
 
             if (data.orderResFrieght.length == 0) {
                 this.sapResFrieght = parseFloat(0).toFixed(2);
             } else {
                 this.sapResFrieght = parseFloat(data.orderResFrieght[0].Rate).toFixed(2);
             }
 
             if (data.orderLiftGateFee.length == 0) {
                 this.sapLiftGateFee = parseFloat(0).toFixed(2);
             } else {
                 this.sapLiftGateFee = parseFloat(data.orderLiftGateFee[0].Rate).toFixed(2);
             }
 
             this.sapSubTotal =
                 parseFloat(this.sapTotal) -
                 (parseFloat(this.sapFrieght) +
                     parseFloat(this.sapResFrieght) +
                     parseFloat(this.sapLiftGateFee));
 
             this.sapSubTotal = parseFloat(this.sapSubTotal).toFixed(2);
 
             let obj = {
                 CurrencyIsoCode: '',
                 Id: '',
                 LB2B_Savings__c: 0,
                 LB2B_Total__c: this.sapTotal,
                 Freight__c: this.sapFrieght,
                 Residential_Freight_Fee__c: this.sapResFrieght,
                 Lift_Gate_Fee__c: this.sapLiftGateFee,
                 LB2B_SubTotal__c: this.sapSubTotal
             };
             this.displayTotal = obj;
         }
     }
 
     label = {
         LB2BShip_To,
         LB2BSold_To,
         LB2BOrderSumm,
         LB2BSubtotal,
         LB2BFreight,
         LB2BResidentialFee,
         LB2BLiftFee,
         LB2BTotal,
         LB2BSavings,
         LB2BOrderDetails,
         LB2BOrderDate,
         LB2BSapAccount,
         LB2BContactName,
         LB2BPONumber,
         LB2BEstimatedShipDate,
         LB2BReference,
         LB2BDropShipAddress,
         LB2BPackingDeliveryInstructions,
         LB2BMultipleLocation,
         LB2BSelectedCarrier
     };
 
     get todaysDate() {
         var today = new Date();
         var dd = String(today.getDate()).padStart(2, '0');
         var mm = String(today.getMonth() + 1).padStart(2, '0');
         var yyyy = today.getFullYear();
         var hh = new Date().getHours();
         var min = new Date().getMinutes();
         var ampm = hh >= 12 ? 'PM' : 'AM';
         hh = hh % 12;
         hh = hh ? hh : 12;
         today = mm + '/' + dd + '/' + yyyy + ', ' + hh + ':' + min + ' ' + ampm;
         return this.pathName == 'sap-order-detail' ? this.sapOrderDate : today;
     }
 
     _connectedResolver;
     _canResolveUrls = new Promise((resolved) => {
         this._connectedResolver = resolved;
     });
 
     connectedCallback() {
        console.log('getSapData ',this.getSapData);
         this.isLoading = true;
         //To show/hide dropShip Address in orderConfirmation page
         this.checkShowDropShip = localStorage.getItem('checkbox');
         console.log('CheckShowDropShip in OC:', this.checkShowDropShip);
         if (this.checkShowDropShip == 'true') {
             this.showDropShip = true;
             this.layoutSize = '3';
         }
 
         var pathname = new URL(window.location.href).pathname.split('/s/');
         this.pathName = pathname[1];
         this.cartIdFromLocalStorage = localStorage.getItem('cartId');
         this._connectedResolver();
         if (this.pathName != 'sap-order-detail') {
             this.updateCartItems();
             this.isOrderDetail = false;
         }
         this.handleCartUpdate();
 
         //    setTimeout(()=>{
         //     this.resetDropShip();
         //    }, 3000);
 
         //To show/hide the packingSlip Instructions
         this.packingInstructions = localStorage.getItem('packing');
         console.log('Packing Instructions: ', this.packingInstructions);
         if (this.packingInstructions != 'undefined' && this.packingInstructions != '') {
             this.showPackingInstructions = true;
         }
 
         this.cartItems = JSON.parse(localStorage.getItem('cartItems'));
         console.log('cartItems ', this.cartItems);
         this.pcrCodes = localStorage.getItem('PcrCodes');
       //  this.productCurrency = localStorage.getItem('currencyCodeGA');

        localStorage.removeItem('isQuote')


        if(SalesRepUS != null || SalesRepCA != null || SalesRepMX != null || SalesRepCAMarketing  != null || SalesRepCASales != null || SalesRepCASalesMarketing != null){
            this.userType = 'Internal Sales Rep';
           }else if(hasExportAffiliateUser != null){
               this.userType = 'Export Affiliates';
           }else if(hasDomesticAffiliate != null){
               this.userType = 'Domestic Affiliates';
           }else{
               this.userType = 'External Customer';
           } 
   
        // getQuotePdf(
        //     JSON.parse(localStorage.getItem("cartItems")),
        //     JSON.parse(localStorage.getItem("quote-getTodaysDate")),
        //     JSON.parse(localStorage.getItem("quote-orderTotal")),
        //     JSON.parse(localStorage.getItem("quote-brandToPdf")),
        //     JSON.parse(localStorage.getItem("quote-base64data")),
        //     'fr',
        //     this.orderNumber
        // );
        // localStorage.removeItem('quote-getTodaysDate');
        // localStorage.removeItem('quote-orderTotal');
        // localStorage.removeItem('quote-brandToPdf');
        //  localStorage.removeItem('quote-base64data');
        // console.log('from local storage getTodaysDate >>>',JSON.parse(localStorage.getItem('quote-getTodaysDate')));
       

     }
 
     resetDropShip() {
         let fields = {};
         fields[ID.fieldApiName] = this.cartIdFromLocalStorage;
         fields[ADDRESS1.fieldApiName] = '';
         fields[ADDRESS2.fieldApiName] = '';
         fields[CITY.fieldApiName] = '';
         fields[POSTALCODE.fieldApiName] = '';
         fields[STATE.fieldApiName] = '';
         fields[COUNTRY.fieldApiName] = '';
         const recordInput = { fields: fields };
         console.log('record input after place order:' + JSON.stringify(recordInput));
         updateRecord(recordInput);
     }
 
     handleCartUpdate() {
         console.log('update cart ');
         // Update Cart Badge
         this.dispatchEvent(
             new CustomEvent(CART_CHANGED_EVT, {
                 bubbles: true,
                 composed: true
             })
         );
         // Notify any other listeners that the cart items have updated
         // fireEvent(this.pageRef, CART_ITEMS_UPDATED_EVT);
     }
 
     @wire(getRecord, { recordId: USER_ID, fields: [ContactName] })
     contact;
 
     get contactName() {
         return this.pathName == 'sap-order-detail'
             ? ''
             : getFieldValue(this.contact.data, ContactName);
     }
 
     @wire(getRecord, { recordId: USER_ID, fields: [ACCOUNT_NAME, SAP_Customer_Number] })
     user;
 
     get accountName() {
         //return getFieldValue(this.user.data, ACCOUNT_NAME);
         return this.pathName == 'sap-order-detail'
             ? this.sapAccNum
             : getFieldValue(this.user.data, ACCOUNT_NAME);
     }
     get sapAccountNumber() {
         return this.pathName == 'sap-order-detail'
             ? this.sapAccNum
             : getFieldValue(this.user.data, SAP_Customer_Number);
     }
 
     @wire(getRecord, {
         recordId: USER_ID,
         fields: [ShippingStreet, ShippingCity, ShippingState, ShippingCountry, ShippingPostalCode]
     })
     add;
 
     get shipStr() {
         return this.pathName == 'sap-order-detail' ? this.sapShipStreet : this.ShippingStreet;
     }
     get shipcity() {
         return this.pathName == 'sap-order-detail' ? this.sapShipCity : this.ShippingCity;
     }
     get shipcon() {
         return this.pathName == 'sap-order-detail' ? this.sapShipCountry : this.ShippingCountry;
     }
     get shipstate() {
         return this.pathName == 'sap-order-detail' ? this.sapShipState : this.ShippingState;
     }
     get shipCode() {
         return this.pathName == 'sap-order-detail' ? this.sapShipCode : this.ShippingPostalCode;
     }
 
     navigateToCart() {
         let url = window.location.href;
         let newUrl = url.replace(/order-review/, 'cart/');
         let cartUrl = newUrl + this.cartIdFromLocalStorage;
         console.log('url', newUrl + this.cartIdFromLocalStorage);
         //this.showSpinner = false;
         this.navigateToCartPage(cartUrl);
         // this.navigateToCartPage();
     }
 
     navigateToOrderConfirmation() {
         let url = window.location.href;
         let newUrl = url.replace(/order-review/, 'orderconfirmation/');
         let cartUrl = newUrl + this.cartIdFromLocalStorage;
         console.log('url', newUrl + this.cartIdFromLocalStorage);
         //this.showSpinner = false;
         this.navigateToCartPage(cartUrl);
         // this.navigateToCartPage();
     }
 
     navigateToCartPage(url) {
         console.log(url);
         this[NavigationMixin.Navigate]({
             type: 'standard__webPage',
             attributes: {
                 url: url
             }
         });
     }
 
     get resolvedEffectiveAccountId() {
         const effectiveAccountId = this.effectiveAccountId || '';
         let resolved = null;
         if (effectiveAccountId.length > 0 && effectiveAccountId !== '000000000000000') {
             resolved = effectiveAccountId;
         }
         return resolved;
     }
 
     setShippingCarrierName(carrierName){
       
        if(carrierName === 'UPS2' || carrierName === 'UPS1' || carrierName === 'UPS' ){
            this.shippingCarrier = 'UPS';
        } else if(carrierName === 'Fed1' || carrierName === 'Fed2' || carrierName === 'FedG'){
            this.shippingCarrier = 'FedEx';
        } else if(carrierName === 'DHXO' || carrierName === 'DHGO'){
            this.shippingCarrier = 'DHL/Loomis';
        } else if(carrierName === 'DIXO' || carrierName === 'DIGO'){
            this.shippingCarrier = 'Dicom';
        } else if(carrierName === 'MIXO' || carrierName === 'MIGO'){
            this.shippingCarrier = 'Midland Courier';
        } else if(carrierName === 'PUXO' || carrierName === 'PUGO'){
            this.shippingCarrier = 'Purolator';
        } else if(carrierName === 'CAXO' || carrierName === 'CAGO'){
            this.shippingCarrier = 'Cardinal';
        } else if(carrierName === 'PICK'){
            this.shippingCarrier = 'Customer Pickup';
        }
}

     updateCartItems() {
        console.log('this.cartIdFromLocalStorage', this.cartIdFromLocalStorage);
         getSapTotal({
             webcartId: this.cartIdFromLocalStorage
         })
             .then((result) => {
                 console.log('Get SAP Total', result);
                 this._poNumber = result[0].UI_Po_Number__c;

                 if(result[0].ShippingCarrierName__c !== undefined){
                    this.setShippingCarrierName(result[0].ShippingCarrierName__c);
                    this.shippingCarrierAccNum = result[0].ShippingCarrierName__c ==='PICK'?
                        result[0].ShippingAccountNumber__c:'/'+' '+result[0].ShippingAccountNumber__c;
                 result[0].LB2B_Total__c = result[0].LB2B_SubTotal__c;
                 result[0].Freight__c = 0;
                 }

                 this.frightcharges = parseFloat(result[0].Freight__c).toFixed(2);
                 this.SoldtoAccountname = result[0].Sold_To_SAP_Account__r.Name;
                 this.soldToStreet = result[0].Sold_To_SAP_Account__r.Street__c;
                 this.soldToCity = result[0].Sold_To_SAP_Account__r.City__c;
                 this.soldToState = result[0].Sold_To_SAP_Account__r.State__c;
                 this.soldToPostalCode = result[0].Sold_To_SAP_Account__r.Postal_Code__c;
                 this.soldToCountry = result[0].Sold_To_SAP_Account__r.Country__c;
                 if (result[0].Ship_To_SAP_Account__r != undefined) {
                     this.ShiptoAccountname = result[0].Ship_To_SAP_Account__r.Name;
                     this.ShippingStreet = result[0].Ship_To_SAP_Account__r.Street__c;
                     this.ShippingCity = result[0].Ship_To_SAP_Account__r.City__c;
                     this.ShippingState = result[0].Ship_To_SAP_Account__r.State__c;
                     // this.ShippingState = result[0].Ship_To_SAP_Account__r.City__c ;
                     this.ShippingPostalCode = result[0].Ship_To_SAP_Account__r.Postal_Code__c;
                     this.ShippingCountry = result[0].Ship_To_SAP_Account__r.Country__c;
                 } else {
                     this.isMultipleLocation = true;
                     this.ShiptoAccountname = LB2BMultipleLocation;
                 }
                 this.displayTotal = result[0];
                 this.displayTotal2 = JSON.stringify(result[0].LB2B_Total__c);
                 this.MoveToDataLayer();
                 //To display fields on dropShipAddress
                 if (result.length != 0) {
                    this.dropshipName = result[0].SAP_ShipTo_Override_Name__c;
                    this.dropshipName2 = result[0].SAP_ShipTo_Override_Name1__c;
                     this.dropShipAddress1 = result[0].SAP_ShipTo_Override_Street__c;
                     this.dropShipAddress2 = result[0].SAP_ShipTo_Override_Street2__c;
                     this.dropShipCity = result[0].SAP_ShipTo_Override_City__c;
                     // this.dropShipState = result[0].LB2BState__c;
                     this.dropShipState = result[0].SAP_ShipTo_Override_Region__c;
                     this.dropShipZip = result[0].SAP_ShipTo_Override_PostalCode__c;
                     this.dropShipCountry = result[0].SAP_ShipTo_Override_Country__c;
 
                     if (this.dropShipAddress2 != undefined) {
                         this.showAddress2 = true;
                     }
                     this.dropshipName2 != undefined ? this.showName2 = true :this.showName2 = false;
                 }
 
                 // Get the currency of the sold to account
                 getSapAccountFlags({ sapAccountId: result[0].Sold_To_SAP_Account__c })
                     .then((accountResult) => {
                         if (accountResult.length == 0) {
                             this.doShowFreightFields = true;
                         } else {
                             if (accountResult[0].CurrencyIsoCode == 'USD') {
                                 this.doShowFreightFields = true;
                             } else {
                                 this.doShowFreightFields = false;
                             }
                         }
                     })
                     .catch((err) => {
                         console.error(err);
                     });
             })
             .catch((error) => {
                 console.error(error);
             });
     }
     @track mapData = [];
     mapDataFinal = [];
     totalFinalValue = 0;
     countryCurrency;
     MoveToDataLayer() {
         this.countryCurrency = this.soldToCountry === 'US' ? 'USD' : this.soldToCountry === 'MX' ? 'MXN' : 'CAD';
         for (var i = 0; i < this.cartItems.length; i++) {
             this.mapData.push({
                 item_name: this.cartItems[i].productName,
                 item_brand: this.cartItems[i].brandName,
                 item_id: this.cartItems[i].productSku,
                 item_variant: null,
                 price: this.cartItems[i].unitPrice,
                 quantity: this.cartItems[i].quantity,
                 index: i + 1
             });
             this.totalFinalValue =  this.totalFinalValue + this.cartItems[i].extendedPrice;
         }
         this.mapDataFinal = this.mapData;
         console.log('Final Array ', JSON.parse(JSON.stringify(this.mapDataFinal)));
         dispatchUpdateDataLayerEvent({
             event: 'purchase',
             'userType' : this.userType,
             ecommerce: {
                 transaction_id: this.orderNumber,
                 value: this.totalFinalValue.toFixed(2),
                 currency: this.countryCurrency,
                 shipping: this.frightcharges,
                 coupon: this.pcrCodes === undefined || null ? null : this.pcrCodes,
                 items: JSON.parse(JSON.stringify(this.mapDataFinal))
             }
         });
         localStorage.removeitem('PcrCodes');
     }
 }
 
 export function dispatchUpdateDataLayerEvent(detail) {
     document.dispatchEvent(
         new CustomEvent('updatedatalayer', {
             detail
         })
     );
 }