/**
 * To display the items with non-editable fields(Quantity change) in checkout page this lb2bCheckoutFinalCart component is used.
 *
 * this is parent component of lb2bCheckoutFinalCartItem.
 */

import { api, wire, track, LightningElement } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { fireEvent } from 'c/lb2bPubSub';
import communityId from '@salesforce/community/Id';
import getCartItems from '@salesforce/apex/LB2BCartController.getCartItems';
import getCartValidation from '@salesforce/apex/LB2BCartController.getCartValidation';
import { isCartClosed } from 'c/lb2bCartUtils';
import getData from '@salesforce/apex/LB2BCallEnosix.getData';
import getSapData from '@salesforce/apex/LB2BCartController.getSapData';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import PO_NUMBER from '@salesforce/schema/WebCart.PoNumber';
import Last_Modified_Date from '@salesforce/schema/WebCart.LastModifiedDate';
import LB2BEmptyCartHeaderLabel from '@salesforce/label/c.LB2BEmptyCartHeaderLabel';
import LB2BFooter_Line from '@salesforce/label/c.LB2BFooter_Line';
import LB2BClosedCartLabel from '@salesforce/label/c.LB2BClosedCartLabel';
import LB2BCartTimeOutErrorMsg from '@salesforce/label/c.LB2BCartTimeOutErrorMsg';
import LB2BProceedToCart from '@salesforce/label/c.LB2BProceedToCart';
import LB2BCheckout from '@salesforce/label/c.LB2BCheckout';
import LB2BPackingDeliveryInstructions from '@salesforce/label/c.LB2BPackingDeliveryInstructions';
import LB2BPackingOptional from '@salesforce/label/c.LB2BPackingOptional';
import LB2BDeliveryOptional from '@salesforce/label/c.LB2BDeliveryOptional';
import LB2BItems from '@salesforce/label/c.LB2BItems';
import LB2BEmptyCartBodyLabel from '@salesforce/label/c.LB2BEmptyCartBodyLabel';
import LB2BDropShipCheckbox from '@salesforce/label/c.LB2BDropShipCheckbox';
import LB2BDropShipAddress from '@salesforce/label/c.LB2BDropShipAddress';
import LB2BDropShipAddress1 from '@salesforce/label/c.LB2BDropShipAddress1';
import LB2BDropShipAddress2 from '@salesforce/label/c.LB2BDropShipAddress2';
import LB2BDropShipCity from '@salesforce/label/c.LB2BDropShipCity';
import LB2BDropShipState from '@salesforce/label/c.LB2BDropShipState';
import LB2BDropShipPostalCode from '@salesforce/label/c.LB2BDropShipPostalCode';
import LB2BDropShipCountry from '@salesforce/label/c.LB2BDropShipCountry';
import LB2BUnitedStates from '@salesforce/label/c.LB2BUnitedStates';
import LB2BCloseWindow from '@salesforce/label/c.LB2BCloseWindow';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';
import ID from '@salesforce/schema/WebCart.Id';
import ADDRESS1 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Street__c';
import ADDRESS2 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Street2__c';
import CITY from '@salesforce/schema/WebCart.SAP_ShipTo_Override_City__c';
import POSTALCODE from '@salesforce/schema/WebCart.SAP_ShipTo_Override_PostalCode__c';
import STATE from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Region__c';
import COUNTRY from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Country__c';
import US_STATES from '@salesforce/schema/WebCart.LB2BState__c';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { registerListener } from 'c/lb2bPubSub';
import deleteCartItem from '@salesforce/apex/LB2BCartController.deleteCartItem';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import getSapTotal from '@salesforce/apex/LB2BCartController.getSapTotal';
import updateWebCartPackSlip from '@salesforce/apex/LB2BCartController.updateWebCartPackSlip';
import getAccount from '@salesforce/apex/LB2BGetUserInformation.getAccount';
import USER_ID from '@salesforce/user/Id';
import NAME_K from '@salesforce/schema/User.Name';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
import LB2BQuote from '@salesforce/label/c.LB2BQuote';
import LB2BQuoteDate from '@salesforce/label/c.LB2BQuoteDate';
import LB2BCartValidationError from '@salesforce/label/c.LB2BCartValidationError';
import SBD_LOGO from '@salesforce/contentAssetUrl/unknown_content_asset';
import LB2BGetQuote from '@salesforce/label/c.LB2BGetQuote';
import LB2BLoadingCartItems from '@salesforce/label/c.LB2BLoadingCartItems';

// Event name constants
const CART_CHANGED_EVT = 'cartchanged';
const CART_ITEMS_UPDATED_EVT = 'cartitemsupdated';

// Locked Cart Status
const LOCKED_CART_STATUSES = new Set(['Processing', 'Checkout']);

/**
 * A sample cart contents component.
 * This component shows the contents of a buyer's cart on a cart detail page.
 * When deployed, it is available in the Builder under Custom Components as
 * 'B2B Sample Cart Contents Component'
 *
 * @fires CartContents#cartchanged
 * @fires CartContents#cartitemsupdated
 */

export default class lb2bCheckoutFinalCart extends NavigationMixin(LightningElement) {
    sbdLogo = SBD_LOGO;

    label = {
        LB2BCheckout,
        LB2BPackingDeliveryInstructions,
        LB2BPackingOptional,
        LB2BDeliveryOptional,
        LB2BItems,
        LB2BEmptyCartBodyLabel,
        LB2BFooter_Line,
        LB2BEmptyCartHeaderLabel,
        LB2BClosedCartLabel,
        LB2BDropShipCheckbox,
        LB2BDropShipAddress,
        LB2BDropShipAddress1,
        LB2BDropShipAddress2,
        LB2BDropShipState,
        LB2BDropShipCity,
        LB2BDropShipPostalCode,
        LB2BDropShipCountry,
        LB2BUnitedStates,
        LB2BLoading,
        LB2BCartTimeOutErrorMsg,
        LB2BProceedToCart,
        LB2BQuote,
        LB2BQuoteDate,
        LB2BGetQuote,
        LB2BCloseWindow,
        LB2BLoadingCartItems
    };
    /**
     * An event fired when the cart changes.
     * This event is a short term resolution to update the cart badge based on updates to the cart.
     *
     * @event CartContents#cartchanged
     *
     * @type {CustomEvent}
     *
     * @export
     */

    /**
     * An event fired when the cart items change.
     * This event is a short term resolution to update any sibling component that may want to update their state based
     * on updates in the cart items.
     *
     * In future, if LMS channels are supported on communities, the LMS should be the preferred solution over pub-sub implementation of this example.
     * For more details, please see: https://developer.salesforce.com/docs/component-library/documentation/en/lwc/lwc.use_message_channel_considerations
     *
     * @event CartContents#cartitemsupdated
     * @type {CustomEvent}
     *
     * @export
     */

    /**
     * A cart line item.
     *
     * @typedef {Object} CartItem
     *
     * @property {ProductDetails} productDetails
     *   Representation of the product details.
     *
     * @property {number} quantity
     *   The quantity of the cart item.
     *
     *  @property {number} sapOrderQuantity
     *   The quantity of the cart item.
     *
     * @property {string} originalPrice
     *   The original price of a cart item.
     *
     * @property {string} salesPrice
     *   The sales price of a cart item.
     *
     * @property {string} totalPrice
     *   The total sales price of a cart item, without tax (if any).
     *
     * @property {string} totalListPrice
     *   The total original (list) price of a cart item.
     */

    /**
     * Details for a product containing product information
     *
     * @typedef {Object} ProductDetails
     *
     * @property {string} productId
     *   The unique identifier of the item.
     *
     * @property {string} sku
     *  Product SKU number.
     *
     * @property {string} name
     *   The name of the item.
     *
     * @property {ThumbnailImage} thumbnailImage
     *   The quantity of the item.
     */

    /**
     * Image information for a product.
     *
     * @typedef {Object} ThumbnailImage
     *
     * @property {string} alternateText
     *  Alternate text for an image.
     *
     * @property {string} id
     *  The image's id.
     *
     * @property {string} title
     *   The title of the image.
     *
     * @property {string} url
     *   The url of the image.
     */

    /**
     * Representation of a sort option.
     *
     * @typedef {Object} SortOption
     *
     * @property {string} value
     * The value for the sort option.
     *
     * @property {string} label
     * The label for the sort option.
     */

    /**
     * The recordId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    recordId;
    @api
    sapNetItemPrice;

    /**
     * The effectiveAccountId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    effectiveAccountId;

    @api nextPageToken;

    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;
    /**
     * Total number of items in the cart
     * @private
     * @type {Number}
     */
    _cartItemCount = 0;

    /**
     * A list of cartItems.
     *
     * @type {CartItem[]}
     */
    cartItems;

    sapItems;

    concatinatedArray;
    @track isIndirectAccount;
    @track checkAccount;

    /**
     * Specifies the page token to be used to view a page of cart information.
     * If the pageParam is null, the first page is returned.
     * @type {null|string}
     */
    pageParam = null;
    pageSize = 100;

    /**
     * Sort order for items in a cart.
     * The default sortOrder is 'CreatedDateDesc'
     *    - CreatedDateAsc—Sorts by oldest creation date
     *    - CreatedDateDesc—Sorts by most recent creation date.
     *    - NameAsc—Sorts by name in ascending alphabetical order (A–Z).
     *    - NameDesc—Sorts by name in descending alphabetical order (Z–A).
     * @type {string}
     */
    sortParam = 'CreatedDateDesc';

    /**
     * Is the cart currently disabled.
     * This is useful to prevent any cart operation for certain cases -
     * For example when checkout is in progress.
     * @type {boolean}
     */
    isCartClosed = false;

    /**
     * The ISO 4217 currency code for the cart page
     *
     * @type {string}
     */
    currencyCode;

    @api webCartId;
    @api _interval;
    @api openModal;
    @api address1;
    @api address2;
    @api city;
    @api postalCode;
    @api state;
    @api country;
    @api statesOfUsa;
    @api checked = false;
    @api isChecked = false;
    @api summary;
    @api recInput;
    @api packSlipInstruction;
    @api name;
    countryCurrency;
    countryUSA = false;
    @api timeoutId;
    @api progress = 5000;
    @api _records;
    @track hidePagination;
    @api previousPageToken;
    @api printArray = [];
    @api isBrowserPrint;
    @api isPrintCalled = false;
    @api getTodaysDate;
    @api localeSidKey;
     isDirty;
     lastSimulated;
     time;

    NewSap = [{}];

    /**
     * Gets whether the cart item list is empty.
     *
     * @type {boolean}
     * @readonly
     */
    get isCartEmpty() {
        // If the items are an empty array (not undefined or null), we know we're empty.
        return Array.isArray(this.cartItems) && this.cartItems.length === 0;
    }

    /**
     * Gets whether the item list state is indeterminate (e.g. in the process of being determined).
     *
     * @returns {boolean}
     * @readonly
     */
    get isCartItemListIndeterminate() {
        return !Array.isArray(this.cartItems);
    }

    /**
     * Gets the normalized effective account of the user.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get resolvedEffectiveAccountId() {
        const effectiveAccountId = this.effectiveAccountId || '';
        let resolved = null;
        if (effectiveAccountId.length > 0 && effectiveAccountId !== '000000000000000') {
            resolved = effectiveAccountId;
        }
        return resolved;
    }

    connectedCallback() {
        localStorage.setItem('packing', this.packSlipInstruction);
        this.getTodaysDate = new Date();
        fireEvent(this.pageRef, 'checkbox', this.isChecked);
        registerListener('paginationNextPage', this.handleNextPage, this);
        registerListener('paginationPreviousPage', this.handlePreviousPage, this);

        getSapTotal({
            webcartId: this.recordId
        }).then((result) => {
            this.summary = result[0];
            this.sapId = this.summary.Sold_To_SAP_Account__c;
            this.checkAccountType(this.sapId);
            this.address1 = this.summary.SAP_ShipTo_Override_Street__c;
            this.address2 = this.summary.SAP_ShipTo_Override_Street2__c;
            this.city = this.summary.SAP_ShipTo_Override_City__c;
            this.state = this.summary.SAP_ShipTo_Override_Region__c;
            this.postalCode = this.summary.SAP_ShipTo_Override_PostalCode__c;
            this.country = this.summary.SAP_ShipTo_Override_Country__c;
            this.packSlipInstruction = this.summary.UI_Pack_Slip_Instruction__c;
            this.isDirty = this.summary.Is_Dirty__c;
                 this.lastSimulated = this.summary.Last_Simulated__c;

                 let new_last_simulation = new Date(this.lastSimulated);
                 this.time = new_last_simulation.getTime();
                 this.getTimeDifference(this.time);

                 /* for 15 min timer last simulated */
                 if(this.isDirty === true || (this.lastSimulated === null || this.lastSimulated === undefined || this.getTimeDifference(this.time) >= '15')){
                     this.sapData();
                 }
                 else{
                     this.updateSap();
                 }
        }).catch(error => {
            console.log("Error"+ error);
         }) 
    }

    handleNextPage(data) {
        this.pageParam = data;
        this.updateCartItems();
    }

    handlePreviousPage(data) {
        this.pageParam = data;
        this.updateCartItems();
    }

    getBrowserPrint() {
        this.isBrowserPrint = true;
        this.printArray = this.cartItems;
        if (this._cartItemCount > 100 && !this.isPrintCalled) {
            this.pageParam =
                this.previousPageToken == null ? this.nextPageToken : this.previousPageToken;
            this.updateCartItems();
        } else {
            window.print();
        }
    }

    resetTimer() {
        clearTimeout(this.timeoutId);
        this.timeoutId = setTimeout(() => {
            this.sessionExpirationModal();
        }, 900000);
    }
    sessionExpirationModal() {
        this.openModal = true;
    }

    backToCartPage() {
        history.back();
    }

    //TODO:Get time difference for cart time out
    getTimeDifference(datetime){
        console.log("datetime",datetime)
        let now = new Date().getTime();
        console.log("now -------> ", now)
        if( isNaN(datetime) )
        // var timeDiff = now-datetime;
        console.log("diffffffffff",now-datetime)
        let minutes = Math.floor((now-datetime) / 60000);
        let seconds = (((now-datetime) % 60000) / 1000).toFixed(0);
        console.log("time diff",minutes + ":" + (seconds < 10 ? '0' : '') + seconds )
        return minutes;  
    }

    handlePackingSlip(event) {
        localStorage.setItem('packing', event.target.value);
        updateWebCartPackSlip({
            cartId: this.recordId,
            packSlip: event.target.value
        })
            .then((result) => {})
            .catch((error) => {});
    }

  // To identify the country & Indirect Acoount to show/hide dropShip section
  checkAccountType(sapId) {
    getSapAccountFlags({
        sapAccountId: sapId
    }).then((result) => {
        fireEvent(this.pageRef, 'brandName', result);
        this.countryCurrency = result[0].CurrencyIsoCode;
        if(this.countryCurrency == 'USD'){
           this.countryUSA = true;
        }

        this.checkAccount = result[0].Indirect_Sold_To__c;
        if (this.checkAccount === true) {
            this.isIndirectAccount = true;
        } else {
            this.isIndirectAccount = false;
        }
        if ((this.isIndirectAccount === true) && (this.address1 != undefined) && (this.city != undefined) && (this.state != undefined) && (this.postalCode != undefined)) {
           this.checked = true;
           this.isChecked = true;
           fireEvent(this.pageRef, 'checkbox', this.isChecked);
           this.updateDropShip();
       }
       else{
           this.resetDropShip();
       }
    })
     .catch(error => {
        console.log("Error"+ error);
     }) 
}

    @api validateData;
    @api validateMessage = [];
    @api listOption = [];
    sapData() {
        this.webCartId = this.recordId; //webcartId

        getData({ CartId: this.recordId })
            .then((result) => {
                this.updateSap();

                // this.updateCartItems();
            })
            .catch((error) => {
                console.log('error', error);
            });
    }

    updateSap() {
        let sapFailArray = [];
        getSapData({
            cartId: this.recordId
        })
            .then((result) => {
                fireEvent(this.pageRef, '_callCartTotal', '');
                this.resetTimer();
                this.sapItems = result;
                console.log('net item : ', this.sapItems);
                getCartValidation({
                    cartId: this.recordId
                })
                    .then((result) => {
                        this.validateData = result;
                        console.log('get cart validation result : ', this.validateData);
                        if (this.validateData.length == 0) {
                            this.sapItems.forEach((item) => {
                                let sapJsonData =
                                    item.SAP_ItemsJSON__c != undefined
                                        ? JSON.parse(item.SAP_ItemsJSON__c)
                                        : [];
                                if (
                                    item.SAP_NetItemPrice__c == undefined ||
                                    item.SAP_NetItemPrice__c == null ||
                                    (item.SAP_NetItemPrice__c == 0 &&
                                        sapJsonData[0].ItemCategory != 'TAN')
                                ) {
                                    sapFailArray.push(item);
                                    console.log('failedsapdata', sapFailArray);
                                }
                            });
                        } else {
                            window.history.back();
                            setTimeout(() => {
                                fireEvent(this.pageRef, 'sapcallFail', this.validateData);
                            }, 2000);
                        }
                        if (sapFailArray.length != 0) {
                            window.history.back();
                            setTimeout(() => {
                                sapFailArray.forEach((product) => {
                                    let obj = { Message: '' };
                                    obj.Message = product.Sku + ' ' + LB2BCartValidationError;
                                    this.validateData.push(obj);
                                });
                                fireEvent(this.pageRef, 'sapcallFail', this.validateData);
                            }, 2000);
                        }
                    })
                    .catch((error) => {
                        console.log('error for cart validation : ', error);
                    });
                this.updateCartItems();
            })
            .catch((error) => {
                console.log('Sap data Error : ', error);
            });
    }

    updateCartItems() {
        getCartItems({
            communityId: communityId,
            effectiveAccountId: this.resolvedEffectiveAccountId,
            activeCartOrId: this.recordId,
            productFields: 'Brand__c',
            pageParam: this.pageParam,
            pageSize: this.pageSize,
            sortParam: this.sortParam
        })
            .then((result) => {
                console.log('sap', this.sapItems);
                this.cartItems = result.cartItems;
                this._records = result.cartItems;
                this.hidePagination = this._records.length == 0 ? false : true;

                if (this.isBrowserPrint) {
                    this.cartItems = [...this.printArray, ...result.cartItems];
                    this.isPrintCalled = true;
                }

                this.nextPageToken = result.nextPageToken;
                this.previousPageToken = result.previousPageToken;
                for (let i = 0; i <= this.cartItems.length; i++) {
                    for (let j = 0; j <= this.sapItems.length; j++) {
                        if (this.cartItems[i] != undefined && this.sapItems[j] != undefined) {
                            if (
                                this.cartItems[i].cartItem.productId == this.sapItems[j].Product2Id
                            ) {
                                let sapJsonData =
                                    this.sapItems[j].SAP_ItemsJSON__c != undefined
                                        ? JSON.parse(this.sapItems[j].SAP_ItemsJSON__c)
                                        : [];
                                if (
                                    sapJsonData.length != 0 &&
                                    this.sapItems[j].SAP_NetItemPrice__c == 0 &&
                                    sapJsonData[0].ItemCategory == 'TAN'
                                ) {
                                    deleteCartItem({
                                        communityId,
                                        effectiveAccountId: this.effectiveAccountId,
                                        activeCartOrId: this.recordId,
                                        cartItemId: this.cartItems[i].cartItem.cartItemId
                                    })
                                        .then(() => {
                                            fireEvent(this.pageRef, '_deleteCartItem', '');
                                            getData({ CartId: this.recordId })
                                                .then((result) => {})
                                                .catch((error) => {
                                                    console.log('error', error);
                                                });
                                            this.handleCartUpdate();
                                        })
                                        .catch((e) => {
                                            console.log(e);
                                        });
                                    this.cartItems.splice(i, 1);
                                } else {
                                    this.cartItems[i].cartItem.totalPrice =
                                        this.sapItems[j].SAP_NetOrderValue__c;
                                    this.cartItems[i].cartItem.unitAdjustedPrice =
                                        this.sapItems[j].SAP_NetItemPrice__c;
                                    if (this.sapItems[j].SAP_ItemsJSON__c != undefined) {
                                        this.cartItems[i].cartItem.SAP_ItemsJSON__c =
                                            this.sapItems[j].SAP_ItemsJSON__c;
                                        this.cartItems[i].cartItem.sapOrderQuantity = JSON.parse(
                                            this.sapItems[j].SAP_ItemsJSON__c
                                        )[0].OrderQuantity;
                                    }
                                }
                            }
                        }
                    }
                }
                this._cartItemCount = Number(result.cartSummary.uniqueProductCount);
                this.currencyCode = result.cartSummary.currencyIsoCode;
                this.isCartDisabled = LOCKED_CART_STATUSES.has(result.cartSummary.status);
            })
            .catch((error) => {
                const errorMessage = error.body.message;
                this.cartItems = undefined;
                this.isCartClosed = isCartClosed(errorMessage);
            });
    }

    handleCartUpdate() {
        // Update Cart Badge
        this.dispatchEvent(
            new CustomEvent(CART_CHANGED_EVT, {
                bubbles: true,
                composed: true
            })
        );
        // Notify any other listeners that the cart items have updated
        fireEvent(this.pageRef, CART_ITEMS_UPDATED_EVT);
    }

    /**
     * Handles a "click" event on the sort menu.
     *
     * @param {Event} event the click event
     * @private
     */
    handleChangeSortSelection(event) {
        this.sortParam = event.target.value;
        // After the sort order has changed, we get a refreshed list
        this.updateCartItems();
    }

    renderedCallback() {
        if (this.isBrowserPrint) {
            setTimeout(() => {
                window.print();
                this.hidePagination = false;
                this.isBrowserPrint = false;
            }, 1000);
        }
        loadStyle(this, GlobalCSS);
    }

    handleCheckbox(event) {
        let checked = event.target.checked;
        if (checked == true) {
            this.isChecked = true;
            fireEvent(this.pageRef, 'checkbox', this.isChecked);
        } else {
            this.isChecked = false;
            fireEvent(this.pageRef, 'checkbox', this.isChecked);
            this.resetDropShip();
        }
    }

    resetDropShip() {
        let fields = {};
        fields[ID.fieldApiName] = this.recordId;
        fields[ADDRESS1.fieldApiName] = '';
        fields[ADDRESS2.fieldApiName] = '';
        fields[CITY.fieldApiName] = '';
        fields[POSTALCODE.fieldApiName] = '';
        fields[STATE.fieldApiName] = '';
        fields[COUNTRY.fieldApiName] = '';
        const recordInput = { fields: fields };
        console.log('record input after disable checkbox:' + JSON.stringify(recordInput));
        updateRecord(recordInput);
    }

    @wire(getPicklistValues, { recordTypeId: '012000000000000AAA', fieldApiName: US_STATES })
    states;

    get stateOptions() {
        this.statesOfUsa = this.states.data;
        //console.log("States of USA:", this.statesOfUsa);
        return this.statesOfUsa.values;
    }

    handleAddress1Change(event) {
        this.address1 = event.target.value;
        this.updateDropShip();
    }

    handleAddress2Change(event) {
        this.address2 = event.target.value;
        this.updateDropShip();
    }

    handleCityChange(event) {
        this.city = event.target.value;
        this.updateDropShip();
    }

    handlePostalCodeChange(event) {
        this.postalCode = event.target.value;
        this.updateDropShip();
    }

    handleStateChange(event) {
        this.state = event.detail.value;
        this.updateDropShip();
    }

    updateDropShip() {
        fireEvent(this.pageRef, 'address1Value', this.address1);
        let fields = {};
        fields[ID.fieldApiName] = this.recordId;
        fields[ADDRESS1.fieldApiName] = this.address1;
        fields[ADDRESS2.fieldApiName] = this.address2;
        fields[CITY.fieldApiName] = this.city;
        fields[POSTALCODE.fieldApiName] = this.postalCode;
        fields[STATE.fieldApiName] = this.state;
        fields[COUNTRY.fieldApiName] = this.label.LB2BUnitedStates;

        const recordInput = { fields: fields };

        updateRecord(recordInput).catch((error) => {
            console.log('Bug:', error);
        });

        this.recInput = recordInput;
        fireEvent(this.pageRef, 'checkbox', this.isChecked);
        fireEvent(this.pageRef, 'dropship', this.recInput);
        //fireEvent(this.pageRef,'pattern',this.postalCode);
    }

    //To check the name of the user
    @wire(getRecord, {
        recordId: USER_ID,
        fields: [NAME_K]
    })
    wireuser({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            this.name = data.fields.Name.value;
            this.checkCountry();
        }
    }

    checkCountry() {
        getAccount({
            username: this.name
        })
            .then((result) => {
                //To get print page Quote date:
                this.localeSidKey = result[0].LocaleSidKey;
                if (this.localeSidKey == 'es_MX') {                   
                    this.getTodaysDate = new Intl.DateTimeFormat(['ban', 'id']).format(
                        this.getTodaysDate
                    );
                } else if (this.localeSidKey == 'fr' || this.localeSidKey == 'fr_CA') {
                    this.getTodaysDate = new Intl.DateTimeFormat('fr-CA').format(
                        this.getTodaysDate
                    );
                } else {
                    this.getTodaysDate = new Intl.DateTimeFormat('en-US').format(
                        this.getTodaysDate
                    );
                }

                console.log('Get Account:', result);
            })
            .catch((error) => {
                console.log('Address Undefined:', error);
            });
    }
}