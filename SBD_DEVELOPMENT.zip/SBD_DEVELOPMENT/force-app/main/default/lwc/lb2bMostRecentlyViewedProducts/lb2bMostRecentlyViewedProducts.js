import { LightningElement, api, wire, track } from 'lwc';
import communityId from '@salesforce/community/Id';
import { NavigationMixin } from 'lightning/navigation';
import { CurrentPageReference } from 'lightning/navigation';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BRecentSku from '@salesforce/label/c.LB2BRecentSku';
import LOCALE from '@salesforce/i18n/locale';
import addToContact from '@salesforce/apex/LB2BRecentlyViewedProducts.addToContact';

export default class Lb2bMostRecentlyViewedProducts extends NavigationMixin(LightningElement) {
    @track carouselTitle = 'WHAT YOU BROWSED FOR';
    @track currentSlideIndex = 0;
    @track productsPerPage = 4;
    @track productList;
    @api product;
    color;
    _isPlp;
    _isPlpValue;
    isLoading = true;
    isCanadaUser = false;
    isMxUser = false;
    isUsUser = false;
    productCount = 0;

    labels = {
        LB2BSku,
        LB2BRecentSku
    }

    @api
    get effectiveAccountId() {
        return this._effectiveAccountId;
    }

    @wire(CurrentPageReference)
    pageRef;

    set effectiveAccountId(newId) {
        this._effectiveAccountId = newId;
    }

    @api
    recordId;

    @track stockAvailabilityColor;

    get hasProducts() {
        return this.productCount > 0;
    }

    connectedCallback() {
        if (LOCALE === 'en-US') {
            this.isUsUser = true;
        } else if (LOCALE === 'fr-CA') {
            this.isCanadaUser = true;
        } else {
            this.isMxUser = true;
        }
        this.isLoading = true;
        this._isPlp = window.location.origin + window.location.pathname;
        this._isPlpValue = this._isPlp.includes('product');
        this.recordId = this._isPlpValue === true ? this.recordId : null;
        console.log('Record Id:', this.recordId);
        addToContact({ sku: this.recordId, communityId: communityId, effectiveAccountId: this._effectiveAccountId })
            .then((result) => {
                this.isLoading = false;
                console.log('SKU Added to Recent View List', result);
                this.productList = result;
                this.productCount = this.productList.length;
                this.productList = JSON.parse(JSON.stringify(this.productList));

                // Change Product Availability Status Color
                this.productList.forEach(element => {
                    let value = this.isUsUser ? element.fields.LB2BProductAvailabilityStatusUs__c :
                        this.isCanadaUser ? element.fields.LB2BProductAvailabilityStatusCa__c :
                            element.fields.LB2BProductAvailabilityStatusMx__c
                    element.color = value === 'In Stock' ? 'color:limegreen' :
                        value === 'Out of Stock' ? 'color:red' :
                            value === 'Low Stock' ? 'color: #ffdb0a' : '';
                });
            })
            .catch((error) => {
                // Handle error appropriately, such as displaying an error message
                console.error(error);
            });
    }

    get currentGroup() {
        const start = this.currentSlideIndex * this.productsPerPage;
        const end = start + this.productsPerPage;
        // console.log('start',start);
        // console.log('end',end);
        return this.productList ? this.productList.slice(start, end) : [];
    }

    get showLeftArrow() {
        return this.currentSlideIndex > 0;
    }

    get showRightArrow() {
        if(this.currentSlideIndex == 1 && (this.productCount > 3 && this.productCount <= 8)){
          
        }

        else if(this.currentSlideIndex == 2 && (this.productCount > 7 && this.productCount <= 12)){

        }
        else{
        return this.currentSlideIndex < 3 && (this.productList != undefined && this.productList.length > 4);
        }
    }


    handlePrevArrowClick() {
        if (this.currentSlideIndex > 0) {
            this.currentSlideIndex--;
        }
    }

    handleNextArrowClick() {
        const totalSlides = Math.ceil(this.productList.length / this.productsPerPage);
        if (this.currentSlideIndex < totalSlides - 1) {
            this.currentSlideIndex++;
        }
    }

    handleCarouselClick(event) {
        const productId = event.currentTarget.dataset.productId;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: productId,
                objectApiName: 'Product2',
                actionName: 'view'
            }
        });
    }

}