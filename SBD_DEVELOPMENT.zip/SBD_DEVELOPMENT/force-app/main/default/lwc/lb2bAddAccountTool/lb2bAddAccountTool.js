import { LightningElement, track } from 'lwc';
import USER_ID from '@salesforce/user/Id';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import isAccountSuperUser from '@salesforce/customPermission/Account_Superuser';
import checkAccountNumber from '@salesforce/apex/LB2BAddAccountToolController.checkAccountNumber';
import addAccount from '@salesforce/apex/LB2BAddAccountToolController.addAccount';
import LB2BSapAccountExcelFile from '@salesforce/label/c.LB2BSapAccountExcelFile';

const DEFAULT_VALUE = { number: '', id: undefined, timer: undefined };

export default class Lb2bAddAccountTool extends LightningElement {
    hasAccess = isAccountSuperUser; 

    @track
    data = {
        SoldTo: { ...DEFAULT_VALUE },
        ShipTo: { ...DEFAULT_VALUE }
    };

    labels = {
        LB2BSapAccountExcelFile
    };

    @track isSoldTo = false;
    @track isShipTo = false;
    @track shipToNotes;
    @track soldToNotes;
    shipToLength = 10;
    soldToLength = 10;
    isError = false;
    accountNumbers;
    inValidNumbers;
    soldToNumbers = [];
    shipToNumbers = [];
    soldToIds = [];
    shipToIds = [];

    handleMultipleAccountsCheck(evt){
        evt.target.name == 'soldTo' ? (this.isShipTo = evt.target.checked ? true : false) : ( this.isSoldTo = evt.target.checked ? true : false);
        // this.soldToIds = [];
        // this.shipToIds = [];
        // this.soldToNumbers = [];
        // this.shipToNumbers = [];
        if (this.isSoldTo){
           this.shipToNotes =  '- Enter multiple accounts in comma separated format ", "' ; 
           this.soldToNotes = '- Please enter only one Account';
           this.soldToLength = 10;
           this.shipToLength = 1000;
        //    console.log('this.soldToLength >>>',this.soldToLength)
        } else if(this.isShipTo){
            this.soldToNotes = '- Enter multiple accounts in comma separated format ", "' ; 
            this.shipToNotes = '- Please enter only one Account';
            this.shipToLength = 10;
            this.soldToLength = 1000;
            // console.log('this.shipToLength >>>',this.shipToLength)
        } else if(!this.isSoldTo && !this.isShipTo){
            this.shipToNotes = '';
            this.soldToNotes = '';
            this.soldToLength = 10;
            this.shipToLength = 10;
        }
    }

    handleSoldToChanged(evt) {
        // alert('sld')
        // Reset arrays and isError flag
        this.accountNumbers = [];
        this.inValidNumbers = [];
        this.isError = false;
        let accountNumber = evt.target.value.split(',');
        console.log('accnt Numbers >>>',accountNumber,'>>>',this.soldToNumbers)
        for (let i = 0; i < accountNumber.length; i++) {
            // alert('123');
            this.accountNumbers.push(accountNumber[i]);
            this.soldToNumbers.push(accountNumber[i]);
        }
        console.log('accnt Numbers 1 >>>',this.accountNumbers,' >>> ',this.soldToNumbers)
        this.accountNumbers = this.accountNumbers?.filter((str) => str !== '');
        console.log('accnt Numbers >>>',this.accountNumbers)
        this.assignData('SoldTo', this.accountNumbers); 
    }

    handleShipToChanged(evt) {
        // alert('shp')
        this.accountNumbers = [];
        this.inValidNumbers = [];
        this.isError = false;
        let accountNumber = evt.target.value.split(',');
        console.log('accnt Numbers >>>',accountNumber,accountNumber.length)
        for (let i = 0; i < accountNumber.length; i++) {
            this.accountNumbers.push(accountNumber[i]);
            this.shipToNumbers.push(accountNumber[i]);
        }
        console.log('accnt Numbers 1 >>>',this.accountNumbers,' >>> ',this.shipToNumbers)
        this.accountNumbers = this.accountNumbers?.filter((str) => str !== '');
        console.log('accnt Numbers >>>',this.accountNumbers)
        this.assignData('ShipTo', this.accountNumbers); 
    }
    
    assignData(mode, value) {
        clearTimeout(this.data[mode]);
        this.data[mode].id = undefined;
        this.data[mode].number = value;
        this.data[mode].timer = setTimeout(() => {
          this.data[mode].isLoading = true;
          // Call the checkAccountNumber function with the account numbers provided in value
          checkAccountNumber({ accountNumbers: this.data[mode].number })
            .then((result) => {
              if (!!result) {
                console.log('result >>>', result);
                this.inValidNumbers = value;
                const _inValidNumbers = [];
                for (const val of value) {
                    let isInvalid = false;
                    for (const res of result) {
                        console.log('val.toString() >>> ',val.toString());
                        if (val.toString().includes(res.ERP_Customer_No_Search__c.substr(res.ERP_Customer_No_Search__c.length - 7))) {
                            if (mode == 'SoldTo') {
                                // alert('1')
                                this.soldToIds.push(res.Id);
                            } else {
                                // alert('3')
                                this.shipToIds.push(res.Id);
                            }
                            // alert('2')
                            isInvalid =  true;
                            console.log('isInvalid >>>',isInvalid);
                            break;
                        }
                    }
                    if (!isInvalid) {
                        _inValidNumbers.push(val);
                    }
                }
                this.inValidNumbers = _inValidNumbers;
                if (this.inValidNumbers.length >= 1) {
                  this.isError = true;
                } else {
                  this.isError = false;
                  this.data[mode].id = true; // Set the id property to true if there are no invalid numbers
                }
                // console.log('this.inValidNumbers >>>', this.inValidNumbers);
              } else {
                this.data[mode].id = false;
              } 
              this.data[mode].isLoading = false;
            })
            .catch(() => {
              this.data[mode].isLoading = false;
            });
        }, 700);
      }

    get isSoldToValid() {
        return this.data.SoldTo.id !== undefined && this.data.SoldTo.id !== false;
    }

    get isShipToValid() {
        return this.data.ShipTo.id !== undefined && this.data.ShipTo.id !== false;
    }

    handleAddAccount() {
        if (this.data.SoldTo.id && this.data.ShipTo.id) {
            // console.log('this.data.SoldTo.id >>> ',this.soldToNumbers,' >>> ',this.shipToNumbers,' >>> ',USER_ID);
            addAccount({
                userId: USER_ID,
                soldToIds: this.soldToIds,
                shipToIds: this.shipToIds
            }).then((result) => {
                if (result) {
                    console.log('addAccount result >>>',result)
                    this.soldToIds = [];
                    this.shipToIds = [];
                    this.soldToNumbers = [];
                    this.shipToNumbers = [];
                    this.isSoldTo = false;
                    this.isShipTo = false;
                    this.data.SoldTo = { ...DEFAULT_VALUE };
                    this.data.ShipTo = { ...DEFAULT_VALUE };

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success!',
                            message: 'Account combination added successfully',
                            variant: 'success'
                        })
                    );
                } else {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Something Went Wrong!',
                            message: 'Unable to add account, please refresh and try again',
                            variant: 'error'
                        })
                    );
                }
            })
            .catch((error)=>{
                console.log('error >>>',error);
            });
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Heads Up!!',
                    message: 'Please verify your Sold To and Ship To are valid',
                    variant: 'warning'
                })
            );
        }
    }
}