/**
 * @description       :
 * @author            : Stefanie Elling
 * @group             :
 * @last modified on  : 09-14-2022
 * @last modified by  : Dilvar Singh
 **/
import { LightningElement, api } from 'lwc';

import LB2BFeaturedProductsButton from '@salesforce/label/c.LB2BFeaturedProductsButton';

import CURRENCY from '@salesforce/i18n/currency';

import { NavigationMixin } from 'lightning/navigation';
import {HomePageEvent} from 'c/lb2bDataLayer';   //added
import communityBasePath from '@salesforce/community/basePath';

export default class Lb2bFeaturedProductsImage extends NavigationMixin(LightningElement) {
    @api product;
    currency = CURRENCY;
    url;

    label = {
        LB2BFeaturedProductsButton
    };

    get isBlank() {
        return this.product.productName == '';
    }

    handleClick(evt) {
        evt.preventDefault();
        evt.stopPropagation();
        console.log('Feature Products Image ', JSON.parse(JSON.stringify(this.product)))
        this.navigateToWebPage();
        this.MoveFeaturedProductsToDataLayer('Featured Products');     //added
    }

    navigateToWebPage() {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: communityBasePath + '/product/' + this.product.productId
            }
        });
    }
    
    //added
    MoveFeaturedProductsToDataLayer(data){
        HomePageEvent('select_content','Home',data);
    }
}