import { LightningElement, api, track } from 'lwc';
import LB2B_MultipleEmailError from '@salesforce/label/c.LB2B_MultipleEmailError';
import LB2B_MultipleEmailLabel from '@salesforce/label/c.LB2B_MultipleEmailLabel';
import LB2B_MultipleEmailLabelSemiColon from '@salesforce/label/c.LB2B_MultipleEmailLabelSemiColon';
import LB2B_MultipleEmailLabelTwo from '@salesforce/label/c.LB2B_MultipleEmailLabelTwo';



export default class MyComponent extends LightningElement {

    @track emailInput;

    labels = {
      LB2B_MultipleEmailError,
      LB2B_MultipleEmailLabel,
      LB2B_MultipleEmailLabelSemiColon,
      LB2B_MultipleEmailLabelTwo
    }
  
      //---------- Multiple Email ID's------------//
      
      validateEmail(email) {
         // let emailRegex = /^[a-zA-Z]+[0-9]*@[a-zA-Z]+\.[a-zA-Z]{2,}$/;
          let regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          let emails = email.split(';');
          console.log('this.emails emails>>>',emails);
          let invalidEmails = [];
          console.log('this.invalidEmails >>>',invalidEmails);
          for (let i = 0; i < emails.length; i++) {
             // if (!emailRegex.test(emails[i].trim())) {
            if (emails[i] == "" || ! regex.test(emails[i])) { 
                  invalidEmails.push(emails[i]);
              }
          }
          console.log('this.invalidEmails2 >>>',invalidEmails);
          if (invalidEmails.length > 0) {
              return LB2B_MultipleEmailError;
          }
          
          return null;
      }
      isDisable = false;
      handleEmailInput(event) {
        this.emailInput = event.target.value;
        this.isDisable = true;
        console.log('this.emailInput >>>',this.emailInput,' >>> ', this.emailInput.length);
       // this.emailInput.length === 0 ? this.template.querySelector('.email-validation-message').textContent = "" : "";
        const selectEvent = new CustomEvent('changeonemailchange', {
            detail: {emails: '',
            isDisable: this.emailInput.length !== 0 ? true : false}
            });
        this.dispatchEvent(selectEvent);


          let emailValidationMessage = this.validateEmail(this.emailInput);

            console.log('emailValidationMessage >>>',emailValidationMessage);
        
          
          if (emailValidationMessage) {
              // Display the error message
            //   if(this.emailInput.length == 0){
            //     alert('inside 49');
            //     this.template.querySelector('.email-validation-message').textContent = "";
            // } else {
            //     this.template.querySelector('.email-validation-message').textContent = emailValidationMessage;
            // }
            this.template.querySelector('.email-validation-message').textContent = this.emailInput.length === 0 ? "" : emailValidationMessage;
          } else {
              // Clear the error message
              this.template.querySelector('.email-validation-message').textContent = "";
              this.isDisable = false;
              selectEvent.detail.emails = this.emailInput;
              selectEvent.detail.isDisable = false;
              this.dispatchEvent(selectEvent);
          }
      }
}