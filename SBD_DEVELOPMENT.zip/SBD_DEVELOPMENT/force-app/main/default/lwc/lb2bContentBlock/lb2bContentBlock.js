import { LightningElement, api } from 'lwc';
export default class Lb2bContentBlock extends LightningElement {
    hasLink;

    @api
    property;

    get alignmentContainerClass() {
        if (this.property.media) {
            if (this.property.media.type === 'Video') {
                return 'block-container video';
            } else if (this.property.media.type === 'Image') {
                return 'block-container image';
            }
        } else {
            return 'block-container';
        }
    }

    get alignmentImageClass() {
        if (this.property.media) {
            if (this.property.media.alignment === 'Right') {
                return 'image-box-container right-align';
            } else if (this.property.media.alignment === 'Left') {
                return 'image-box-container left-align';
            }
        } else {
            return 'image-box-container center-align';
        }
    }
}