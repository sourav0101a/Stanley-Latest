import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Lb2bCreateEditUserInfo extends LightningElement {

    name;
    soldToAccount;
    shipToAccount;
    @api recordId;
    @track createEdit;
    @track modalHeading;
    @track createdOrUpdated = false;

    @api
    get isCreateEdit() {
        return this.createEdit;
    }

    set isCreateEdit(value) {
        this.createEdit = value.createEditModal;
        this.recordId = value.record != undefined ? value.record.Id : '';
        this.name = value.record != undefined ? value.record.User__c : '';
        this.soldToAccount = value.record != undefined ? value.record.Sold_To_SAP_Account__c : '';
        this.shipToAccount = value.record != undefined ? value.record.Ship_To_SAP_Account__c : '';
        this.modalHeading = (this.recordId == undefined || '') ? 'New User SAP Account' : 'Update User SAP Account';
    }

    closeModal(event) {
        this.createEdit = false;
        const closeEvent = new CustomEvent("closemodalvalue", {
            detail: this.createdOrUpdated
        });
        this.dispatchEvent(closeEvent);
    }

    handleSucess(event) {
        let message = (this.recordId == undefined || '') ? 'Record created' : 'Record updated';
        this.createdOrUpdated = true;
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success',
            }),
        );
        this.closeModal();
    }
}