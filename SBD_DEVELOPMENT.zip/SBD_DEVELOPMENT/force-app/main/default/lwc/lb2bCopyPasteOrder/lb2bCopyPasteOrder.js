import { LightningElement, track, api } from 'lwc';
import communityId from '@salesforce/community/Id';
import { NavigationMixin } from 'lightning/navigation';
import upload_title from '@salesforce/label/c.LB2BUpload_Product_To_Cart';
import upload_note from '@salesforce/label/c.LB2BUpload_Note';
import attach_csv from '@salesforce/label/c.LB2BAttach_CSV';
import upload_result from '@salesforce/label/c.LB2BUpload_Result';
import upload_sku from '@salesforce/label/c.LB2BUpload_Sku';
import upload_qty from '@salesforce/label/c.LB2BUpload_Qty';
import upload_notes from '@salesforce/label/c.LB2BUpload_Notes';
import upload_limits from '@salesforce/label/c.LB2BUpload_Limits';
import upload_qty_required from '@salesforce/label/c.LB2BUpload_Quantity_required';
import upload_added_all from '@salesforce/label/c.LB2BUpload_Added_All';
import LB2BCopyPasteDiscrp from '@salesforce/label/c.LB2BCopyPasteDiscrp';
import LB2BCopyPaste from '@salesforce/label/c.LB2BCopyPaste';
import LB2BCopyPasteError from '@salesforce/label/c.LB2BCopyPasteError';
import LB2BAddToCart from '@salesforce/label/c.LB2BAddToCart';
import LB2BGoToCart from '@salesforce/label/c.LB2BGoToCart';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
import addToCart from '@salesforce/apex/LB2BCSVUploaderController.addToCart';
import { toastUtil } from 'c/lb2bUtil';
import {callDataLayerEvent} from 'c/lb2bDataLayer';
import {addtocartEvent} from 'c/lb2bDataLayer';

const columns = [
    { label: upload_sku, fieldName: 'sku' },
    { label: upload_qty, fieldName: 'qty' },
    {
        label: upload_notes,
        fieldName: 'notes',
        cellAttributes: { class: { fieldName: 'notesColor' }, wrapText: true }
    }
];

export default class Lb2bCopyPasteOrder extends NavigationMixin(LightningElement) {
    tableData = [];
    columns = columns;
    index = 0;
    isAddedtoCart = false;
    cartId;
    isAllSkuInvalid;

    label = {
        upload_title,
        upload_sku,
        upload_qty,
        upload_notes,
        upload_note,
        attach_csv,
        upload_result,
        upload_limits,
        upload_qty_required,
        upload_added_all,
        LB2BCopyPasteDiscrp,
        LB2BCopyPaste,
        LB2BCopyPasteError,
        LB2BAddToCart,
        LB2BGoToCart,
        LB2BLoading
    };

    uploadFile(event) {
        var v = this;
        console.log('the first v', v);
        v.uploadInfo = [];
        v.inputData = [];

        var data = event.target.value;
        console.log('pasted items ', data);

        if (data && data.length > 0) {
            v.disabled = false;
        } else {
            v.disabled = true;
        }
        console.log('length', data.length);
        var allRows = data.split(/\r?\n/);

        var start = 0;
        console.log('all rows ', allRows);

        if (allRows[0] && allRows[0].indexOf('SKU,Quantity') == 0) {
            start = 1;
            console.log('inside if');
        }

        for (var singleRow = start; singleRow <= allRows.length; singleRow++) {
            var rowCells = allRows[singleRow].replace('\t', ',').split(',');
            if (rowCells.length > 1) {
                let qty = rowCells[1].trim();
                console.log('inside if', qty);
                if (qty == '') {
                    let item = {};
                    item.sku = rowCells[0];
                    item.qty = rowCells[1];
                    if (qty == '') {
                        v.showAllSuccessMessage = false;
                        item.notesColor = 'slds-text-color_error';
                        item.notes = v.label.upload_qty_required;
                    }

                    v.inputData.push(item);
                } else if (qty !== null && parseInt(qty) > 0) {
                    v.uploadInfo.push({ sku: rowCells[0], quantity: rowCells[1].trim() });
                }
            }
        }
    }

    addToCart(event) {
        var dataSet = JSON.stringify(this.uploadInfo);
        console.log('add to cart(String):', this.uploadInfo);
        this.isLoading = true;

        if (this.uploadInfo.length != 0) {
            addToCart({
                data: dataSet,
                communityId: communityId,
                effectiveAccountId: this.effectiveAccountId,
                isChecked: this.template.querySelector(`[data-id="input-checkbox"]`).checked
            })
                .then((result) => {
                    this.isLoading = false;

                    if (result.isSuccess) {
                        this.isAllSkuInvalid = 0;
                        console.log('result:', result.data);
                        if (this.showAllSuccessMessage) {
                            result.data.forEach((element) => {
                                if (!element.isSuccess) {
                                    this.showAllSuccessMessage = false;
                                    return;
                                }
                            });
                        }
                        for(let i=0 ; i < result.data.length ; i++){
                            if(result.data[i].cartId) {
                                this.cartId = result.data[i].cartId;
                                break;
                            }
                        }
                        result.data.forEach((element) => {
                            let item = {};
                            item.sku = element.sku;
                            item.qty = element.quantity;
                            item.notes = element.message;
                            item.notesColor = element.isSuccess ? 'slds-text-color_success' : 'slds-text-color_error';
                            this.inputData.push(item);

                            //code for google tags data layer starts  
                            if (!element.isSuccess) {
                                this.isAllSkuInvalid += 1;
                                callDataLayerEvent('site_error', element.sku, element.quantity, element.message, 'Tab Entry');
                            }
                            if (element.isSuccess) {
                                this.index = this.index + 1;
                                addtocartEvent('add_to_cart',null, null, element.sku,null, null, null, null, this.index, element.quantity);
                            }
                            //code for google tags data layer ends
                        });
                        this.isAddedtoCart = result.data.length === this.isAllSkuInvalid ? false : true;
                        this.index = 0;

                        if (this.showAllSuccessMessage) {
                            toastUtil.toastSuccess(this, { message: this.label.upload_added_all });
                        }

                        this.tableData = this.inputData;
                        if (this.tableData.length > 0) {
                            this.showTable = true;
                        }

                        this.dispatchEvent(
                            new CustomEvent('cartchanged', {
                                bubbles: true,
                                composed: true
                            })
                        );
                    } else {
                        toastUtil.toastError(this, { message: result.message });
                    }
                })
                .catch((error) => {
                    this.isLoading = false;
                    let message = error && error.body && error.body.message;
                    toastUtil.toastError(this, { message: message });
                });
        } else {
            let message = this.label.LB2BCopyPasteError;
            toastUtil.toastError(this, { message: message });
        }
    }

    //   @track inputvalue;

    //     handleChange(event){
    //         this.inputvalue = event.target.value;
    //         console.log('++++',this.inputvalue);
    //         if(this.inputvalue > 0){
    //             this.Buttontrue=false;
    //         }
    //     }

    uploadInfo = [];

    inputData = [];

    @api
    effectiveAccountId;

    @track
    isLoading = false;
    @track
    disabled = true;
    @track
    showTable = false;

    showAllSuccessMessage = true;

    goToCart() {
        let url = window.location.origin + window.location.pathname;
        let newUrl = url.replace(/quick-order/, 'cart/') + this.cartId;
        this.navigateToCartPage(newUrl);
    }
    navigateToCartPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }
}