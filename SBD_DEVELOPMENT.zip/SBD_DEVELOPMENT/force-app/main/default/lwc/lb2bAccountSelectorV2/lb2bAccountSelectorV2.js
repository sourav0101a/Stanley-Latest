import { LightningElement, api, wire, track } from 'lwc';
import { fireEvent } from 'c/lb2bPubSub';
import { registerListener } from 'c/lb2bPubSub';
import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';

import isAccountSuperUser from '@salesforce/customPermission/Account_Superuser';

// Salesforce fields
import UserId from '@salesforce/user/Id';
import BASE_PATH from '@salesforce/community/basePath';

// Apex classes
import getUserAccounts from '@salesforce/apex/LB2BAccountSelectorController.getUserAccounts';
// import getUserAccounts from '@salesforce/apex/LB2BAccountSelectorController.getUserAccounts2';
import updateCartRecord from '@salesforce/apex/LB2BAccountSelectorController.updateCartAccounts';
import getCartAccounts from '@salesforce/apex/LB2BAccountSelectorController.getCartAccounts';

// Translation labels
import AccountName from '@salesforce/label/c.LB2BAccountName';
import Address from '@salesforce/label/c.LB2BAddress';
import AccountNumber from '@salesforce/label/c.LB2BAccountNumber';
import CompanyName from '@salesforce/label/c.LB2BCompanyName';
import AccountSelectPrompt from '@salesforce/label/c.LB2BAccountSelectPrompt';
import SelectAccount from '@salesforce/label/c.LB2BSelectAccount';
import PleaseChooseOne from '@salesforce/label/c.LB2BPleaseChooseOne';

// CSS loads
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle } from 'lightning/platformResourceLoader';

const EVENT_NAME = 'accountDependency';

export default class Lb2bAccountSelectorV2 extends NavigationMixin(LightningElement) {
    // #region Typedefs
    /**
     * Dependency information for account selector
     *
     * @typedef {Object} DependencyData
     *
     * @property {string} fromAccountType
     * The account type of the component sending the dependency data
     *
     * @property {string} accountSelected
     * The Salesforce ID (or the string 'null' if none) of the SAP account
     * that is being sent as a driver for the dependency.
     */

    /**
     * Details about an SAP Account sent from Salesforce as part of a Ship To
     * and Sold To pair the user can select
     *
     * @typedef {Object} AccountInfo
     *
     * @property {string} accountName
     * The SAP Account Name for the account.  This is displayed to the user
     * in the dropdown list as the label of the value-label pair
     *
     * @property {string} sapAccountId
     * The Salesforce SAP Account (Erp_Account__c) record ID.  This is used
     * when writing to the WebCart record the Ship To and Sold To account
     * lookup fields.
     *
     * @property {string} streetAddress
     * The 911 number and street of the location.  This is displayed as the
     * first line of the address on the Ship to address block of test
     *
     * @property {string} city
     * The city of the location.  This is displayed in the second line of
     * the address on the Ship to address block of text
     *
     * @property {string} state
     * The state of province of the location.  This is displayed in the
     * second line of the Ship To address block of text
     *
     * @property {string} postalCode
     * This is the zip/postal code of the location.  This is displayed
     * in the Ship To address block of text
     *
     * @property {string} country
     * The country of the location.  This is displayed in the Ship To
     * address block of text.
     *
     * @property {string} sapNumber
     * 10 digit SAP Account number
     */

    /**
     * Data sent in the form of a wrapper class about a ship to and sold to
     * account combination that is valid for the current user.
     *
     * @typedef {Object} UserAccount
     *
     * @property {string} companyName
     * The name on the master account that both SAP accounts reference
     *
     * @property {AccountInfo} soldToAccountInfo
     * Information about the Sold To SAP account
     *
     * @property {AccountInfo} shipToAccountInfo
     * Information about the Ship To SAP account
     */

    /**
     * Key value pairs for the dropdown list
     *
     * @typedef {Object} SelectOption
     *
     * @property {string} value
     * A concatenation of the account type, the pipe character, and the SFDC ID
     * of the SAP Account that is selected.  The account type is added so that
     * we do not have duplicates values between the two dropdowns on the Checkout
     * page since a user can select the same SAP Account for Ship To and Sold To
     *
     * @property {string} label
     * A user friendly version for the dropdown display.  This is the SAP Account
     * Name that is given from Salesforce.
     */
    // #endregion

    /**
     * A collection of labels that are used in the page for localization and
     * internationalization.
     */
    label = {
        AccountName,
        Address,
        AccountNumber,
        CompanyName,
        AccountSelectPrompt,
        SelectAccount,
        PleaseChooseOne
    };

    /**
     * A reference to the current page.  This is utilized by the Pubsub
     * communcation between the dropdown boxes.
     */
    @wire(CurrentPageReference) pageRef;

    /**
     * Data incoming from an instance of this component about this instance should
     * apply filters to its dropdown list
     *
     * @type DependencyData
     */
    incomingDependencyData;

    /**
     * Data outgoing from this instance to another instance of this component about
     * how it should apply filters to its dropdown list.
     *
     * @type DependencyData
     */
    outgoingDependencyData;

    /**
     * Indicates whether this component is functioning as a sold to or ship to.
     *
     * Possible values: 'SoldTo' or 'ShipTo' ONLY.
     *
     * @type {string}
     */
    @api accountType;

    /**
     * Indicates where this component is being used.
     *
     * Possible values or 'Cart' or 'Query'
     */
    @api usage;
    @api hidelink;

    /**
     * ID of the cart
     *
     * @type {string}
     */
    @api cartId;

    @api customLabel;

    @track hideAccount = false;

    ishandleChange = false;

    pricingAccounts;
    /**
     * Wrapper for account data to show on the user interface
     *
     * @type {AccountInfo}
     */
    _selectedErpAccount = '';

    @api
    get selectedErpAccount() {
        if (this._selectedErpAccount) {
            this._selectedErpAccount.sapNumber = this.cleanSapNumber(
                this._selectedErpAccount.sapNumber
            );
            return this._selectedErpAccount;
        } else {
            return '';
        }
    }

    set selectedErpAccount(value) {
        this._selectedErpAccount = value;
        this.dispatchEvent(
                  new CustomEvent('getsapaccountvalue', {
                     detail: this._selectedErpAccount
                   })
                 );
    }

    get selectorLabel() {
        if (this.customLabel) {
            return this.customLabel;
        } else {
            return this.label.SelectAccount;
        }
    }

    /**
     * The name of the company for the selected Sold To SAP Account.
     *
     * @type {string}
     */
    selectedCompanyName;

    /**
     * Selected SAP Account SFDC Id to send to the cart.  Depending on the account type,
     * this could be used for the sold to or ship to account.
     *
     * @type {string}
     */
    selectedErpAccountId;

    /**
     * List of User SAP Accounts retrieved from salesforce
     *
     * @type {Array<UserAccount>}
     */
    userErpAccountList;

    /**
     * Options to be displayed in the dropdown list
     */
    _selectOptions = [];

    hasAccess = isAccountSuperUser;

    pointOfPurchase;
    @track isPop;

    // #region Getters
    /**
     * Indicates if this component is functioning as a ship to selector.
     *
     * @type {boolean}
     */
    get isShipToSelector() {
        return this.accountType == 'ShipTo' && !this.hideAccount;
    }

    /**
     * Indicates if this component is functioning as a sold to selector.
     *
     * @type {boolean}
     */
    get isSoldToSelector() {
        return this.accountType == 'SoldTo';
    }

    /**
     * Returns true if an account is selected from the dropdown.
     *
     * @type {boolean}
     */
    get isAccountSelected() {
        return this.selectedErpAccountId !== undefined;
    }

    /**
     * Returns true if the selector should be required
     *
     * @type {boolean}
     */
    get isSelectorRequired() {
        if (this.usage == 'Cart') {
            return true;
        } else if (this.usage == 'Query') {
            return this.accountType == 'SoldTo';
        } else {
            return true;
        }
    }

    /**
     * Returns true if the usage of this component is in the cart
     *
     * @type {boolean}
     */
    get isCartUsage() {
        return this.usage == 'Cart';
    }

    get isPricingAccSelectorUsage() {
        return this.hidelink == 'pricingAccSelector';
    }

    @api retainSelectedAccs(type) {
        this.pricingAccounts = localStorage.getItem('pricingaccounts_');
        if (this.pricingAccounts !== undefined && this.pricingAccounts !== null) {
            let value = this.pricingAccounts.split(',,');
            console.log('pricingaccounts_',value)
            let soldToInfo = value[0].split('|');
            if (value[1] != UserId) {
                localStorage.removeItem('pricingaccounts_');
            }
            else if (type == 'SoldTo') {
                this.accountType = 'SoldTo';
                this.selectedErpAccount = this.getErpAccountById(soldToInfo[1]);
                this.selectedErpAccountId = soldToInfo[1];
                this.template.querySelector('c-lb2b-searchable-dropdown').setValue(this.cleanSapNumber(soldToInfo[2]) + ' - ' + soldToInfo[3]);
            }

        }
    }
    
    get hasAddress() {
        if (!this.selectedErpAccount) {
            return false;
        }

        const address =
            this.selectedErpAccount.city +
            this.selectedErpAccount.country +
            this.selectedErpAccount.postalCode +
            this.selectedErpAccount.state +
            this.selectedErpAccount.streetAddress;

        return address.length > 5;
    }

    /**
     * Returns an array of values to be displayed in the dropdown list,
     * or an error message if there are none
     */
    @api
    get selectOptions() {
        // console.log('SelectOptions:', this._selectOptions);
        // if (this._selectOptions && this._selectOptions.length > 0) {
        //     return this._selectOptions;
        // } else {
        //     return [{ value: this.accountType + '|err', label: 'Error' }];
        // }
        return this._selectOptions;
    }

    set selectOptions(val) {
        this._selectOptions = val;
    }

    get initialValue() {
        return this.accountType + '|null';
    }
    // #endregion

    async connectedCallback() {
        registerListener('multipleShipTo', this.handleMultipleShipTo, this);
        registerListener(EVENT_NAME, this.handleDependencyEvent, this);
        registerListener('isPop', this.handlePop, this);
        this.getAccountOptions().then((result) => this.optionPopulate(result, true));
    }

    handleMultipleShipTo(row) {
        if (this.accountType == 'ShipTo') {
            if (row.length == 1) {
                this.selectedErpAccount = this.getErpAccountById(row[0].sapAccountId);
                this.selectedErpAccountId = row[0].sapAccountId;
                this.template
                    .querySelector('c-lb2b-searchable-dropdown')
                    .setValue(this.cleanSapNumber(row[0].sapNumber) + ' - ' + row[0].accountName);
                this.updateCart(row[0], false);
                this.hideAccount = false;
            } else {
                this.template.querySelector('c-lb2b-searchable-dropdown').setValue(PleaseChooseOne);
                this.hideAccount = true;
                this.updateCart(null, true);
            }
        }
    }

    handlePop(value) {
        this.pointOfPurchase = value;
        this.isPop =
            this.accountType == 'ShipTo' && this.pointOfPurchase == 'LB2BPointofPurchase'
                ? true
                : false;
        if (this.pointOfPurchase == 'LB2BPointofPurchase') {
            this.getAccountOptions().then((result) => this.optionPopulate(result, true));
        }
    }

    renderedCallback() {
        loadStyle(this, GlobalCSS);
    }

    // #region Pubsub communication
    fireDependencyEvent() {
        fireEvent(this.pageRef, EVENT_NAME, this.outgoingDependencyData);

        if (this.outgoingDependencyData.accountSelected == 'null') {
            this.optionPopulate(this.userErpAccountList, false);
        }
    }

    handleDependencyEvent(dependencyData) {
        // If this dropdown sent the event, we can ignore it
        if (dependencyData.fromAccountType == this.accountType) {
            return;
        }

        this.incomingDependencyData = dependencyData;
        this.populateOptionsFromDependency();
    }
    // #endregion

    /**
     * Populates the dropdown list based on a selected SAP Account from the other
     * dropdown, or 'null' if the default option of ' -- ' was selected to reset
     * the dependency.
     */
    populateOptionsFromDependency() {
        let dependencyOptions = [];

        if (this.incomingDependencyData.accountSelected == 'null') {
            dependencyOptions = this.userErpAccountList;
        } else {
            if (this.accountType == 'SoldTo') {
                dependencyOptions = this.userErpAccountList.filter(
                    (acct) =>
                        acct.shipToAccountInfo.sapAccountId ==
                        this.incomingDependencyData.accountSelected
                );
            } else if (this.accountType == 'ShipTo') {
                dependencyOptions = this.userErpAccountList.filter(
                    (acct) =>
                        acct.soldToAccountInfo.sapAccountId ==
                        this.incomingDependencyData.accountSelected
                );
            }
        }
        this.optionPopulate(dependencyOptions, false);

        if (this.incomingDependencyData.accountSelected == 'null') {
            this.template.querySelector('c-lb2b-searchable-dropdown').setValue('');
            this.selectedErpAccountId = undefined;
        }

        this.incomingDependencyData = {
            fromAccountType: 'type',
            accountSelected: 'null'
        };
    }

    /**
     * Retrieves possible pairs of SAP Accounts for the given user.
     *
     * @returns {Promise<Array<UserAccount>>} A promise of a list
     * of User Account instances
     */
    async getAccountOptions() {
        return (
            getUserAccounts({ userId: UserId })
                // return getUserAccounts()
                .then((result) => {
                    return result;
                })
                .catch((error) => {
                    // TODO: Add toast message with error
                    console.error(error);
                    return [];
                })
        );
    }

    /**
     * Provides the dropdown with its initial data before considering any default options,
     * currently selected data in the cart, or dependency data.
     *
     * @param {Array<UserAccount>} res
     * A list of User Accounts
     *
     * @param {boolean} updateErpAccountList
     * Whether or not to update the full list of User Accounts.  Updating
     * this should only happen during the Connected Callback of the lifecycle.  Future
     * updates will result in instability
     */
    optionPopulate(res, updateErpAccountList) {
       
        let options = [];
        let sfIds = [];
        let shipTo = [];

        for (let userAcct of res) {
            // Select the correct SAP account based on the account type
            let myAcct = this.getSapAccount(userAcct, undefined);

            // Due to how we are storing data, duplicates are possible and expected to happen,
            // so lets only grab one of each account
            if (sfIds.includes(myAcct.sapAccountId)) {
                // We already have this account in this drop down, we can skip it
                continue;
            } else {
                sfIds.push(myAcct.sapAccountId);

                //send ship to account for multiple location functionality
                if (this.accountType == 'ShipTo' && this.pointOfPurchase == 'LB2BPointofPurchase'){
                    shipTo.push(myAcct);
                }

                // Set description of option
                let description = '';
                if (myAcct.streetAddress != undefined) {
                    description =
                        myAcct.streetAddress + ' ' + myAcct.city + ' ' + myAcct.postalCode;
                }

                if (myAcct.streetAddress != undefined && myAcct.brand != undefined) {
                    description += ' - ' + myAcct.brand;
                }

                if (myAcct.streetAddress == undefined && myAcct.brand != undefined) {
                    //description = myAcct.brand;
                    description = myAcct.city + ' ' + myAcct.postalCode + ' - ' + myAcct.brand;
                }
                if (myAcct.streetAddress == undefined && myAcct.brand == undefined) {
                    description = myAcct.city + ' ' + myAcct.postalCode;
                }
                if (
                    myAcct.streetAddress == undefined &&
                    myAcct.brand == undefined &&
                    myAcct.city == undefined &&
                    myAcct.postalCode == undefined
                ) {
                    description = null;
                }

                options.push({
                    label: this.cleanSapNumber(myAcct.sapNumber) + ' - ' + myAcct.accountName,
                    description: description,
                    value: this.accountType + '|' + myAcct.sapAccountId + '|' + userAcct.isPersonal,
                    search: myAcct.searchableText
                });
              
            }
          
        }

        //send ship to account for multiple location functionality
        if (this.accountType == 'ShipTo' && this.pointOfPurchase == 'LB2BPointofPurchase') {
            // if(this.accountType == 'ShipTo' && (this.pointOfPurchase == 'LB2BPointofPurchase' || this.pointOfPurchase == 'LB2BFinishedGoods')){
            const multipleAcctShipTo = this.template.querySelector(
                'c-lb2b-ship-to-multiple-locations'
            );
            multipleAcctShipTo.multipleShitpToLocations(shipTo);
        }

        if (updateErpAccountList) {
            this.userErpAccountList = res;

            if (this.usage == 'Cart') {
                this.getCurrentCart();
            }

            //TCOM-2958 Account Selector - Prepopulate for Direct Customers
           if(this.userErpAccountList.length === 1){
                this.setAccount(this.userErpAccountList[0], true);

                //For pricing account selector
                let soldToAccountname = this.userErpAccountList[0].soldToAccountInfo.sapNumber +'|'+this.userErpAccountList[0].soldToAccountInfo.accountName;
                localStorage.setItem('pricingaccounts_', 'SoldTo' + '|' + this.userErpAccountList[0].soldToAccountInfo.sapAccountId + '|'+soldToAccountname +',,'+ UserId);
        
                const evt = new CustomEvent('accountselected', {
                    detail: this.userErpAccountList[0].soldToAccountInfo.sapNumber                   
                });
                this.usage === 'Cart' ? this.dispatchEvent(evt):'';
            } //2958 ends        
        }

     if(this.selectedErpAccountId === undefined){ //Retain pricing account selector from local storage
        fireEvent(this.pageRef, 'notifyPricingAccSelector', this.accountType);
     }
        
        // Set the options for the drop down now
        this._selectOptions = [];
        this.selectOptions = [...options];
        const acctSelector = this.template.querySelector('c-lb2b-searchable-dropdown');
        acctSelector.setOptions(options);
       
        
    }

    /**
     * Retreives the currently chosen Ship To and Sold To SAP Accounts in the cart.
     *
     * This function also handles pre-selecting options in the dropdowns if the
     * Ship_To_SAP_Account__c and Sold_To_SAP_Account__c fields are populated OR
     * selecting the only option allowed if the current user only has a single
     * combination.
     */
    getCurrentCart() {
       
        getCartAccounts({ cartId: this.cartId })
            .then((result) => {
                if (result == null) {
                    return;
                }
             
                let shipToNumberFromCart = result.ensxb2b__sap_DeliverTo_PartnerNumber__c;
                let soldToNumberFromCart = result.ensxb2b__sap_BillTo_PartnerNumber__c;

                //For multiple shipto address
                if (result.LB2BMultiple_ShipTo_Ids__c != undefined) {
                    if (this.accountType == 'ShipTo') {
                        const multipleAcctShipTo = this.template.querySelector(
                            'c-lb2b-ship-to-multiple-locations'
                        );
                        multipleAcctShipTo.multipleShitpToIds(result.LB2BMultiple_ShipTo_Ids__c);
                    }
                    if (this.accountType == 'SoldTo') {
                        let userAcctFound = this.userErpAccountList.filter(
                            (userAcct) =>
                                this.cleanSapNumber(userAcct.soldToAccountInfo.sapNumber) ==
                                soldToNumberFromCart
                        )[0];
                        this.setAccount(userAcctFound, false);
                    }
                }

                // Check if account information is return from the cart
                else if (
                    (this.accountType == 'SoldTo' && soldToNumberFromCart == null) ||
                    (this.accountType == 'ShipTo' && shipToNumberFromCart == null)
                ) {
                    if (this.userErpAccountList.length == 1) {
                        this.setAccount(this.userErpAccountList[0], true);
                    } else {
                        // Do nothing- stick with placeholder
                        return;
                    }
                } else {
                    // Populate dropdown with existing data in cart
                    let userAcctFound = this.userErpAccountList.filter(
                        (userAcct) =>
                            this.cleanSapNumber(userAcct.shipToAccountInfo.sapNumber) ==
                                this.cleanSapNumber(shipToNumberFromCart) &&
                            this.cleanSapNumber(userAcct.soldToAccountInfo.sapNumber) ==
                                this.cleanSapNumber(soldToNumberFromCart)
                    )[0];
                    this.setAccount(userAcctFound, false);
                }
            })
            .catch((error) => {
                // TODO: Add toast message with error
                console.error(error);
            });
    }

    setRetryCount = 0;

    @api
    setSelectedAccount(sapAccountNumber) {
        let dropdown = this.template.querySelector('c-lb2b-searchable-dropdown');

        if (!dropdown) {
            console.error('No dropdown found');
            return;
        }

        if (this.userErpAccountList && this.userErpAccountList.length > 0) {
            if (this.isSoldToSelector) {
                this.selectedErpAccountId =
                    this.userErpAccountList.filter(
                        (x) =>
                            this.cleanSapNumber(x.soldToAccountInfo.sapNumber) == sapAccountNumber
                    )[0].soldToAccountInfo.sapAccountId || undefined;

                if (this.selectedErpAccountId) {
                    this.selectedErpAccount = this.getErpAccountById(this.selectedErpAccountId);
                }
            }
            if (this.isShipToSelector) {
                this.selectedErpAccountId =
                    this.userErpAccountList.filter(
                        (x) =>
                            this.cleanSapNumber(x.shipToAccountInfo.sapNumber) == sapAccountNumber
                    )[0].shipToAccountInfo.sapAccountId || undefined;

                if (this.selectedErpAccountId) {
                    this.selectedErpAccount = this.getErpAccountById(this.selectedErpAccountId);
                }
            }
        }

        dropdown.setValue(
            (this.selectedErpAccount.sapNumber || '') +
                ' - ' +
                (this.selectedErpAccount.accountName || '')
        );
    }

    /**
     * Populates the dropdown's selected option and optionally sends an update
     * request to the backend to updatupdateCarte fields in the cart.
     *
     * @param {UserAccount} accountWrapper
     * The UserAccount record to use to populate the dropdown.
     *
     * @param {boolean} doUpdateCart
     * Whether or not to send an update request to make changes to the cart.
     * This is not necessary if we are reading from Salesforce and pre-populating
     * already selected options for Ship To and Sold To accounts.
     */
    setAccount(accountWrapper, doUpdateCart) {
        let dropdown = this.template.querySelector('c-lb2b-searchable-dropdown');

        if (!dropdown) {
            return;
        }

        let acct = this.getSapAccount(accountWrapper);
        dropdown.setValue(this.cleanSapNumber(acct.sapNumber) + ' - ' + acct.accountName);
        this.selectedErpAccountId = acct.sapAccountId;
        this.selectedErpAccount = this.getErpAccountById(this.selectedErpAccountId);

        if (this.accountType == 'SoldTo') {
            this.selectedCompanyName = accountWrapper.companyName;
        }

        if (this.usage == 'Cart' && doUpdateCart) {
            this.updateCart(this.selectedErpAccount, false);
        } else {
            // console.log('Skipping update cart');
        }

        //Modified
        this.outgoingDependencyData = {
            fromAccountType: this.accountType,
            accountSelected:
                this.selectedErpAccountId != undefined ? this.selectedErpAccountId : null,
            isPersonal: accountWrapper.isPersonal,
            sapNumber: accountWrapper.sapNumber
        };
        this.fireDependencyEvent();
    }

    /**
     * Event handler for when the dropdown box selection changes.
     * This updates the component's api property and displays the account information
     * on the screen.
     */
    handleAccountChanged(event) {
        this.ishandleChange = true;
        const selection = event.detail.value;
        const valueArr = selection.split('|');

        this.outgoingDependencyData = {
            fromAccountType: this.accountType,
            accountSelected: valueArr[1],
            isPersonal: valueArr[2],
            sapNumber:event.detail.label
        };
        this.fireDependencyEvent();

        if (valueArr[1] == 'null') {
            this.selectedErpAccountId = undefined;
            this.selectedErpAccount = undefined;

            if (this.usage == 'Cart') {
                this.updateCart(null, true);
            }
        } else {
            this.hideAccount = false;
            this.selectedErpAccountId = valueArr[1];
            this.selectedErpAccount = this.getErpAccountById(this.selectedErpAccountId);

            if (valueArr[0] == 'SoldTo') {
                // Set company name for sold to selection
                let userAcct = this.userErpAccountList.filter(
                    (a) => a.soldToAccountInfo.sapAccountId == this.selectedErpAccountId
                )[0];
                this.selectedCompanyName = userAcct.companyName;
            }

            if (this.usage == 'Cart') {
                this.updateCart(this.selectedErpAccount, false);
            }
        }
    
        const evt = new CustomEvent('accountselected', {
            //detail: this.accountType + '|' + this.selectedErpAccountId
            // Modified To send Sap Number to orderhistory component
            detail: this.selectedErpAccount.sapNumber
        });
        this.dispatchEvent(evt);

        //For pricing account selector
        const pricingEvt = new CustomEvent('pricingaccount', {
            detail: this.accountType + '|' + this.selectedErpAccountId + '|' + this.selectedErpAccount.sapNumber + '|' + this.selectedErpAccount.accountName
        });
        this.dispatchEvent(pricingEvt);
       
        this.updateCart(this.selectedErpAccount, false);
    }

    /**
     * Finds and returns the correct AccountInfo instance based on a Salesforce ID
     * and the account type of this dropdown.
     *
     * @param {string} salesforceId
     * The Salesforce ID of the SAP Account
     *
     * @returns {AccountInfo} The matching AccountInfo instance.
     */
    getErpAccountById(salesforceId) {
        if (salesforceId == 'null') {
            return null;
        } else {
            return this.getSapAccount(undefined, salesforceId);
        }
    }

    /**
     * Sends a request to the apex xontroller to update (or reset) the Cart's
     * SAP Account info.
     *
     * @param {AccountInfo} selection
     * @param {boolean} resetFlag
     */
    updateCart(selection, resetFlag) {
        if (resetFlag) {
            // Indicate that the dependency relationship is being reset (one of the
            // two dropdowns was reset to the dashes) and clear out the account data
            // from the cart.
            updateCartRecord({
                cartId: this.cartId,
                sapAccountNumber: null,
                sapAccountId: null,
                accountType: this.hideAccount ? 'ShipTo' : null
            }).catch((error) => {
                // console.log('Error resetting the cart accounts.');
                console.error(error);
                // TODO: Toast error message
            });
        } else {
            if (
                selection &&
                selection.sapNumber &&
                selection.sapAccountId &&
                this.cartId &&
                this.cardId !== ''
            ) {
                updateCartRecord({
                    cartId: this.cartId,
                    sapAccountNumber: selection.sapNumber,
                    sapAccountId: selection.sapAccountId,
                    accountType: this.accountType
                })
                    .then((result) => {
                        console.log('result updating the cart accounts', result);
                    })
                    .catch((error) => {
                        console.log('Error updating the cart accounts', error);
                    });
            }
        }
    }

    /**
     * Extracts the Ship To or Sold To SAP account based on the component instance's
     * accountType value
     *
     * @param {UserAccount} wrapper
     * The wrapper from Salesforce
     *
     * @param {string} sfdcId
     * The SFDC Id of the SAP Account record
     *
     * @returns {AccountInfo} The AccountInfo object for the required account type
     */
    getSapAccount(wrapper, sfdcId) {
        if (this.accountType != 'SoldTo' && this.accountType != 'ShipTo') {
            return null;
        }

        if (wrapper) {
            if (this.accountType == 'SoldTo') {
                return wrapper.soldToAccountInfo;
            } else if (this.accountType == 'ShipTo') {
                return wrapper.shipToAccountInfo;
            }
        } else if (sfdcId) {
            let filterRes;
            if (this.accountType == 'SoldTo') {
                return (filterRes = this.userErpAccountList.filter(
                    (userAcct) => userAcct.soldToAccountInfo.sapAccountId == sfdcId
                )[0]).soldToAccountInfo;
            } else if (this.accountType == 'ShipTo') {
                return (filterRes = this.userErpAccountList.filter(
                    (userAcct) => userAcct.shipToAccountInfo.sapAccountId == sfdcId
                )[0]).shipToAccountInfo;
            }
        }
    }

    cleanSapNumber(acctNumber) {
        return acctNumber.replace(/\b0+/g, '');
    }

    handleAddAccountClicked() {
        this[NavigationMixin.Navigate](
            {
                type: 'standard__webPage',
                attributes: {
                    url: BASE_PATH + '/add-account'
                }
            },
            false
        );
    }

    //clear order history filter soldTo and shipTo
    @api
    clearFilter() {
        this.getAccountOptions().then((result) => this.optionPopulate(result, true));
        this.template.querySelector('c-lb2b-searchable-dropdown').setValue(PleaseChooseOne);
    }
}