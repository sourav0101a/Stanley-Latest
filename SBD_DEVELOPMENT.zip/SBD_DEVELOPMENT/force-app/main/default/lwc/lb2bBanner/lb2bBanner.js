import { LightningElement, api, wire, track } from 'lwc';
import getProductCategoryName from '@salesforce/apex/LB2BGetProductCategory.getProductCategoryName';
import getActiveMetadataCategoryName from '@salesforce/apex/LB2BGetProductCategory.getActiveMetadataCategoryName';

export default class lb2bBanner extends LightningElement {
    @api
    property;
    @api currentUrl = '';
    productId = null;
    @track productCategories = [];
    shouldDisplayBanner = false;
    metadataRecords = [];
    activeMetadataCategories = [];
    isLoading = false;
    connectedCallback() {
        this.isLoading=true;
        this.productId = this.extractProductIdFromUrl();
        console.log('productId Banner', this.productId);
        this.getProductCategories();
    }

    extractProductIdFromUrl() {
        console.log('currenturl', this.currentUrl);
        const urlSegments = this.currentUrl.split('/');
        console.log('urlSegments', urlSegments);
        const lastSegment = urlSegments[urlSegments.length - 1];
        console.log('lastSegment', lastSegment);
        return lastSegment || null;
    }

    getProductCategories() {
        if (this.productId) {
            getProductCategoryName({ productId: this.productId })
                .then(result => {
                    this.productCategories = result;
                    console.log('productCategories inside', this.productCategories);
                    this.fetchActiveMetaDataRecords();
                })
                .catch(error => {
                    console.log('Error in fetching category');
                });

            console.log('productCategories', this.productCategories);
        }
    }

    fetchActiveMetaDataRecords() {
        getActiveMetadataCategoryName()
            .then(result => {
                this.activeMetadataCategories = result;
                console.log('activeMetadataCategories inside', this.activeMetadataCategories);
                this.checkIfDisplayBanner();
            })
            .catch(error => {

            });

        console.log('activeMetadataCategories', this.activeMetadataCategories);

    }

    checkIfDisplayBanner() {

        const categoryNames = this.productCategories;
        console.log('categoryNames', categoryNames);
        this.shouldDisplayBanner = categoryNames.some(category => this.activeMetadataCategories.includes(category));
        console.log('shouldDisplayBanner', this.shouldDisplayBanner);
        
            this.isLoading=false;
        
    }

    handleButtonClick() {
        window.open('https://www.dewalt.com/systems/toughsystem', '_blank');
    }
}