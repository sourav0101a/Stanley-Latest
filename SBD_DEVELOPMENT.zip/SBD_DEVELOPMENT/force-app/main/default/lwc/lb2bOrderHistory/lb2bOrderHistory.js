import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import ShortDate from '@salesforce/i18n/dateTime.shortDateFormat';
import LB2BOrder_History from '@salesforce/label/c.LB2BOrder_History';
import LB2BPONumber from '@salesforce/label/c.LB2BPONumber';
import LB2BSkuNumber from '@salesforce/label/c.LB2BSkuNumber';
import LB2BOrder_Dates from '@salesforce/label/c.LB2BOrder_Dates';
import LB2BSales_Order_Number from '@salesforce/label/c.LB2BSales_Order_Number';
import LB2BShip_To from '@salesforce/label/c.LB2BShip_To';
import LB2BSold_To from '@salesforce/label/c.LB2BSold_To';
import LB2BSales_Re_Filter from '@salesforce/label/c.LB2BSales_Re_Filter';
import LB2BList_Order from '@salesforce/label/c.LB2BList_Order';
import LB2BSearch from '@salesforce/label/c.LB2BSearch';
import LB2BHistorical from '@salesforce/label/c.LB2BHistorical';
import LB2BShipped from '@salesforce/label/c.LB2BShipped';
import LB2BMXIsShipped from '@salesforce/label/c.LB2BMXIsShipped';
import LB2BOnLoanShowOrders from '@salesforce/label/c.LB2BOnLoanShowOrders';
import LB2BPromoDemoMktg from '@salesforce/label/c.LB2BPromoDemoMktg';
import LB2BSalesMktgDemo from '@salesforce/label/c.LB2BSalesMktgDemo';
import LB2BGiveAwayDemo from '@salesforce/label/c.LB2BGiveAwayDemo';
import LB2BStandardOrders from '@salesforce/label/c.LB2BStandardOrders';
import LB2BStandardReturns from '@salesforce/label/c.LB2BStandardReturns';
import LB2BBBFSales from '@salesforce/label/c.LB2BBBFSales';
import LB2BOpenOrders from '@salesforce/label/c.LB2BOpenOrders';
import LB2BOrdersOnHold from '@salesforce/label/c.LB2BOrdersOnHold';
import LB2BBackOrders from '@salesforce/label/c.LB2BBackOrders';
import LB2BOrderNumber from '@salesforce/label/c.LB2BOrderNumber';
import LB2BStatus from '@salesforce/label/c.LB2BStatus';
import LB2BOrderType from '@salesforce/label/c.LB2BOrderType';
import LB2BDocumentDate from '@salesforce/label/c.LB2BDocumentDate';
import LB2BNetAmount from '@salesforce/label/c.LB2BNetAmount';
import LB2BShipToCustomer from '@salesforce/label/c.LB2BShipToCustomer';
import LB2BSoldToCustomer from '@salesforce/label/c.LB2BSoldToCustomer';
import LB2BOnLoan from '@salesforce/label/c.LB2BOnLoan';
import LB2BShowing from '@salesforce/label/c.LB2BShowing';
import LB2BOf from '@salesforce/label/c.LB2BOf';
import LB2BTo from '@salesforce/label/c.LB2BTo';
import LB2BEntries from '@salesforce/label/c.LB2BEntries';
import LB2BInvoice from '@salesforce/label/c.LB2BInvoice';
import LB2BOrderDate from '@salesforce/label/c.LB2BOrderDate';
import LB2BOpen from '@salesforce/label/c.LB2BOpen';
import LB2BError from '@salesforce/label/c.LB2BError';
import LB2BErrorMessage from '@salesforce/label/c.LB2BErrorMessage';
import LB2BNoOrdersMsg from '@salesforce/label/c.LB2BNoOrdersMsg';
import LB2BMandatoryFieldsError from '@salesforce/label/c.LB2BMandatoryFieldsError';
import LB2BSelectShipTo from '@salesforce/label/c.LB2BSelectShipTo';
import LB2BAll from '@salesforce/label/c.LB2BAll';
import LB2BClosed from '@salesforce/label/c.LB2BClosed';
import LB2BOpenWBO from '@salesforce/label/c.LB2BOpenWBO';
import LB2BParShip from '@salesforce/label/c.LB2BPartiallyShipped';
import LB2BParInvoice from '@salesforce/label/c.LB2BPartiallyInvoiced';
import LB2BBlocked from '@salesforce/label/c.LB2BBlocked';
import LB2BPending from '@salesforce/label/c.LB2BPending';
import LB2BCancelled from '@salesforce/label/c.LB2BCancelled';
import LB2BBol from '@salesforce/label/c.LB2BBol';
import LB2BCreditBlock from '@salesforce/label/c.LB2BCreditBlock';
import LB2BExportToExcel from '@salesforce/label/c.LB2BExportToExcel';
import LB2BDropShipCity from '@salesforce/label/c.LB2BDropShipCity';
import LB2BDropShipState from '@salesforce/label/c.LB2BDropShipState';
import LB2BDropShipCountry from '@salesforce/label/c.LB2BDropShipCountry';
import LB2BShipToCustomerName from '@salesforce/label/c.LB2BShipToCustomerName';
import LB2BIsNotAvailable from '@salesforce/label/c.LB2BIsNotAvailable';
import LB2BNotAccess from '@salesforce/label/c.LB2BNotAccess';
import LB2BOk from '@salesforce/label/c.LB2BOk';
import LB2BOrderNumberError from '@salesforce/label/c.LB2BOrderNumberError';
import LB2BSearchCriteria from '@salesforce/label/c.LB2BSearchCriteria';
import LB2BFinishedGoods from '@salesforce/label/c.LB2BFinishedGoods';
import LB2BPage from '@salesforce/label/c.LB2BPage';
import LB2bPrevious from '@salesforce/label/c.LB2bPrevious';
import LB2BNext from '@salesforce/label/c.LB2BNext';
import LB2BListOrderNotes from '@salesforce/label/c.LB2BListOrderNotes';
import LB2BExportAffiliate from '@salesforce/label/c.LB2BExportAffiliate';
import LB2BDomesticAffiliate from '@salesforce/label/c.LB2BDomesticAffiliate';
import LB2BOrderHistoryPlaceHolder from '@salesforce/label/c.LB2BOrderHistoryPlaceHolder';
import LB2BQuoteFile from '@salesforce/label/c.LB2BQuoteFile';
import LB2BDownload from '@salesforce/label/c.LB2BDownload';
import LB2BQuoteOrders from '@salesforce/label/c.LB2BQuoteOrders';
import LB2BWarrantyExchange from '@salesforce/label/c.LB2BWarrantyExchange';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import USER_ID from '@salesforce/user/Id';
import LOCALE from '@salesforce/i18n/locale';
import getPdf from '@salesforce/apex/LB2BRestApiController.getPdf';
import getSearchResults from '@salesforce/apex/LB2BOrderHistoryController.getSearchResults';
import getOrderDetail from '@salesforce/apex/LB2BCallEnosix.getOrderDetail';
//get logo image base64 value
import getBase64FromImageUrl from '@salesforce/apex/LB2BRestApiController.getBase64FromImageUrl';
import LB2BTargetedFunds from '@salesforce/label/c.LB2BTargetedFunds';
import LB2BFreeGoods from '@salesforce/label/c.LB2BFreeGoods';
import LB2BOnAccountOrder from '@salesforce/label/c.LB2BOnAccountOrder';
import LB2BReturnedOrder from '@salesforce/label/c.LB2BReturnedOrder';
import { TrackOrderHistory } from 'c/lb2bDataLayer';
import IS_EXPORT_AFFILIATE from '@salesforce/customPermission/Export_Affiliate_User';
import IS_DOMESTIC_AFFILIATE from '@salesforce/customPermission/Domestic_Affiliate_User';
import IS_INTERNAL_SALES from '@salesforce/customPermission/Internal_Sales_Rep';
import IS_Sales_Rep_CA from '@salesforce/customPermission/Sales_Rep_CA';
import { TrackOrderHistoryNinetyDays } from 'c/lb2bDataLayer';
import { fireEvent } from 'c/lb2bPubSub';
import jspdf from '@salesforce/resourceUrl/LB2BGetQuotePdfScript';
import { getQuotePdf } from 'c/lb2bGetQuote';
import LB2BClearAllFilters from '@salesforce/label/c.LB2BClearAllFilters';
import LB2BCreditNotes from '@salesforce/label/c.LB2BCreditNotes';
import lb2bMarketingDemo from '@salesforce/label/c.lb2bMarketingDemo';

export default class Lb2bOrderHistory extends NavigationMixin(LightningElement) {
    constructor() {
        super();
        this.apexInputWrapper = {
            isAdvancedSearch: true,
            userId: USER_ID,
            userLocale: LOCALE,
            soldToNumber: null,
            shipToNumber: null,
            orderType: 'ALL',
            orderStatus: 'ALL',
            startDate: null,
            endDate: null,
            omniSearch: null,
            pageNumber: 1,
            // These teo are reserved for future use
            sortField: 'Order_Create_Date__c',
            sortDirection: 'DESC',
            doAllRecords: false
        };
    }
   // @track callReturnRequest = false;
    @api orderNumber;
    orderType = '';
    customFormModal = false;
    isLoader = false;
    customFormModal2 = false;
    @track disableNext = true;
    @track disablePrevious = true;
    @track showResults = false;
    @track isMexican = false;
    @track isOnAsc = false;
    @track isOnDesc = false;
    @track isPoAsc = false;
    @track isPoDesc = false;
    @track isOdAsc = false;
    @track isOdDesc = false;
    @track isNaAsc = false;
    @track isNaDesc = false;
    @track isSoldToAsc = false;
    @track isSoldToDesc = false;
    @track isShipToAsc = false;
    @track isShipToDesc = false;
    @track createDate;
    @track lastDate;
    // @track loadpage;
    orderTotal;
    brandToPdf;
    base64data;
    sapTotal;
    sapFrieght;

    soldToSelector;
    shipToSelector;
    firstLoadComplete = false;
    omniValue = false;
    urlQuery;
    decodedUrl = false;

    /**
     * @typedef {Object} OrderHistoryItem
     *
     * @property {number} id
     * @property {string} orderNumber
     * @property {string} soldToNumber
     * @property {string} shipToNumber
     * @property {string} orderType
     * @property {string} orderStatus
     * @property {string} poNumber
     * @property {Date} documentDate
     * @property {number} netAmount
     * @property {string} status
     * @property {Array<string>} bolNumbers
     * @property {Array<string>} invoiceNumbers
     * @property {Boolean} isPending
     */

    /**
     * @typedef {Object} OrderHistoryResults
     *
     * @property {boolean} hasError
     * @property {string} errorMessage
     * @property {String} hasNextPage
     * @property {Array<OrderHistoryItem} orders
     * @property {string} query
     * @property {string} userMode
     */

    /**
     * @typedef {Object} OrderSearchInput
     *
     * @property {boolean} isAdvancedSearch
     * @property {string} soldToNumber
     * @property {string} shipToNumber
     * @property {string} reportFilter
     * @property {Date} startDate
     * @property {Date} endDate
     * @property {string} omniSearch
     * @property {number} pageNumber
     * @property {string} userId
     * @property {string} userLocale
     * @property {string} sortField
     * @property {string} sortDirection
     */

    /** @type {OrderSearchInput} */
    apexInputWrapper;

    /** @type {OrderHistoryResults} */
    orderHistoryResults;

    label = {
        LB2BOrder_History,
        LB2BPONumber,
        LB2BSkuNumber,
        LB2BOrder_Dates,
        LB2BSales_Order_Number,
        LB2BShip_To,
        LB2BSold_To,
        LB2BSales_Re_Filter,
        LB2BList_Order,
        LB2BSearch,
        LB2BHistorical,
        LB2BShipped,
        LB2BMXIsShipped,
        LB2BOpenOrders,
        LB2BOrdersOnHold,
        LB2BBackOrders,
        LB2BOrderNumber,
        LB2BStatus,
        LB2BOrderType,
        LB2BDocumentDate,
        LB2BNetAmount,
        LB2BSoldToCustomer,
        LB2BShipToCustomer,
        LB2BShowing,
        LB2BOf,
        LB2BTo,
        LB2BEntries,
        LB2BInvoice,
        LB2BOrderDate,
        LB2BAll,
        LB2BClosed,
        LB2BOpen,
        LB2BOpenWBO,
        LB2BParShip,
        LB2BParInvoice,
        LB2BBlocked,
        LB2BPending,
        LB2BCancelled,
        LB2BCreditBlock,
        LB2BError,
        LB2BErrorMessage,
        LB2BNoOrdersMsg,
        LB2BMandatoryFieldsError,
        LB2BSelectShipTo,
        LB2BBol,
        LB2BExportToExcel,
        LB2BDropShipCity,
        LB2BDropShipState,
        LB2BDropShipCountry,
        LB2BShipToCustomerName,
        LB2BIsNotAvailable,
        LB2BNotAccess,
        LB2BOk,
        LB2BOrderNumberError,
        LB2BSearchCriteria,
        LB2BPage,
        LB2bPrevious,
        LB2BNext,
        LB2BListOrderNotes,
        LB2BExportAffiliate,
        LB2BDomesticAffiliate,
        LB2BOrderHistoryPlaceHolder,
        LB2BClearAllFilters,
        LB2BCreditNotes,
        LB2BQuoteFile,
        LB2BDownload
    };

    columnHeader = [
        this.label.LB2BOrderNumber,
        this.label.LB2BStatus,
        this.label.LB2BOrderType,
        this.label.LB2BPONumber,
        this.label.LB2BDocumentDate,
        this.label.LB2BNetAmount,
        this.label.LB2BSoldToCustomer,
        this.label.LB2BShipToCustomer
    ];

    get orderTypeOptions() {
        let options = [];

        if (!!IS_EXPORT_AFFILIATE) {
            options.push({ label: LB2BExportAffiliate, value: 'ZX1' });
            return options;
        }

        if (!!IS_DOMESTIC_AFFILIATE) {
            options.push({ label: LB2BDomesticAffiliate, value: 'ZS2' });
            return options;
        }

        options.push({ label: LB2BAll, value: 'ALL' });

        if (LOCALE == 'en-US') {
            options.push({ label: LB2BFinishedGoods, value: 'OR TA' });
            options.push({ label: LB2BReturnedOrder, value: 'RE' });
        } else if (LOCALE == 'fr-CA') {
            options.push({ label: LB2BStandardOrders, value: 'OR TA' });
            options.push({ label: LB2BStandardReturns, value: 'RE' });
        } else if (LOCALE == 'es-MX') {
            options.push({ label: LB2BFinishedGoods, value: 'ZMXA' });
            options.push({ label: LB2BReturnedOrder, value: 'ZMXC' });
            options.push({ label: LB2BCreditNotes, value: 'ZMXE' });
        }

        if (!!IS_INTERNAL_SALES) {
            if (!!IS_Sales_Rep_CA) {
                options.push({ label: LB2BOnLoanShowOrders, value: 'ZDSL' });
                options.push({ label: LB2BPromoDemoMktg, value: 'ZTC' });
                options.push({ label: LB2BBBFSales, value: 'ZRP' });
                options.push({ label: LB2BSalesMktgDemo, value: 'ZSLS' });
                options.push({ label: LB2BGiveAwayDemo, value: 'ZDG' });
            } else {
                options.push({ label: LB2BTargetedFunds, value: 'ZGA' });
                options.push({ label: lb2bMarketingDemo, value: 'ZMKG' });
                options.push({ label: LB2BWarrantyExchange, value: 'ZWX' });
                //Added ZPRM ZTC ZTST . --TCOM -3623,3626
                options.push({ label: LB2BFreeGoods, value: 'ZSLS ZPRM ZTC ZTST' });
            }
        }

        options.push({ label: LB2BOnAccountOrder, value: 'ZSA0' });
        options.push({ label: LB2BQuoteOrders, value: 'QT' });

        return options;
    }

    get orderStatusOptions() {
        if (LOCALE == 'es-MX') {
            return [
                { label: LB2BAll, value: 'ALL' },
                { label: LB2BOpen, value: 'A B' },
                { label: LB2BParShip, value: 'C' },
                { label: LB2BParInvoice, value: 'E' },
                { label: LB2BShipped, value: 'D F' },
                { label: LB2BCancelled, value: 'X' },
                { label: LB2BPending, value: 'Pending' },
                { label: LB2BBlocked, value: 'Z' },
                { label: LB2BCreditBlock, value: 'Y' }
            ];
        } else {
            return [
                { label: LB2BAll, value: 'ALL' },
                { label: LB2BOpen, value: 'A B Z Y' },
                { label: LB2BParShip, value: 'C' },
                { label: LB2BParInvoice, value: 'E' },
                { label: LB2BShipped, value: 'D F' },
                { label: LB2BCancelled, value: 'X' },
                { label: LB2BPending, value: 'Pending' }
                /*{ label: LB2BBlocked, value: 'Z' },
                { label: LB2BCreditBlock, value: 'Y' }*/
            ];
        }
    }

    get omniSearch() {
        if (window.location.href.includes('tabset')) {
            if (localStorage.getItem('orderHistoryRecords')) {
                let localData = JSON.parse(localStorage.getItem('orderHistoryRecords'));
                if (localData) {
                    return localData.omniSearch;
                }
            } else {
                return '';
            }
        } else {
            let retainStatus = JSON.parse(JSON.stringify(history.state));
            if (!retainStatus) {
                return '';
            }
            if (retainStatus.apexInputWrapper) {
                return retainStatus.apexInputWrapper.omniSearch;
            } else if (this.omniValue) {
                return this.apexInputWrapper.omniSearch;
            } else {
                return '';
            }
        }
    }

    get orderTypePlaceholder() {
        let retainStatus = JSON.parse(JSON.stringify(history.state));
        if (!retainStatus) {
            return LB2BAll;
        }
        if (retainStatus.apexInputWrapper) {
            if (!!IS_EXPORT_AFFILIATE) {
                if (retainStatus.apexInputWrapper.orderType === 'ZX1') {
                    return LB2BExportAffiliate;
                }
            }

            if (!!IS_DOMESTIC_AFFILIATE) {
                if (retainStatus.apexInputWrapper.orderType === 'ZS2') {
                    return LB2BDomesticAffiliate;
                }
            }

            if (LOCALE == 'en-US') {
                if (retainStatus.apexInputWrapper.orderType === 'OR TA') {
                    return LB2BFinishedGoods;
                } else if (retainStatus.apexInputWrapper.orderType === 'RE') {
                    return LB2BReturnedOrder;
                } else if (retainStatus.apexInputWrapper.orderType === 'ZSLS') {
                    return LB2BFreeGoods;
                } else if (retainStatus.apexInputWrapper.orderType === 'QT') {
                    return LB2BQuoteOrders;
                } else {
                    return LB2BAll;
                }
            } else if (LOCALE == 'fr-CA') {
                // None specified
                if (retainStatus.apexInputWrapper.orderType === 'OR TA') {
                    return LB2BStandardOrders;
                } else if (retainStatus.apexInputWrapper.orderType === 'RE') {
                    return LB2BStandardReturns;
                } else if (retainStatus.apexInputWrapper.orderType === 'QT') {
                    return LB2BQuoteOrders;
                } else {
                    if (!!IS_Sales_Rep_CA) {
                        if (retainStatus.apexInputWrapper.orderType === 'ZDSL') {
                            return LB2BOnLoanShowOrders;
                        } else if (retainStatus.apexInputWrapper.orderType === 'ZTC') {
                            return LB2BPromoDemoMktg;
                        } else if (retainStatus.apexInputWrapper.orderType === 'ZRP') {
                            return LB2BBBFSales;
                        } else if (retainStatus.apexInputWrapper.orderType === 'ZSLS') {
                            return LB2BSalesMktgDemo;
                        } else if (retainStatus.apexInputWrapper.orderType === 'ZDG') {
                            return LB2BGiveAwayDemo;
                        } else {
                            return LB2BAll;
                        }
                    } else {
                        return LB2BAll;
                    }
                }
            } else if (LOCALE == 'es-MX') {
                if (retainStatus.apexInputWrapper.orderType === 'ZMXA') {
                    return LB2BFinishedGoods;
                } else if (retainStatus.apexInputWrapper.orderType === 'ZMXC') {
                    return LB2BReturnedOrder;
                } else if (retainStatus.apexInputWrapper.orderType === 'ZMXE') {
                    return LB2BCreditNotes;
                } else if (retainStatus.apexInputWrapper.orderType === 'QT') {
                    return LB2BQuoteOrders;
                } else {
                    return LB2BAll;
                }
            }

            if (!!IS_INTERNAL_SALES) {
                if (retainStatus.apexInputWrapper.orderType === 'ZGA ZRP') {
                    return LB2BTargetedFunds;
                } else if (retainStatus.apexInputWrapper.orderType === 'ZSLS') {
                    return LB2BFreeGoods;
                } else {
                    return LB2BAll;
                }
            }
        } else {
            return this.orderTypeOptions[0].label;
        }
    }

    get orderStatusPlaceholder() {
        if (window.location.href.includes('tabset')) {
        } else {
            let retainStatus = JSON.parse(JSON.stringify(history.state));
            if (!retainStatus) {
                return LB2BAll;
            }
            if (retainStatus.apexInputWrapper) {
                if (retainStatus.apexInputWrapper.orderStatus === 'A B') {
                    return LB2BOpen;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'C') {
                    return LB2BParShip;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'E') {
                    return LB2BParInvoice;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'D F') {
                    return LB2BShipped;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'X') {
                    return LB2BCancelled;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'Z') {
                    return LB2BBlocked;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'Pending') {
                    return LB2BPending;
                } else if (retainStatus.apexInputWrapper.orderStatus === 'Y') {
                    return LB2BCreditBlock;
                } else {
                    return LB2BAll;
                }
            } else {
                return this.orderStatusOptions[0].label;
            }
        }
        // return this.orderStatusOptions[0].label;
    }

    get dateRange() {
        return [
            { label: 'This Week', value: 'THIS_WEEK' },
            { label: 'This Month', value: 'THIS_MONTH' },
            { label: 'This Quarter', value: 'THIS_QUARTER' },
            { label: 'Last 6 Months', value: 'LAST_N_DAYS:180' },
            { label: 'This Year', value: 'THIS_YEAR' }
        ];
    }

    @wire(CurrentPageReference) pageRef;

    connectedCallback() {
        if (LOCALE === 'es-MX') {
            this.isMexican = true;
        }
        this.getbase64FromUrl();
        this.apexInputWrapper;
        this.apexInputWrapper.isAdvancedSearch = true;
        this.decodeUrl();
    }

    decodeUrl() {
        console.log('Encode/Decode');
        const params = Object.fromEntries(new URLSearchParams(window.location.search));
        console.log(params.q);
        if (params.q) {
            const encodedData = params.q;
            const decodedData = atob(encodedData);
            console.log('Encoded Data ', encodedData);
            console.log('Decoded Data ', decodedData);
            this.apexInputWrapper = JSON.parse(decodedData);
            console.log('Apex Input Wrapper ', this.apexInputWrapper);
            this.decodedUrl = true;
            this.handleSearch();
        }
    }

    handleCreateChange(event) {
        this.createDate = event.target.value;
        this.apexInputWrapper.startDate = event.target.value;
        this.apexInputWrapper.pageNumber = 1;
        this.omniValue = true;
    }
    handleLastChange(event) {
        this.lastDate = event.target.value;
        this.apexInputWrapper.endDate = event.target.value;
        this.apexInputWrapper.pageNumber = 1;
        this.omniValue = true;
    }

    handleOmniSearchChanged(event) {
        this.apexInputWrapper.omniSearch = event.target.value;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleSoldToAccountSelected(evt) {
        const acctNumber = evt.detail;
        if (!acctNumber) {
            this.apexInputWrapper.shipToNumber = null;
        }

        this.apexInputWrapper.soldToNumber = acctNumber;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleShipToAccountSelected(evt) {
        const acctNumber = evt.detail;
        if (!acctNumber) {
            this.apexInputWrapper.soldToNumber = null;
        }

        this.apexInputWrapper.shipToNumber = acctNumber;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleOrderTypeChanged(evt) {
        console.log(evt.detail.value);
        this.apexInputWrapper.orderType = evt.detail.value;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleOrderStatusChanged(evt) {
        console.log(evt.detail.value);
        this.apexInputWrapper.orderStatus = evt.detail.value;
        this.apexInputWrapper.pageNumber = 1;
    }

    handleNavigate(event) {
        this.orderNumber = event.currentTarget.dataset.value;
        this.orderType = event.currentTarget.dataset.ordertype;
        let url = window.location.origin + window.location.pathname;
        let newUrl = url.replace('/OrderSummary/OrderSummary/Default', '/sap-order-detail');
        console.log('url123', newUrl);
        if (event.currentTarget.dataset.status != 'Pending') {
            this.navigateToWebPage(newUrl);
        }
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url + '?orderNumber=' + this.orderNumber + '&type=' + this.orderType
            }
        });
    }

    handleAccrdionTable(event) {
        console.log('Click Icon', event);
        let accordionBtns = this.template.querySelectorAll('.accordion');

        console.log('accordionBtns', accordionBtns);

        this.template.querySelectorAll('.is-open').length
            ? this.template.querySelectorAll('.is-open').forEach((item) => {
                item.classList.remove('is-open');
            })
            : null;

        accordionBtns.forEach((item) => {
            item.addEventListener('click', () => {
                item.parentElement.parentElement.classList.contains('is-open')
                    ? item.parentElement.parentElement.classList.remove('is-open')
                    : item.parentElement.parentElement.classList.add('is-open');
            });
        });
    }

    customDelete(event) {
        this.customFormModal2 = false;
    }

    renderedCallback() {
        if (!this.firstLoadComplete) {
            this.firstLoadComplete = true;

            this.soldToSelector = this.template.querySelectorAll('c-lb2b-account-selector-v2')[0];
            this.shipToSelector = this.template.querySelectorAll('c-lb2b-account-selector-v2')[1];

            if (!this.decodedUrl) {
                /** To retain records for Advance search  */
                let retainData = JSON.parse(JSON.stringify(history.state));
                console.log('retain :', retainData);
                if (retainData.apexInputWrapper) {
                    this.apexInputWrapper = retainData.apexInputWrapper;
                    this.createDate = this.apexInputWrapper.startDate;
                    this.lastDate = this.apexInputWrapper.endDate;
                    this.handleSearch();

                    setTimeout(() => {
                        const soldToNumber = retainData.apexInputWrapper.soldToNumber;
                        const shipToNumber = retainData.apexInputWrapper.shipToNumber;

                        /**To retain value of sold to and ship to account  */
                        if (soldToNumber) {
                            console.log('Setting sold to selector to:', soldToNumber);
                            this.soldToSelector.setSelectedAccount(soldToNumber);
                        } else {
                            console.log('No sold to number found to set');
                        }
                        if (shipToNumber) {
                            console.log('Setting sold to selector to:', shipToNumber);
                            this.shipToSelector.setSelectedAccount(shipToNumber);
                        } else {
                            console.log('No ship to number found to set');
                        }
                    }, 3000);
                }
            } else {
            }
        }

        this.handleAccrdionTable();
        loadStyle(this, GlobalCSS);

        Promise.all([
            loadScript(this, jspdf) // load script here
        ]);
    }

    handleSearch() {
        this.isLoader = true;
        let searchCriteriaString = JSON.stringify(this.apexInputWrapper);
        console.log('Search criteria:', searchCriteriaString);
        console.log('local : ', LOCALE);

        console.log('order Type', this.apexInputWrapper.orderType);
        console.log('order Status', this.apexInputWrapper.orderStatus);
        /*  if(this.apexInputWrapper.orderType==='OR TA' )
           {
               if(this.apexInputWrapper.orderStatus==='D F'){
               this.callReturnRequest=true;
               console.log('entered previous');
               }
             
          
               else if(this.apexInputWrapper.orderStatus==='C'){
                   this.callReturnRequest=true;
                   console.log('entered previous');
                   }
              
           
              else if(this.apexInputWrapper.orderStatus==='E'){
                   this.callReturnRequest=true;
                   console.log('entered previous');
                   }
                   else{
                       this.callReturnRequest=false;
                   }
             
           } */



        getSearchResults({ inputString: searchCriteriaString })
            .then((result) => {
                this.isLoader = false;

                if (result.hasError) {
                    console.log('Error:', result.errorMessage);
                    console.log(result.query);
                    this.showResults = false;

                    let historyObj = {};
                    historyObj.apexInputWrapper = this.apexInputWrapper;
                    history.replaceState(historyObj, '');

                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: result.errorMessage,
                            variant: 'error',
                            mode: 'dismissable'
                        })
                    );
                } else {
                    console.log('Results:', result);
                    //  this.showResults = result.orders.length > 0 ? true : false;
                    this.showResults = true;
                    this.orderHistoryResults = result;
                    console.log('orderHistoryResults', this.orderHistoryResults);

                    //hide + - button if bol & invoice is not available
                    for (let i = 0; i < this.orderHistoryResults.orders.length; i++) {
                        let bol = this.orderHistoryResults.orders[i].bolNumbers;
                        let invoice = this.orderHistoryResults.orders[i].invoiceNumbers;

                        if (
                            (this.orderHistoryResults.orders[i].orderType === 'QUOTE' ||
                                this.orderHistoryResults.orders[i].orderType === 'QT') &&
                            !this.orderHistoryResults.orders[i].orderNumber.includes('REF:')
                        ) {
                            this.orderHistoryResults.orders[i].hideAccordion = false;
                            this.orderHistoryResults.orders[i].isQuote = true;
                        } else if (bol.length !== 0 && invoice.length !== 0) {
                            this.orderHistoryResults.orders[i].hideAccordion = false;
                            this.orderHistoryResults.orders[i].isQuote = false;
                        } else {
                            this.orderHistoryResults.orders[i].hideAccordion = true;
                        }


                        console.log('order Type', this.orderHistoryResults.orders[i].orderType);
        console.log('order Status', this.orderHistoryResults.orders[i].status);

                        if (this.orderHistoryResults.orders[i].orderType.includes(LB2BFinishedGoods) && (LOCALE==='en-US')) {
                            if (this.orderHistoryResults.orders[i].status === 'Shipped') {
                                this.orderHistoryResults.orders[i].callReturnRequest = true;
                                console.log('entered shipped');
                            }


                            else if (this.orderHistoryResults.orders[i].status === 'Partially Shipped') {
                                this.orderHistoryResults.orders[i].callReturnRequest = true;
                                console.log('entered Partially Shipped');
                            }
                            


                            else if (this.orderHistoryResults.orders[i].status === 'Partially Invoiced') {
                                this.orderHistoryResults.orders[i].callReturnRequest = true;
                                console.log('Partially Invoiced');
                            }
                            
                            else {
                                this.orderHistoryResults.orders[i].callReturnRequest = false;
                            }

                        }
                           
                        /*  if ((this.orderHistoryResults.orders[i].orderType.includes(LB2BFinishedGoods)) && (this.orderHistoryResults.orders[i].orderStatus === LB2BShipped || LB2BPartiallyShipped || LB2BPartiallyInvoiced) && (LOCALE==='en-US')){
                              console.log('inside fG and order status >>>');
                              this.callReturnRequest=true;
                          }*/
                        /* console.log('orderType',this.orderHistoryResults.orders[i].orderType);
                         console.log('status',this.orderHistoryResults.orders[i].status);
                 
                         if(this.orderHistoryResults.orders[i].orderType.includes(LB2BFinishedGoods) && this.orderHistoryResults.orders[i].status==='Shipped' && LOCALE==='en-US')
                         {
                             this.callReturnRequest=true;
                             console.log('Entered shipped');
                            
                           
                         }else if(this.orderHistoryResults.orders[i].orderType.includes(LB2BFinishedGoods) && this.orderHistoryResults.orders[i].status==='Partially Shipped' && LOCALE==='en-US')
                         {
                             this.callReturnRequest=true;
                             console.log('Partially Shipped');
                           
                         }else if(this.orderHistoryResults.orders[i].orderType.includes(LB2BFinishedGoods) && this.orderHistoryResults.orders[i].status==='Partially Invoiced' && LOCALE==='en-US')
                         {
                             this.callReturnRequest=true;
                             console.log('Partially Invoiced');
                            
                            
                         }else{
                                 this.callReturnRequest=false;
                                 console.log('Entered none');
                                
                             }*/
                    }

                    /** To store data in localstorage if search by order */
                    let historyObj = {};
                    historyObj.pageNo = this.apexInputWrapper.pageNumber;
                    historyObj.orderRecords = this.orderHistoryResults;
                    historyObj.apexInputWrapper = this.apexInputWrapper;
                    console.log('historyObj: ', historyObj);
                    history.replaceState(historyObj, '');
                    //** end of code  */

                    this.disableNext = this.orderHistoryResults.hasNextPage == true ? false : true;
                    this.disablePrevious = this.apexInputWrapper.pageNumber == 1 ? true : false;
                }
            })
            .catch((error) => {
                this.isLoader = false;
                this.showResults = false;
                console.error(error);
            });
    }

    nextHandleSearch() {
        this.apexInputWrapper.pageNumber++;
        this.handleSearch();
    }

    previousHandleSearch() {
        this.apexInputWrapper.pageNumber--;
        this.handleSearch();
    }

    callRestApi(evt) {
        this.isLoader = true;
        let _name = evt.currentTarget.name;
        let _invoice = '';
        let _bol = '';
        let fileName = '';

        if (_name == 'Invoice') {
            _invoice = evt.currentTarget.dataset.value;
            fileName = _invoice;
        } else {
            _bol = evt.currentTarget.dataset.value;
            fileName = _bol;
        }

        let _orderNumber = evt.currentTarget.dataset.id;
        if (LOCALE === 'es-MX') {
            this.isMexican = true;
        }

        getPdf({
            invoice: _invoice,
            orderNumber: _orderNumber,
            bol: _bol,
            isMexican: this.isMexican
        })
            .then((result) => {
                this.isLoader = false;
                console.log('result of restAPI: ', result);
                if (result) {
                    if (LOCALE == 'es-MX') {
                        if (result.includes('ERROR')) {
                            this.callDispatchEvent(_name);
                        } else {
                            this.downloadBolInvoicePdf(result, fileName);
                        }
                    } else {
                        this.downloadBolInvoicePdf(result, fileName);
                    }
                } else {
                    this.callDispatchEvent(_name);
                }
            })
            .catch((error) => {
                this.isLoader = false;
                console.log('error for invoice : ', error);
            });
    }

    downloadBolInvoicePdf(pdf, file_name) {
        let downloadLink = document.createElement('a');
        downloadLink.href = 'data:application/pdf;base64,' + pdf;
        downloadLink.download = file_name;
        downloadLink.click();
    }

    callDispatchEvent(name) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message: name + ' ' + this.label.LB2BIsNotAvailable,
                variant: 'error',
                mode: 'dismissable'
            })
        );
    }

    sort(event) {
        this.isOnAsc = false;
        this.isOnDesc = false;
        this.isPoAsc = false;
        this.isPoDesc = false;
        this.isOdAsc = false;
        this.isOdDesc = false;
        this.isNaAsc = false;
        this.isNaDesc = false;
        this.isSoldToAsc = false;
        this.isSoldToDesc = false;
        this.isShipToAsc = false;
        this.isShipToDesc = false;

        this.apexInputWrapper.sortField = event.currentTarget.dataset.id;
        this.apexInputWrapper.sortDirection =
            this.apexInputWrapper.sortDirection === 'DESC' ? 'ASC' : 'DESC';

        switch (this.apexInputWrapper.sortField) {
            case 'Order_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isOnAsc = true;
                } else {
                    this.isOnDesc = true;
                }
                break;

            case 'PO_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isPoAsc = true;
                } else {
                    this.isPoDesc = true;
                }
                break;

            case 'Order_Create_Date__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isOdAsc = true;
                } else {
                    this.isOdDesc = true;
                }
                break;

            case 'Net_Amount__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isNaAsc = true;
                } else {
                    this.isNaDesc = true;
                }
                break;

            case 'Sold_To_Account_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isSoldToAsc = true;
                } else {
                    this.isSoldToDesc = true;
                }
                break;

            case 'Ship_To_Account_Number__c':
                if (this.apexInputWrapper.sortDirection === 'ASC') {
                    this.isShipToAsc = true;
                } else {
                    this.isShipToDesc = true;
                }
                break;
        }
        this.handleSearch();
    }

    exportToExcel() {
        let fullOrderInputWrapper = {
            ...this.apexInputWrapper
        };
        this.isLoader = true;
        fullOrderInputWrapper.doAllRecords = true;
        const searchCriteriaString = JSON.stringify(fullOrderInputWrapper);
        getSearchResults({ inputString: searchCriteriaString }).then((Results) => {
            if (Results.hasError) {
                console.error('Error:', Results.errorMessage);
            } else {
                let doc = '<table>';
                doc += '<style>';
                doc += 'table, th, td {';
                doc += '    border: 1px solid black;';
                doc += '    border-collapse: collapse;';
                doc += '}';
                doc += '</style>';
                // Adding all the Table Headers
                doc += '<tr>';
                this.columnHeader.forEach((element) => {
                    doc += '<th>' + element + '</th>';
                });
                doc += '</tr>';
                // Adding the data rows
                Results.orders.forEach((record) => {
                    if (record) {
                        doc += '<tr>';
                        doc += '<th>' + record.orderNumber + '</th>';
                        doc += '<th>' + record.status + '</th>';
                        doc += '<th>' + record.orderType + '</th>';
                        doc += '<th>' + record.poNumber + '</th>';
                        doc += '<th>' + record.documentDate + '</th>';
                        doc += '<th>' + record.netAmount + '</th>';
                        doc += '<th>' + record.soldToNumber + '</th>';
                        doc += '<th>' + record.shipToNumber + '</th>';
                        doc += '</tr>';
                    } else {
                        doc += '<th>' + '</th>';
                    }
                });
                doc += '</table>';
                var element = 'data:application/vnd.ms-excel,' + encodeURIComponent(doc);
                let downloadElement = document.createElement('a');
                downloadElement.href = element;
                downloadElement.target = '_self';
                downloadElement.download = 'Order History List.xls';
                document.body.appendChild(downloadElement);
                downloadElement.click();
                this.isLoader = false;
            }
        });
    }

    MoveToDataLayer() {
        TrackOrderHistory(
            'order_history_search',
            this.soldTo,
            this.shipTo,
            this.createDate,
            this.lastDate,
            this.PONumber,
            this.SalesOrderNo
        );
    }

    //clear all filter method
    clearAllFilters() {
        this.handleAccrdionTable();

        if (
            this.apexInputWrapper.omniSearch !== null ||
            this.apexInputWrapper.endDate !== null ||
            this.apexInputWrapper.startDate !== null ||
            this.apexInputWrapper.shipToNumber !== null ||
            this.apexInputWrapper.soldToNumber !== null ||
            this.apexInputWrapper.orderType !== 'ALL' ||
            this.apexInputWrapper.orderStatus !== 'ALL'
        ) {
            this.isLoader = true;
            this.createDate = null;
            this.lastDate = null;

            this.apexInputWrapper.omniSearch = null;
            this.apexInputWrapper.endDate = null;
            this.apexInputWrapper.isAdvancedSearch = true;
            this.apexInputWrapper.userId = USER_ID;
            this.apexInputWrapper.userLocale = LOCALE;
            this.apexInputWrapper.soldToNumber = null;
            this.apexInputWrapper.shipToNumber = null;
            this.apexInputWrapper.orderType = 'ALL';
            this.apexInputWrapper.orderStatus = 'ALL';
            this.apexInputWrapper.startDate = null;
            this.apexInputWrapper.pageNumber = 1;
            this.apexInputWrapper.sortField = 'Order_Create_Date__c';
            this.apexInputWrapper.sortDirection = 'DESC';

            this.template.querySelectorAll('c-lb2b-account-selector-v2')[0].clearFilter();
            this.template.querySelectorAll('c-lb2b-account-selector-v2')[1].clearFilter();

            this.template.querySelectorAll('lightning-combobox').forEach((element) => {
                element.value = null;
            });

            let historyObj = {};
            console.log('historyObj: ', historyObj);
            history.replaceState(historyObj, '');
            this.isLoader = false;
        }
    }

    handleAccordianPlus(event) {
        const itemIndex = event.currentTarget.dataset.index;
        const rowData = this.orderHistoryResults.orders[itemIndex];
        this.orderNumber = rowData.orderNumber;
    }

    getbase64FromUrl() {
        getBase64FromImageUrl({
            url: window.location.origin + this.sbdLogo
        })
            .then((result) => {
                this.base64data = result;
                localStorage.setItem('quote-base64data', JSON.stringify(this.base64data));
            })
            .catch((error) => {
                console.log('error for base64', error);
            });
    }

    handleDownloadPdf(event) {
        this.isLoader = true;
        getOrderDetail({
            SapNumber: this.orderNumber
        })
            .then((result) => {
                let _result = result[0];
                localStorage.setItem('orderItems', JSON.stringify(_result.orderItems[0]));
                for (let i = 0; i < _result.orderItems.length; i++) {
                    this.sapTotal += _result.orderItems[i].NetItemPrice;
                }
                this.sapTotal = parseFloat(this.sapTotal).toFixed(2);

                if (_result.orderFrieght.length == 0) {
                    this.sapFrieght = parseFloat(0).toFixed(2);
                } else {
                    this.sapFrieght = parseFloat(data.orderFrieght[0].Rate).toFixed(2);
                }
                if (_result.orderResFrieght.length == 0) {
                    this.sapResFrieght = parseFloat(0).toFixed(2);
                } else {
                    this.sapResFrieght = parseFloat(data.orderResFrieght[0].Rate).toFixed(2);
                }

                if (_result.orderLiftGateFee.length == 0) {
                    this.sapLiftGateFee = parseFloat(0).toFixed(2);
                } else {
                    this.sapLiftGateFee = parseFloat(data.orderLiftGateFee[0].Rate).toFixed(2);
                }

                let _total = 0;

                for (let i = 0; i < _result.orderItems.length; i++) {
                    _total += _result.orderItems[i].NetValueInDocumentCurrency;
                }

                let obj = {};
                obj.Freight__c = this.sapFrieght;
                obj.LB2B_Total__c = _total;
                obj.SubTotal__c = 0;
                obj.SubTotal__c =
                    parseFloat(obj.LB2B_Total__c) -
                    (parseFloat(this.sapFrieght) +
                        parseFloat(this.sapResFrieght) +
                        parseFloat(this.sapLiftGateFee));
                obj.Ship_To_SAP_Account__r = _result.orderShipTo;
                obj.Sold_To_SAP_Account__r = _result.orderSoldTo;
                this.isLoader = false;
                getQuotePdf(
                    _result.orderItems,
                    _result.orderDate.CreateDate,
                    obj,
                    'All',
                    this.base64data,
                    '',
                    true
                );
            })
            .catch((error) => {
                this.isLoader = false;
                console.error('error for downloading quote', error);
            });
    }

    customShowModalPopup() {
        const itemNo = event.target.dataset.name;
        const modal = this.template.querySelector('c-modal-Popup');
        modal.customShowModalPopup(itemNo);

    }


}