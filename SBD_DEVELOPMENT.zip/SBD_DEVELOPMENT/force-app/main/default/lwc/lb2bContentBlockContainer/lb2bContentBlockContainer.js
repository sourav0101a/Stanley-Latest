import { api, LightningElement } from 'lwc';
import getTitle from '@salesforce/apex/LB2BContentController.getTitle';
import getContent from '@salesforce/apex/LB2BContentController.getContent';
import getWhatsNewTitle from '@salesforce/apex/LB2BContentController.getWhatsNewTitle';
import getWhatsNewContent from '@salesforce/apex/LB2BContentController.getWhatsNewContent';
import LANG from '@salesforce/i18n/lang';
import LOCALE from '@salesforce/i18n/locale';

export default class Lb2bContentBlockContainer extends LightningElement {
    @api
    contentType;
    releaseMonth;
    releaseYear;

    cardList = [];
    title = {
        headingText: '',
        imageUrl: '',
        subheadingText: ''
    };

    get _contentType() {
        const params = Object.fromEntries(new URLSearchParams(window.location.search));

        if (params.q && Object.keys(params).length !== 0) {
            this.releaseMonth = params.q.split('-')[0];
            this.releaseYear = params.q.split('-')[1];
        }

        let cType = this.contentType;
        if (params.p) {
            cType = (this.contentType + ' - ' + params.p).trim();
        }

        return cType;
    }

    connectedCallback() {
         console.log('Lang:', LANG, 'Locale:', LOCALE, 'Type:', this._contentType, 'month',this.releaseMonth, 'year',this.releaseYear);
        this._contentType;
        if (this.releaseMonth !== undefined) {
            this.getWhatsNewPageTitleAndContent();
        }
        else {
            getTitle({ contentType: this._contentType, language: LANG, locale: LOCALE })
                .then((result) => {
                    console.log("gettitleresponse", result);
                    this.title = result;
                })
                .catch((error) => {
                    console.error('error!:', error);
                });
            getContent({ contentType: this._contentType, language: LANG, locale: LOCALE })
                .then((result) => {

                    console.log("getcontentresponse", result);
                    this.cardList = result;
                })
                .catch((error) => {
                    console.error('error!:', error);
                });
        }
    }

    getWhatsNewPageTitleAndContent() {
        getWhatsNewTitle({ contentType: this._contentType, language: LANG, locale: LOCALE, releaseMonth: this.releaseMonth, releaseYear: this.releaseYear })
            .then((result) => {
                this.title = result;
            })
            .catch((error) => {
                console.error('error!:', error);
            });
        getWhatsNewContent({ contentType: this._contentType, language: LANG, locale: LOCALE, releaseMonth: this.releaseMonth, releaseYear: this.releaseYear })
            .then((result) => {
                this.cardList = result;
            })
            .catch((error) => {
                console.error('error!:', error);
            });
    }

}