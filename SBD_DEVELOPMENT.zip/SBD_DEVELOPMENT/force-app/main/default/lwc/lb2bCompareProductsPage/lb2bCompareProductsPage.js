import { LightningElement, wire, api, track} from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

import LB2BPriceInCart from '@salesforce/label/c.LB2BPriceInCart';
import LB2BLowStock from '@salesforce/label/c.LB2BLowStock';
import LB2BInStock from '@salesforce/label/c.LB2BInStock';
import LB2BOutOfStock from '@salesforce/label/c.LB2BOutOfStock';
import LB2BSku from '@salesforce/label/c.LB2BSku';
import LB2BQuickPrice from '@salesforce/label/c.LB2BSuccess';
import LB2BPLPAddedToCart from '@salesforce/label/c.LB2BPLPAddedToCart';
import LB2BGenericErrorTitle from '@salesforce/label/c.LB2BGenericErrorTitle';
import LB2BCompareProducts from '@salesforce/label/c.LB2BCompareProducts';
import LB2BBackToResults from '@salesforce/label/c.LB2BBackToResults';
import LB2BExportToPdf from '@salesforce/label/c.LB2BExportToPdf';
import LB2BHome from '@salesforce/label/c.LB2BHome';
import LB2BRemove from '@salesforce/label/c.LB2BRemove';
import LB2BAddToCart from '@salesforce/label/c.LB2BAddToCart';
import LB2BCountryofOrigin from '@salesforce/label/c.LB2BCountryofOrigin';
import LB2BCordless_Corded from '@salesforce/label/c.LB2BCordless_Corded';
import LB2BVoltage from '@salesforce/label/c.LB2BVoltage';
import LB2BMotorType from '@salesforce/label/c.LB2BMotorType';
import LB2BBladeType from '@salesforce/label/c.LB2BBladeType';
import LB2BBatteryAmpHrs from '@salesforce/label/c.LB2BBatteryAmpHrs';
import LB2BBatteryIncluded from '@salesforce/label/c.LB2BBatteryIncluded';
import LB2BBatteryLife from '@salesforce/label/c.LB2BBatteryLife';
import LB2BBatteryQty from '@salesforce/label/c.LB2BBatteryQty';
import LB2BBatteryType from '@salesforce/label/c.LB2BBatteryType';
import LB2BBatteryWeight from '@salesforce/label/c.LB2BBatteryWeight';
import LB2BChargerIncluded from '@salesforce/label/c.LB2BChargerIncluded';
import LB2BChargerType from '@salesforce/label/c.LB2BChargerType';
import LB2BNetLition from '@salesforce/label/c.LB2BNetLition';
import LB2BPowerSource from '@salesforce/label/c.LB2BPowerSource';
import LB2BTotalNetLit from '@salesforce/label/c.LB2BTotalNetLit';
import LB2BWattHours from '@salesforce/label/c.LB2BWattHours';
import LB2BItemLength from '@salesforce/label/c.LB2BItemLength';
import LB2BItemHeight from '@salesforce/label/c.LB2BItemHeight';
import LB2BItemWidth from '@salesforce/label/c.LB2BItemWidth';
import LB2BItemWeight from '@salesforce/label/c.LB2BItemWeight';

import addToCart from '@salesforce/apex/LB2BQuantitySelectorController.addProductToCart';
import getProducts from '@salesforce/apex/LB2BCompareProductController.getProducts';
import SBD_LOGO from '@salesforce/contentAssetUrl/headerLogo';
import getBase64FromImageUrl from '@salesforce/apex/LB2BRestApiController.getBase64FromImageUrl';

// import getBase64FromImageUrl from '@salesforce/apex/LB2BRestApiController.getBase64FromImageUrl';
// import { loadScript } from 'lightning/platformResourceLoader';
// import jspdf from '@salesforce/resourceUrl/LB2BGetQuotePdfScript';
// import JSPDF_AUTO_TABLE from '@salesforce/resourceUrl/LB2BJspdfAutoTableScript';
// import { getCompareProductsPdf } from 'c/lb2bCompareProductsPdf';

import { addtocartEvent } from 'c/lb2bDataLayer';
import COMMUNITY_ID from '@salesforce/community/Id';
import { publish, MessageContext } from 'lightning/messageService';
import cartChanged from '@salesforce/messageChannel/lightning__commerce_cartChanged';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class Lb2bCompareProductsPage extends LightningElement {

    labels = {
        LB2BPriceInCart,
        LB2BSku,
        LB2BInStock,
        LB2BLowStock,
        LB2BOutOfStock,
        LB2BPLPAddedToCart,
        LB2BQuickPrice,
        LB2BGenericErrorTitle,
        LB2BCompareProducts,
        LB2BBackToResults,
        LB2BExportToPdf,
        LB2BHome,
        LB2BRemove,
        LB2BAddToCart,
        LB2BCountryofOrigin,
        LB2BCordless_Corded,
        LB2BVoltage,
        LB2BMotorType,
        LB2BBladeType,
        LB2BBatteryAmpHrs,
        LB2BBatteryIncluded,
        LB2BBatteryLife,
        LB2BBatteryQty,
        LB2BBatteryType,
        LB2BBatteryWeight,
        LB2BChargerIncluded,
        LB2BChargerType,
        LB2BNetLition,
        LB2BPowerSource,
        LB2BTotalNetLit,
        LB2BWattHours,
        LB2BItemLength,
        LB2BItemHeight,
        LB2BItemWidth,
        LB2BItemWeight
    };

    @wire(CurrentPageReference)
    pageRef;

    @wire(MessageContext)
    messageContext;
    
    @api homeUrl;
    @api effectiveAccountId;
    @track stockAvailabilityColor;
    @track selectedProducts = [];
    @track productsFromTray = [];
    @track base64Data = [];
    @track base64imageurl = [];
    communityId = COMMUNITY_ID;
    sbdLogo = SBD_LOGO;
    isLoading = true;
    _breadcrumbData;


    connectedCallback(){    
        this._breadcrumbData = JSON.parse(localStorage.getItem('breadcrumbList'))[0].name;
        let url = (window.location.origin + window.location.pathname).split('/compare-products');
        this.homeUrl = url[0];    
        this.getCompareproductInfo();
    }

    get hasMinProducts() {
        return this.selectedProducts.length === 2;
    }
     
    getCompareproductInfo(){
        this.productsFromTray = JSON.parse(localStorage.getItem('selectedProducts'));
        let productIds = [];
       
        this.productsFromTray.forEach(el => {
            productIds.push(el.data.id);
        })
        
        getProducts({
            communityId: this.communityId,
            productIds: productIds,
        }).then((res)=>{
            console.log('Compare prod res', res);  
            this.productsFromTray.forEach((x) => {
            res.forEach((y) => {
               if(x.data.id === y.id){          
                y.fields.LB2BProductAvailabilityStatus__c = x.data.stock !== undefined ? x.data.stock : '';
                if (y.fields.LB2BProductAvailabilityStatus__c === LB2BInStock){
                    y.fields.LB2BProductAvailabilityStatusCa__c = 'item-in-stock';
                } else if (y.fields.LB2BProductAvailabilityStatus__c === LB2BOutOfStock) {              
                    y.fields.LB2BProductAvailabilityStatusCa__c = 'item-out-stock';
                } else if(y.fields.LB2BProductAvailabilityStatus__c  === LB2BLowStock) {           
                    y.fields.LB2BProductAvailabilityStatusCa__c = 'item-low-stock';
                }
               }
                });
            });
            
            this.selectedProducts = res; 
            this.getbase64FromUrl();
            this.isLoading = false;       
        }).catch((error) => {
            console.log(error);
        })
    }

    goBack(){
        history.back();
    }

    removeProduct(evt){
        this.selectedProducts.splice(evt.target.dataset.index, 1);
        
        this.productsFromTray.forEach((prod, index) => {
            if (prod.data.id === evt.target.dataset.id) {
                this.productsFromTray.splice(index, 1);
            }
        })
        localStorage.setItem('selectedProducts', JSON.stringify(this.productsFromTray)); //Override tray products
        localStorage.setItem('compareProducts', JSON.stringify(this.selectedProducts)); //Override page products
    }

    exportToPdf(){
        window.print();
    }

    callAddToCart(evt) {
        this.isLoading = true;
        addToCart({
            productId: evt.target.dataset.id,
            quantity: 1,
            communityId: this.communityId,
            accountId: this.effectiveAccountId
        }).then((result) => {
            this.isLoading = false;
                // addtocartEvent('add_to_cart', result.name, this.listname, result.productDetails.sku, null, result.listPrice
                //     , null, this.product_Isocode, this.productIndex, result.quantity);
            
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: this.labels.LB2BSuccess,
                            message: this.labels.LB2BPLPAddedToCart,
                            variant: 'success'
                        })
                    );
                    publish(this.messageContext, cartChanged);
            })
            .catch((err) => {
                this.isLoading = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: this.labels.LB2BGenericErrorTitle,
                        message: err,
                        variant: 'error'
                    })
                );
                console.error('err', err);
            });
    }  
    
    getbase64FromUrl() {
        getBase64FromImageUrl({
            url: window.location.origin + this.sbdLogo
        })
            .then((result) => {
                this.base64data = result;
            })
            .catch((error) => {
                console.log('error for base64', error);
            });
    }
}