/**
 * To display the items with non-editable fields(Quantity change) in checkout page this lb2bCheckoutFinalCart component is used.
 *
 * this is parent component of lb2bCheckoutFinalCartItem.
 */
 
import { api, wire, track, LightningElement } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { fireEvent } from 'c/lb2bPubSub';
import getSapData from '@salesforce/apex/LB2BCartController.getSapData';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import PO_NUMBER from '@salesforce/schema/WebCart.PoNumber';
import Last_Modified_Date from '@salesforce/schema/WebCart.LastModifiedDate';
import LB2BEmptyCartHeaderLabel from '@salesforce/label/c.LB2BEmptyCartHeaderLabel';
import LB2BMaterial from '@salesforce/label/c.LB2BMaterial';
import LB2BTanProdError from '@salesforce/label/c.LB2BTanProdError';
import LB2BTanProdErr from '@salesforce/label/c.LB2BTanProdErr';
import LB2BFooter_Line from '@salesforce/label/c.LB2BFooter_Line';
import LB2BFooter_Line_enUS from '@salesforce/label/c.LB2BFooter_Line_enUS';
import LB2BFooter_Line_frCA from '@salesforce/label/c.LB2BFooter_Line_frCA';
import LB2BFooter_Line_esMX from '@salesforce/label/c.LB2BFooter_Line_esMX';
import LB2BClosedCartLabel from '@salesforce/label/c.LB2BClosedCartLabel';
import LB2BCartTimeOutErrorMsg from '@salesforce/label/c.LB2BCartTimeOutErrorMsg';
import LB2BProceedToCart from '@salesforce/label/c.LB2BProceedToCart';
import LB2BCheckout from '@salesforce/label/c.LB2BCheckout';
import LB2BPackingDeliveryInstructions from '@salesforce/label/c.LB2BPackingDeliveryInstructions';
import LB2BPackingOptional from '@salesforce/label/c.LB2BPackingOptional';
import LB2BDeliveryOptional from '@salesforce/label/c.LB2BDeliveryOptional';
import LB2BItems from '@salesforce/label/c.LB2BItems';
import LB2BEmptyCartBodyLabel from '@salesforce/label/c.LB2BEmptyCartBodyLabel';
import LB2BDropShipCheckbox from '@salesforce/label/c.LB2BDropShipCheckbox';
import LB2BDropShipAddress from '@salesforce/label/c.LB2BDropShipAddress';
import LB2BDropShipAddress1 from '@salesforce/label/c.LB2BDropShipAddress1';
import LB2BDropShipAddress2 from '@salesforce/label/c.LB2BDropShipAddress2';
import LB2BDropShipCity from '@salesforce/label/c.LB2BDropShipCity';
import LB2BDropShipState from '@salesforce/label/c.LB2BDropShipState';
import LB2BDropShipState_Province from '@salesforce/label/c.LB2BDropShipState_Province';
import LB2BDropShipPostalCode from '@salesforce/label/c.LB2BDropShipPostalCode';
import LB2BDropShipCountry from '@salesforce/label/c.LB2BDropShipCountry';
import LB2BUnitedStates from '@salesforce/label/c.LB2BUnitedStates';
import LB2BCanada from '@salesforce/label/c.LB2BCanada';
import LB2BCloseWindow from '@salesforce/label/c.LB2BCloseWindow';
import LB2BOrderReview from '@salesforce/label/c.LB2BOrderReview';
import LB2BInvalidEmail from '@salesforce/label/c.LB2BInvalidEmail';
import GlobalCSS from '@salesforce/resourceUrl/lb2b_global';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import ID from '@salesforce/schema/WebCart.Id';
import LB2BIsQuote from '@salesforce/schema/WebCart.LB2BQuote__c';
import QuoteAdditionalEmail from '@salesforce/schema/WebCart.LB2BQuoteAdditionalEmail__c';
import Name1 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Name__c';
import Name2 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Name1__c';
import ADDRESS1 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Street__c';
import ADDRESS2 from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Street2__c';
import CITY from '@salesforce/schema/WebCart.SAP_ShipTo_Override_City__c';
import POSTALCODE from '@salesforce/schema/WebCart.SAP_ShipTo_Override_PostalCode__c';
import STATE from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Region__c';
import COUNTRY from '@salesforce/schema/WebCart.SAP_ShipTo_Override_Country__c';
import US_STATES from '@salesforce/schema/WebCart.LB2BState__c';
import CA_STATES from '@salesforce/schema/WebCart.LB2BStateCa__c';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import getSapAccountFlags from '@salesforce/apex/LB2BCartController.getSapAccountFlags';
import getSapTotal from '@salesforce/apex/LB2BCartController.getSapTotal';
import updateWebCartPackSlip from '@salesforce/apex/LB2BCartController.updateWebCartPackSlip';
import getAccount from '@salesforce/apex/LB2BGetUserInformation.getAccount';
import USER_ID from '@salesforce/user/Id';
import NAME_K from '@salesforce/schema/User.Name';
import LB2BLoading from '@salesforce/label/c.LB2BLoading';
import LB2BQuote from '@salesforce/label/c.LB2BQuote';
import LB2BQuoteDate from '@salesforce/label/c.LB2BQuoteDate';
import SBD_LOGO from '@salesforce/contentAssetUrl/headerLogo';
import LB2BGetQuote from '@salesforce/label/c.LB2BGetQuote';
import LB2BDiscontinuedErr from '@salesforce/label/c.LB2BDiscontinuedErr';
import LB2BLoadingCartItems from '@salesforce/label/c.LB2BLoadingCartItems';
import LB2BQuoteLine1 from '@salesforce/label/c.LB2BQuoteLine1';
import LB2BQuoteLine2 from '@salesforce/label/c.LB2BQuoteLine2';
import LB2BQuoteLine3 from '@salesforce/label/c.LB2BQuoteLine3';
import LB2BForwardQuote from '@salesforce/label/c.LB2BForwardQuote';
import LB2BQuoteReference from '@salesforce/label/c.LB2BQuoteReference';
import Lb2bAgoraExecuteFailed from '@salesforce/label/c.Lb2bAgoraExecuteFailed';
import LB2BCompanyPersName from '@salesforce/label/c.LB2BCompanyPersName';
import LB2BAttnPersName from '@salesforce/label/c.LB2BAttnPersName';
import LB2BOk from '@salesforce/label/c.LB2BOk';
import { sapOrderSimulationEvent } from 'c/lb2bDataLayer';
import { sfdcOrderSimulationEvent } from 'c/lb2bDataLayer';
import { BapiTimeoutEvent } from 'c/lb2bDataLayer';
import LOCALE from '@salesforce/i18n/locale';
import jspdf from '@salesforce/resourceUrl/LB2BGetQuotePdfScript';
import { getQuotePdf } from 'c/lb2bGetQuote';
import { registerListener } from 'c/lb2bPubSub';
import checkInterface from '@salesforce/apex/LB2BResponseEnosixHelper.checkInterface';
import Internal_Sales_Rep_CA from '@salesforce/customPermission/Sales_Rep_CA';


// simulateOrder New method from LB2BEnosixHelper
// import simulateOrder from '@salesforce/apex/LB2BEnosixHelperV2.simulateOrder';

import callSimulateOrder from '@salesforce/apex/LB2BResponseEnosixHelper.callSimulateOrder';
import checkSimulateStartTime from '@salesforce/apex/LB2BResponseEnosixHelper.checkSimulateStartTime';

// getImages New method from LB2BEnosixHelper
import getImages from '@salesforce/apex/LB2BEnosixHelper.getImages';
//get logo image base64 value
import getBase64FromImageUrl from '@salesforce/apex/LB2BRestApiController.getBase64FromImageUrl';
import convertBulkImageUrlsToBase64 from '@salesforce/apex/LB2BRestApiController.convertBulkImageUrlsToBase64';

// Event name constants
const CART_CHANGED_EVT = 'cartchanged';
const CART_ITEMS_UPDATED_EVT = 'cartitemsupdated';

// Locked Cart Status
const LOCKED_CART_STATUSES = new Set(['Processing', 'Checkout']);

/**
 * A sample cart contents component.
 * This component shows the contents of a buyer's cart on a cart detail page.
 * When deployed, it is available in the Builder under Custom Components as
 * 'B2B Sample Cart Contents Component'
 *
 * @fires CartContents#cartchanged
 * @fires CartContents#cartitemsupdated
 */

export default class Lb2bCheckoutFinalCartV2 extends NavigationMixin(LightningElement) {
    sbdLogo = SBD_LOGO;

    label = {
        LB2BCheckout,
        LB2BPackingDeliveryInstructions,
        LB2BPackingOptional,
        LB2BDeliveryOptional,
        LB2BItems,
        LB2BEmptyCartBodyLabel,
        LB2BFooter_Line,
        LB2BEmptyCartHeaderLabel,
        LB2BClosedCartLabel,
        LB2BDropShipCheckbox,
        LB2BDropShipAddress,
        LB2BDropShipAddress1,
        LB2BDropShipAddress2,
        LB2BDropShipState,
        LB2BDropShipState_Province,
        LB2BDropShipCity,
        LB2BDropShipPostalCode,
        LB2BDropShipCountry,
        LB2BUnitedStates,
        LB2BCanada,
        LB2BLoading,
        LB2BCartTimeOutErrorMsg,
        LB2BProceedToCart,
        LB2BQuote,
        LB2BQuoteDate,
        LB2BGetQuote,
        LB2BCloseWindow,
        LB2BLoadingCartItems,
        LB2BOrderReview,
        LB2BMaterial,
        LB2BTanProdError,
        LB2BTanProdErr,
        LB2BQuoteLine1,
        LB2BQuoteLine2,
        LB2BQuoteLine3,
        LB2BForwardQuote,
        LB2BQuoteReference,
        LB2BOk,
        Lb2bAgoraExecuteFailed,
        LB2BCompanyPersName,
        LB2BAttnPersName,
        LB2BFooter_Line_enUS,
        LB2BFooter_Line_frCA,
        LB2BFooter_Line_esMX
    };

    /**
     * An event fired when the cart changes.
     * This event is a short term resolution to update the cart badge based on updates to the cart.
     *
     * @event CartContents#cartchanged
     *
     * @type {CustomEvent}
     *
     * @export
     */

    /**
     * An event fired when the cart items change.
     * This event is a short term resolution to update any sibling component that may want to update their state based
     * on updates in the cart items.
     *
     * In future, if LMS channels are supported on communities, the LMS should be the preferred solution over pub-sub implementation of this example.
     * For more details, please see: https://developer.salesforce.com/docs/component-library/documentation/en/lwc/lwc.use_message_channel_considerations
     *
     * @event CartContents#cartitemsupdated
     * @type {CustomEvent}
     *
     * @export
     */

    /**
     * A cart line item.
     *
     * @typedef {Object} CartItem
     *
     * @property {ProductDetails} productDetails
     *   Representation of the product details.
     *
     * @property {number} quantity
     *   The quantity of the cart item.
     *
     *  @property {number} sapOrderQuantity
     *   The quantity of the cart item.
     *
     * @property {string} originalPrice
     *   The original price of a cart item.
     *
     * @property {string} salesPrice
     *   The sales price of a cart item.
     *
     * @property {string} totalPrice
     *   The total sales price of a cart item, without tax (if any).
     *
     * @property {string} totalListPrice
     *   The total original (list) price of a cart item.
     */

    /**
     * Details for a product containing product information
     *
     * @typedef {Object} ProductDetails
     *
     * @property {string} productId
     *   The unique identifier of the item.
     *
     * @property {string} sku
     *  Product SKU number.
     *
     * @property {string} name
     *   The name of the item.
     *
     * @property {ThumbnailImage} thumbnailImage
     *   The quantity of the item.
     */

    /**
     * Image information for a product.
     *
     * @typedef {Object} ThumbnailImage
     *
     * @property {string} alternateText
     *  Alternate text for an image.
     *
     * @property {string} id
     *  The image's id.
     *
     * @property {string} title
     *   The title of the image.
     *
     * @property {string} url
     *   The url of the image.
     */

    /**
     * Representation of a sort option.
     *
     * @typedef {Object} SortOption
     *
     * @property {string} value
     * The value for the sort option.
     *
     * @property {string} label
     * The label for the sort option.
     */

    /**
     * The recordId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    recordId;
    @api
    sapNetItemPrice;

    /**
     * The effectiveAccountId provided by the cart detail flexipage.
     *
     * @type {string}
     */
    @api
    effectiveAccountId;

    @api nextPageToken;

    cartItemImages;

    isTanProdError = false;
    isDiscontinuedError = false;
    tanProdSku = [];
    discontinuedSkus = [];
    @track isEnosixInterface;
    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;
    /**
     * Total number of items in the cart
     * @private
     * @type {Number}
     */
    _cartItemCount = 0;

    /**
     * A list of cartItems.
     *
     * @type {CartItem[]}
     */
    cartItems;

    sapItems;
    additionalEmail = '';
    concatinatedArray;
    @track isIndirectAccount;
    @track checkAccount;
    @track orderTotal;
    @track brandToPdf;
    @track base64data;

    /**
     * Specifies the page token to be used to view a page of cart information.
     * If the pageParam is null, the first page is returned.
     * @type {null|string}
     */
    pageParam = null;
    pageSize = 100;

    /**
     * Sort order for items in a cart.
     * The default sortOrder is 'CreatedDateDesc'
     *    - CreatedDateAsc—Sorts by oldest creation date
     *    - CreatedDateDesc—Sorts by most recent creation date.
     *    - NameAsc—Sorts by name in ascending alphabetical order (A–Z).
     *    - NameDesc—Sorts by name in descending alphabetical order (Z–A).
     * @type {string}
     */
    sortParam = 'CreatedDateDesc';

    /**
     * Is the cart currently disabled.
     * This is useful to prevent any cart operation for certain cases -
     * For example when checkout is in progress.
     * @type {boolean}
     */
    isCartClosed = false;

    /**
     * The ISO 4217 currency code for the cart page
     *
     * @type {string}
     */
    currencyCode;
    dataa;
    @api webCartId;
    @api _interval;
    @api openModal;
    @api _name1;
    @api _name2;
    @api address1;
    @api address2;
    @api city;
    @api postalCode;
    @api state;
    @api country;
    @api checked = false;
    @api isChecked = false;
    @api summary;
    @api recInput;
    @api packSlipInstruction;
    @api name;
    countryCurrency;
    isDropship = false;
    @api timeoutId;
    @api _records;
    @track hidePagination;
    @api previousPageToken;
    @api printArray = [];
    @api isBrowserPrint = false;
    @api isPrintCalled = false;
    @api getTodaysDate;
    @api localeSidKey;
    @track shippingCarrier;
    isDirty;
    lastSimulated;
    time;
    selectedCountry;
    showShippingCarrier = false;
    isGetQuote = false;
    isFinishedGoods = false;
    NewSap = [{}];
    @track checkSimulateStartTime = 0;
    @track simulateStartTime;
    _interval;
    @track progress = 3000;
    imagUrlsArray = [];
    base64ProductImages;

    /**
     * Gets whether the cart item list is empty.
     *
     * @type {boolean}
     * @readonly
     */
    get isCartEmpty() {
        // If the items are an empty array (not undefined or null), we know we're empty.
        return Array.isArray(this.cartItems) && this.cartItems.length === 0;
    }

    /**
     * Gets whether the item list state is indeterminate (e.g. in the process of being determined).
     *
     * @returns {boolean}
     * @readonly
     */
    get isCartItemListIndeterminate() {
        return !Array.isArray(this.cartItems);
    }

    /**
     * Gets the normalized effective account of the user.
     *
     * @type {string}
     * @readonly
     * @private
     */
    get resolvedEffectiveAccountId() {
        const effectiveAccountId = this.effectiveAccountId || '';
        let resolved = null;
        if (effectiveAccountId.length > 0 && effectiveAccountId !== '000000000000000') {
            resolved = effectiveAccountId;
        }
        return resolved;
    }

    disconnectedCallback() {
        clearInterval(this._interval);
    }

    async connectedCallback() {
        registerListener('OrderSummaryToPdf', this.handleOrderSummary, this);
        this.getbase64FromUrl();
        this.getTodaysDate = new Date();
        fireEvent(this.pageRef, 'checkbox', this.isChecked);

        this.checkInterface();

        getSapTotal({
            webcartId: this.recordId
        })
            .then((result) => {
                this.summary = result[0];
                this.shippingCarrier = result[0];
                result[0].LB2BOrderType__c == 'LB2BFinishedGoods'
                    ? (this.isFinishedGoods = true)
                    : (this.isFinishedGoods = false);
                this.sapId = this.summary.Sold_To_SAP_Account__c;
                this.checkAccountType(this.sapId);
                this.address1 = this.summary.SAP_ShipTo_Override_Street__c;
                this.address2 = this.summary.SAP_ShipTo_Override_Street2__c;
                this._name1 = this.summary.SAP_ShipTo_Override_Name__c;
                this._name2 = this.summary.SAP_ShipTo_Override_Name1__c;
                this.city = this.summary.SAP_ShipTo_Override_City__c;
                this.state = this.summary.SAP_ShipTo_Override_Region__c;
                this.postalCode = this.summary.SAP_ShipTo_Override_PostalCode__c;
                this.country = this.summary.SAP_ShipTo_Override_Country__c;
                this.packSlipInstruction = this.summary.UI_Pack_Slip_Instruction__c;
                this.isDirty = this.summary.Is_Dirty__c;
                this.lastSimulated = this.summary.Last_Simulated__c;

                let new_last_simulation = new Date(this.lastSimulated);
                this.time = new_last_simulation.getTime();
                localStorage.setItem('packing', this.packSlipInstruction);
                /* for 15 min timer last simulated */
                if (
                    this.isDirty === true ||
                    this.lastSimulated === null ||
                    this.lastSimulated === undefined ||
                    this.getTimeDifference(this.time) >= '15'
                ) {
                    //code for data layer starts
                    sapOrderSimulationEvent('order_simulate', this.recordId);
                    //code for data layer ends
                } else {
                    fireEvent(this.pageRef, '_callCartTotal', '');
                    this.resetTimer();
                    this.cartItems = JSON.parse(localStorage.getItem('cartItems'));
                    if (this.cartItems.hasError) {
                        console.log('result for cartitems', this.cartItems);
                        let errors = [
                            ...this.cartItems.sapErrors,
                            ...this.cartItems.salesforceErrors
                        ];
                        window.history.back();
                        setTimeout(() => {
                            fireEvent(this.pageRef, 'sapcallFail', errors);
                            //fireEvent(this.pageRef, 'sapcallFail', this.cartItems.sapErrors);
                        }, 2000);
                    }
                    console.log('cart items for local storage :', JSON.parse(this.cartItems));
                }
            })
            .catch((error) => {
                console.log('Error' + error);
            });
    }

    checkInterface() {
        checkInterface({}).then((result) => {
            this.isEnosixInterface = result;
            if (this.isEnosixInterface) {
                this.getOrderSimulation();
            } else {
                this._interval = setInterval(() => {
                    this.progress = this.progress + 3000;
                    this.checkSimulateTime().then(() => {
                        if (this.simulateStartTime === undefined) {
                            clearInterval(this._interval);
                        }
                    });
                }, this.progress);
            }
        });
    }

    async checkSimulateTime() {
        return await checkSimulateStartTime({
            webCartId: this.recordId
        }).then((result) => {
            this.simulateStartTime = result.SimulateStartTime__c;
            if (result.SimulateStartTime__c === undefined) {
                clearInterval(this._interval);
                this.getOrderSimulation(); //get the sap data using simulateOrder
            } else if (this.progress === 480000) {
                window.history.back();
                const event = new ShowToastEvent({
                    title: Lb2bAgoraExecuteFailed,
                    variant: 'error',
                    mode: 'dismissable'
                });
                this.dispatchEvent(event);
            }
        });
    }

    getOrderSimulation() {
        callSimulateOrder({
            webcarId: this.recordId,
            doDismissErrors: true
        })
            .then((res) => {
              //  res.agoraResponse = '{"cartId":"0a6D700000006NVIAY", cartItems:[{"brandName":"STANLEY","conditionPrcingUnit":"1","deleteMe":false,"extendedPrice":31.5,"freight":22,"hasBomExplosion":false,"hasDiscount":false,"hasFreeGoods":false,"hasRoundedQuantity":false,"hasSubstituteProducts":false,"oldExtendedPrice":31.5,"oldProduct2Id":"01t3c000006PxsBAAS","oldProductName":"STANLEY KNF CARDED SAFETY","oldProductSku":"10-189C","oldQuantity":6,"product2Id":"01t3c000006PxsBAAS","productName":"STANLEY KNF CARDED SAFETY","productSku":"10-189C","quantity":6,"shipmentList":[{"estimatedShipDate":"","id":"10-189C000010p","isFreeGood":false,"isPendingAvailability":true,"plantName":"","shipQuantity":6}],"sublineList":[],"unitOfMeasure":false,"unitPrice":5.25}], "hasError":false,"orderType":"LB2BFinishedGoods","salesforceErrors":[],"sapErrors":[]}}'
                let result =
                    res.enosixResponse !== undefined ? res.enosixResponse : res.agoraResponse;
                console.log('Result for simulateOrder ---> ', (result));
                fireEvent(this.pageRef, '_callCartTotal', '');
                //handle cart icon
                this.handleCartUpdate();
                this.resetTimer();
                if (result.hasError) {
                    let errors = [...result.sapErrors, ...result.salesforceErrors];

                    //code for data layer starts
                    if (result.status == 'ORDER SIMULATE ERROR') {
                        if (result.sapErrors) {
                            let error = result.sapErrors.map((e) => e).join('|');
                            sapOrderSimulationEvent(
                                'site_error',
                                error,
                                'Order Simulate',
                                true,
                                null
                            );
                        }
                    } else if (result.status == 'SAP CALLOUT ERROR') {
                        if (result.salesforceErrors) {
                            this.MoveToDataLayer('No response');
                            sapOrderSimulationEvent(
                                'site_error',
                                'SAP callout Error',
                                'Order Simulate',
                                true,
                                ''
                            );
                        }
                    } else if (result.status == 'SUB PRODUCTS ERROR') {
                        if (result.salesforceErrors) {
                            for (let i = 0; i < result.salesforceErrors.length; i++) {
                                sfdcOrderSimulationEvent(
                                    'site_error',
                                    result.salesforceErrors[i].split(':')[1],
                                    result.salesforceErrors[i],
                                    'Order Simulate'
                                );
                            }
                        }
                    } else if (result.status == 'LOGIC ERROR') {
                        if (result.salesforceErrors) {
                            for (let i = 0; i < result.salesforceErrors.length; i++) {
                                sfdcOrderSimulationEvent(
                                    'site_error',
                                    result.salesforceErrors[i].split(':')[1],
                                    result.salesforceErrors[i],
                                    'Order Simulate'
                                );
                            }
                        }
                    }
                    //code for data layer ends

                    localStorage.setItem('cartItems', JSON.stringify(result));
                    window.history.back();
                    setTimeout(() => {
                        //fireEvent(this.pageRef, 'sapcallFail', result.sapErrors);
                        fireEvent(this.pageRef, 'sapcallFail', errors);
                    }, 2000);
                } else {
                    if (result.cartItems != undefined) {
                        this.callGetImages(result);
                    }

                    this.cartItems = result.cartItems;
                    console.log('local storage', this.cartItems);
                    localStorage.setItem('cartItems', JSON.stringify(this.cartItems));

                    result.salesforceErrors.forEach((error) => {
                        //To display error msg in checkout page after removing TAN product from cart.
                        if (error.includes('0 DOLALR TAN')) {
                            let str =
                                LB2BMaterial + ' ' + error.split(':')[1] + ' ' + LB2BTanProdError;
                            this.tanProdSku.push(str);
                            this.isTanProdError = this.tanProdSku.length != 0 ? true : false;
                        }

                        //TCOM-2497:To display error msg in checkout page after removing discontinued sku/s.
                        else if (error.includes('DISCONTINUED SKU')) {
                            let str1 =
                                LB2BMaterial +
                                ' ' +
                                error.split(':')[1] +
                                ' ' +
                                LB2BDiscontinuedErr;
                            this.discontinuedSkus.push(str1);
                            this.isDiscontinuedError =
                                this.discontinuedSkus.length != 0 ? true : false;
                        }
                        /* code for data layer starts */
                        sfdcOrderSimulationEvent(
                            'site_error',
                            error.split(':')[1],
                            error,
                            'Order Simulate'
                        );
                        /* code for data layer ends */
                        this.cartItems = result.cartItems;
                    });
                }
            })
            .catch((error) => {
                window.history.back();
                setTimeout(() => {
                    fireEvent(this.pageRef, 'sapcallFail');
                }, 2000);
                console.log('Error for simulateOrder ---> ', error);
            });
    }

    callGetImages(res) {
        // get the images using getImages
        getImages({
            cartId: this.recordId
        })
            .then((result) => {
                this.cartItemImages = result.images;
                console.log('Result for get Images ---> ', result);
                if (res.cartItems != undefined) {
                    res.cartItems.forEach((itemsArray) =>
                        this.cartItemImages.forEach((imagesArray) => {
                            if (itemsArray.productSku === imagesArray.productSku) {
                                itemsArray.productImageUrl = imagesArray.mainImageUrl;
                                this.imagUrlsArray.push(imagesArray.mainImageUrl);
                            }
                        })
                    );
                }
               // this.convertBulkImgUrlsToBase64();
                this.cartItems = res.cartItems;
                console.log('local storage', this.cartItems);
                localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
            })
            .catch((error) => {
                console.log('Error for get Images ---> ', error);
            });
    }

    convertBulkImgUrlsToBase64(){
        convertBulkImageUrlsToBase64({
            imageUrls: this.imagUrlsArray
        })
            .then((result) => {
                this.base64ProductImages = result;
                this.isGetQuote = true;
            })
            .catch((error) => {
                console.log('error for base64', error);
            });
    }

    updateAccountHandler(event) {
        this.visibleAccounts = [...event.detail.records];
        console.log('New Pagination Data ', event.detail.records);
    }
    handleAdditionalEmail(event) {
        this.additionalEmail = event.target.value;
    }

    isValidEmail(email) {
        const regex =
            /^(([^<>()\[\]\\.,;:\s@“]+(\.[^<>()\[\]\\.,;:\s@”]+)*)|(“.+”))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return regex.test(email);
    }

    handleOrderSummary(data) {
        this.orderTotal = data;
    }

    getQuote() {
        this.convertBulkImgUrlsToBase64();
     }
 
    handleCloseGetQuote() {
        this.isGetQuote = false;
    }

    getBrowserPrint() {
           
        if (this.additionalEmail) {
            if (!this.isValidEmail(this.additionalEmail)) {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: LB2BInvalidEmail,
                        variant: 'error',
                        mode: 'dismissable'
                    })
                );
            } else {
                localStorage.setItem('additionalEmail', this.additionalEmail);
                let fields = {};
                fields[ID.fieldApiName] = this.recordId;
                fields[LB2BIsQuote.fieldApiName] = true;
                fields[QuoteAdditionalEmail.fieldApiName] = this.additionalEmail;
                const recordInput = { fields: fields };
                updateRecord(recordInput)
                    .then(() => {
                        throw new Error();
                    })
                    .catch((error) => {
                        fireEvent(this.pageRef, 'quoteOrder', 'true');
                        console.log('base 64',this.base64ProductImages)
                        getQuotePdf(
                            this.cartItems,
                            this.base64ProductImages,
                            this.getTodaysDate,
                            JSON.parse(JSON.stringify(this.orderTotal)),
                            this.brandToPdf,
                            this.base64data,
                            this.localeSidKey,
                            false
                        );
                        this.isGetQuote = false;
                    });
            }
        } else {
            localStorage.setItem('additionalEmail', this.additionalEmail);
            let fields = {};
            fields[ID.fieldApiName] = this.recordId;
            fields[LB2BIsQuote.fieldApiName] = true;
            fields[QuoteAdditionalEmail.fieldApiName] = this.additionalEmail;
            const recordInput = { fields: fields };
            updateRecord(recordInput)
                .then(() => {
                    throw new Error();
                })
                .catch((error) => {
                    fireEvent(this.pageRef, 'quoteOrder', 'true');
                    getQuotePdf(
                        this.cartItems,
                        this.base64ProductImages,
                        this.getTodaysDate,
                        JSON.parse(JSON.stringify(this.orderTotal)),
                        this.brandToPdf,
                        this.base64data,
                        this.localeSidKey,
                        false
                    );
                    this.isGetQuote = false;
                });
        }
    }

    getbase64FromUrl() {
        getBase64FromImageUrl({
            url: window.location.origin + this.sbdLogo
        })
            .then((result) => {
                this.base64data = result;
            })
            .catch((error) => {
                console.log('error for base64', error);
            });
    }

    resetTimer() {
        clearTimeout(this.timeoutId);
        this.timeoutId = setTimeout(() => {
            this.sessionExpirationModal();
        }, 900000);
    }

    sessionExpirationModal() {
        this.openModal = true;
    }

    backToCartPage() {
        history.back();
    }

    //TODO:Get time difference for cart time out
    getTimeDifference(datetime) {
        console.log('datetime', datetime);
        let now = new Date().getTime();
        console.log('now -------> ', now);
        if (isNaN(datetime))
            // var timeDiff = now-datetime;
            console.log('diffffffffff', now - datetime);
        let minutes = Math.floor((now - datetime) / 60000);
        let seconds = (((now - datetime) % 60000) / 1000).toFixed(0);
        console.log('time diff', minutes + ':' + (seconds < 10 ? '0' : '') + seconds);
        return minutes;
    }

    handlePackingSlip(event) {
        localStorage.setItem('packing', event.target.value);
        updateWebCartPackSlip({
            cartId: this.recordId,
            packSlip: event.target.value
        })
            .then((result) => { })
            .catch((error) => { });
    }

    // To identify the country & Indirect Acoount to show/hide dropShip section
    checkAccountType(sapId) {
        getSapAccountFlags({
            sapAccountId: sapId
        })
            .then((result) => {
                console.log('getSapAccountFlags result >>>',result);
                fireEvent(this.pageRef, 'brandName', result);
                this.brandToPdf = result[0].Search_Term_2__c;
                this.countryCurrency = result[0].CurrencyIsoCode;
                if (this.countryCurrency == 'USD' || 'CAD') {
                    this.isDropship = true;
                }

                this.checkAccount = result[0].Indirect_Sold_To__c;
                if (this.checkAccount === true) {
                    this.isIndirectAccount = true;
                } else {
                    this.isIndirectAccount = false;
                }
                if (
                    this.isIndirectAccount === true &&
                    (this.address1 != undefined ||
                    this._name1 != undefined ||
                    this.city != undefined ||
                    this.state != undefined ||
                    this.postalCode != undefined)
                ) {
                    this.checked = true;
                    this.isChecked = true;
                    fireEvent(this.pageRef, 'checkbox', this.isChecked);
                    this.updateDropShip();
                } else {
                    this.resetDropShip();
                }
            })
            .catch((error) => {
                console.log('Error' + error);
            });
    }

    updateSap() {
        getSapData({
            cartId: this.recordId
        })
            .then((result) => {
                fireEvent(this.pageRef, '_callCartTotal', '');
                this.resetTimer();
                this.sapItems = result;
                console.log('net item : ', this.sapItems);
            })
            .catch((error) => {
                console.log('Sap data Error : ', error);
            });
    }

    handleCartUpdate() {
        // Update Cart Badge
        this.dispatchEvent(
            new CustomEvent(CART_CHANGED_EVT, {
                bubbles: true,
                composed: true
            })
        );
        // Notify any other listeners that the cart items have updated
        fireEvent(this.pageRef, CART_ITEMS_UPDATED_EVT);
    }

    renderedCallback() {
        // if (this.isBrowserPrint) {
        //     setTimeout(() => {
        //         window.print();
        //         this.isBrowserPrint = false;
        //     }, 1000);
        // }
        loadStyle(this, GlobalCSS);

        Promise.all([
            loadScript(this, jspdf) // load script here
        ]);
    }

    handleCheckbox(event) {
        let checked = event.target.checked;
        if (checked == true) {
            this.isChecked = true;
            fireEvent(this.pageRef, 'checkbox', this.isChecked);
        } else {
            this.isChecked = false;
            fireEvent(this.pageRef, 'checkbox', this.isChecked);
            this.resetDropShip();
        }
    }

    resetDropShip() {
        this._name2 = '';
        this._name1 = '';
        this.address1 = '';
        this.address2 = '';
        this.city = '';
        this.state = '';
        this.postalCode = '';
        let fields = {};
        fields[ID.fieldApiName] = this.recordId;
        fields[ADDRESS1.fieldApiName] = '';
        fields[ADDRESS2.fieldApiName] = '';
        fields[Name1.fieldApiName] = '';
        fields[Name2.fieldApiName] = '';
        fields[CITY.fieldApiName] = '';
        fields[POSTALCODE.fieldApiName] = '';
        fields[STATE.fieldApiName] = '';
        fields[COUNTRY.fieldApiName] = '';
        const recordInput = { fields: fields };
        console.log('record input after disable checkbox:' + JSON.stringify(recordInput));
        updateRecord(recordInput);
    }

    @wire(getPicklistValues, { recordTypeId: '012000000000000AAA', fieldApiName: US_STATES })
    statesUs;

    @wire(getPicklistValues, { recordTypeId: '012000000000000AAA', fieldApiName: CA_STATES })
    statesCA;

    get stateOptions() {
        if (LOCALE === 'en-US') {
            return this.statesUs.data.values;
        } else if (LOCALE === 'fr-CA') {
            return this.statesCA.data.values;
        } else {
            return [];
        }
    }

    handleName1Change(event) {
        this._name1 = event.target.value;
        this.updateDropShip();
    }

    handleName2Change(event) {
        this._name2 = event.target.value;
        this.updateDropShip();
    }

    handleAddress1Change(event) {
        this.address1 = event.target.value;
        this.updateDropShip();
    }

    handleAddress2Change(event) {
        this.address2 = event.target.value;
        this.updateDropShip();
    }

    handleCityChange(event) {
        this.city = event.target.value;
        this.updateDropShip();
    }

    handlePostalCodeChange(event) {
        if (LOCALE === 'fr-CA') {
            let strCA = event.target.value;
            if (strCA.indexOf(' ') == -1 && strCA.length > 3) {
                let finalpostalCode = strCA.slice(0, 3) + ' ' + strCA.slice(3);
                this.postalCode = finalpostalCode;
            } else {
                this.postalCode = event.target.value;
            }
        } else {
            this.postalCode = event.target.value;
        }
        this.updateDropShip();
    }

    handleStateChange(event) {
        this.state = event.detail.value;
        this.updateDropShip();
    }

    updateDropShip() {
        fireEvent(this.pageRef, 'address1Value', this.address1);
        let fields = {};
        fields[ID.fieldApiName] = this.recordId;
        fields[ADDRESS1.fieldApiName] = this.address1;
        fields[ADDRESS2.fieldApiName] = this.address2;
        fields[Name1.fieldApiName] = this._name1;
        fields[Name2.fieldApiName] = this._name2;
        fields[CITY.fieldApiName] = this.city;
        fields[POSTALCODE.fieldApiName] = this.postalCode;
        fields[STATE.fieldApiName] = this.state;
        if (LOCALE === 'en-US') {
            fields[COUNTRY.fieldApiName] = this.label.LB2BUnitedStates;
        } else if (LOCALE === 'fr-CA') {
            fields[COUNTRY.fieldApiName] = this.label.LB2BCanada;
        }

        const recordInput = { fields: fields };

        updateRecord(recordInput).catch((error) => {
            console.log('Bug:', error);
        });

        this.recInput = recordInput;
        fireEvent(this.pageRef, 'checkbox', this.isChecked);
        fireEvent(this.pageRef, 'dropship', this.recInput);
    }

    //To check the name of the user
    @wire(getRecord, {
        recordId: USER_ID,
        fields: [NAME_K]
    })
    wireuser({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            this.name = data.fields.Name.value;
            this.checkCountry();
        }
    }

    checkCountry() {
        getAccount({
            username: this.name
        })
            .then((result) => {
                //To get print page Quote date:
                this.localeSidKey = result[0].LocaleSidKey;
                if (this.localeSidKey == 'es_MX') {
                    this.getTodaysDate = new Intl.DateTimeFormat(['ban', 'id']).format(
                        this.getTodaysDate
                    );
                } else if (this.localeSidKey == 'fr' || this.localeSidKey == 'fr_CA') {
                    this.getTodaysDate = new Intl.DateTimeFormat('fr-CA').format(
                        this.getTodaysDate
                    );
                } else {
                    this.getTodaysDate = new Intl.DateTimeFormat('en-US').format(
                        this.getTodaysDate
                    );
                }
            })
            .catch((error) => {
                console.log('Address Undefined:', error);
            });

        if (LOCALE === 'en-US') {
            this.selectedCountry = this.label.LB2BUnitedStates;
            this.showShippingCarrier = true;
        } else if (LOCALE === 'fr-CA') {
            this.selectedCountry = this.label.LB2BCanada;
            this.showShippingCarrier = !Internal_Sales_Rep_CA ? false : true;
        }
    }
    MoveToDataLayer() {
        BapiTimeoutEvent('bapi_timeout', 'Order Simulate');
    }

    get cartFooterText() {
        if (LOCALE === 'es-MX') {
            return this.label.LB2BFooter_Line_esMX;
        }
        else if (LOCALE === 'fr-CA') {
            return this.label.LB2BFooter_Line_frCA;
        }
        else if (LOCALE === 'en-US') {
            return this.label.LB2BFooter_Line_enUS;
        }
        else {
            return this.label.LB2BFooter_Line;
        }
    }
}